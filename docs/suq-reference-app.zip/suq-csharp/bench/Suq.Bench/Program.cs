using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using Suq.Model;
using Suq.Pricing;
using Suq.Warehouse;
using static Suq.Pricing.UnitLiterals;

BenchmarkRunner.Run<HotPaths>(args: args);

/// <summary>Budgets (zero allocations) are asserted in the tests; this reports time and variance.</summary>
[MemoryDiagnoser]
public class HotPaths
{
    readonly PackItem[] _items = new PackItem[40];
    readonly PackPlan _plan = new(40);
    readonly PriceLine[] _basket = new PriceLine[40];
    readonly Policy _policy = new(Currency.Myr, Pct(8),
        [new PercentOff(Pct(10), new Money(20000, Currency.Myr)), new FreeShippingOver(new Money(15000, Currency.Myr))],
        [new(Kg(1), new Money(800, Currency.Myr)), new(Kg(5), new Money(1500, Currency.Myr)), new(Kg(20), new Money(3500, Currency.Myr))]);

    [GlobalSetup]
    public void Setup()
    {
        for (int i = 0; i < 40; i++)
        {
            _items[i] = new(new Sku($"ITM-{1000 + i}"), G(100 + (i * 37) % 900), new ShelfSlot((byte)(1 + i % 6), (ushort)(i % 20)));
            _basket[i] = new($"K{i}", 1 + i % 3, new Money(990 + i * 10, Currency.Myr), G(250));
        }
    }

    [Benchmark] public void Pack40() => Packing.Pack(_plan, _items);
    [Benchmark] public Quote Quote40() => Pricing.Price(_basket, _policy);
}
