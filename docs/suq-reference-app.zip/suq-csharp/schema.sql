-- schema.sql — shared by the Bayan and C# versions
create table orders (
    id bigint primary key,
    customer_id bigint not null,
    currency text not null,
    status text not null,
    payment_id text,
    tracking_id text,
    cancel_reason text,
    placed_at timestamptz not null default now()
);
create table order_lines (
    order_id bigint not null references orders(id),
    sku text not null,
    qty int not null,
    unit_price_cents bigint not null,
    unit_weight bigint not null,
    status text not null
);
create table products (
    sku text primary key, name text not null, price_cents bigint not null,
    currency text not null, stock int not null, discontinued boolean not null default false
);
create table users (id bigserial primary key, email text unique not null, username text not null, password_hash text not null);
create table address_drafts (order_id bigint primary key, patch jsonb not null);
create table sessions (token text primary key, customer_id bigint not null, expires_at timestamptz not null);
