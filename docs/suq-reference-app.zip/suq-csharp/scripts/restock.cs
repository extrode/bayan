#!/usr/bin/env dotnet
#:package Npgsql@10.0.3
// restock.cs — load a supplier's stock file into products.stock (a .NET 10 file-based app).
//
//   dotnet run scripts/restock.cs -- --file supplier.csv --dry-run
//
// No Args/Config derivation: flags and env vars are parsed by hand.

using Npgsql;

string? file = null;
bool dryRun = false;
int maxErrors = 10;
for (int i = 0; i < args.Length; i++)
{
    switch (args[i])
    {
        case "--file": file = args[++i]; break;
        case "--dry-run": dryRun = true; break;
        case "--max-errors": maxErrors = int.Parse(args[++i]); break;
        default: Console.Error.WriteLine($"unknown option {args[i]}"); return 2;
    }
}
if (file is null) { Console.Error.WriteLine("--file is required"); return 2; }
if (maxErrors is < 0 or > 1000) { Console.Error.WriteLine("--max-errors must be 0..1000"); return 2; }
var url = Environment.GetEnvironmentVariable("SUQ_DATABASE_URL");
if (url is null) { Console.Error.WriteLine("SUQ_DATABASE_URL is not set"); return 2; }

await using var db = NpgsqlDataSource.Create(url);
await using var conn = await db.OpenConnectionAsync();
await using var tx = await conn.BeginTransactionAsync();   // rolled back on dispose unless committed

long updated = 0;
int bad = 0, lineNo = 0;
foreach (var raw in File.ReadLines(file))
{
    lineNo++;
    var line = raw.Trim();
    if (line.Length == 0 || line.StartsWith('#')) continue;
    var parts = line.Split(',');
    bool ok = parts.Length == 2
        && System.Text.RegularExpressions.Regex.IsMatch(parts[0].Trim(), "^[A-Z]{3}-[0-9]{4}$")
        && int.TryParse(parts[1].Trim(), out var q) && q is >= 0 and <= 100_000;
    if (!ok)
    {
        Console.Error.WriteLine($"line {lineNo}: skipped");
        if (++bad > maxErrors) { Console.Error.WriteLine($"too many bad lines ({bad})"); return 1; }
        continue;
    }
    await using var cmd = new NpgsqlCommand("update products set stock = $2 where sku = $1", conn, tx);
    cmd.Parameters.Add(new NpgsqlParameter<string> { TypedValue = parts[0].Trim() });
    cmd.Parameters.Add(new NpgsqlParameter<int> { TypedValue = int.Parse(parts[1].Trim()) });
    updated += await cmd.ExecuteNonQueryAsync();
}

if (dryRun) { await tx.RollbackAsync(); Console.WriteLine("dry run: rolled back"); }
else await tx.CommitAsync();
Console.WriteLine($"{updated} products updated, {bad} lines skipped");
return 0;
