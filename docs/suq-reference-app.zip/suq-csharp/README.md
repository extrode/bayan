# Sūq — C# baseline (.NET 10, NativeAOT)

The same application in idiomatic C#, used to compare against the Bayan version (HANDOFF §21.4–5). The domain logic is kept identical, and the tests mirror the Bayan tests one for one.

```
dotnet test                                         # 37 tests; DB tests run when SUQ_TEST_DATABASE is set
dotnet publish src/Suq -c Release -r linux-x64      # NativeAOT, zero trim/AOT warnings, ~16 MB
dotnet run -c Release --project bench/Suq.Bench     # BenchmarkDotNet
dotnet run scripts/restock.cs -- --file stock.csv   # file-based app
psql -f schema.sql                                  # schema shared by both versions
```

## Verified

| Check | Result |
|---|---|
| Build, warnings as errors, AOT analyzers | Clean |
| NativeAOT publish (linux-x64) | 16.5 MB binary, no warnings |
| Tests | 37/37, including PostgreSQL 16: binary COPY, state round trip, corrupt rows, ownership, the charged total, outbox retry, search escaping |
| Zero allocations: pack 40 items, quote 40 lines | Asserted in tests |
| Benchmarks | Pack40: 501 ns ± 5 ns; Quote40: 121 ns ± 4 ns; 0 B allocated |
| `restock.cs` against Postgres | 2 updated, 1 skipped |

## Size compared with Bayan (code only, tests excluded)

| Part | Bayan tokens | C# tokens | C# / Bayan |
|---|---|---|---|
| Pricing | 1,168 | 1,915 | 1.64× |
| Model | 852 | 2,754 | 3.23× |
| Warehouse | 892 | 1,111 | 1.25× |
| Carrier | 712 | 1,066 | 1.50× |
| Database | 1,119 | 1,425 | 1.27× |
| Payments + FFI | 946 | 1,153 | 1.22× |
| Storefront | 2,568 | 3,579 | 1.39× |
| Library | 442 | 540 | 1.22× |
| Entry point | 720 | 852 | 1.18× |
| Admin script | 366 | 532 | 1.45× |
| **Total** | **9,785** | **14,927** | **1.53×** |

Line counts are much closer than tokens because the C# packs several statements per line. Tokens are the fairer measure. The model is where Bayan saves most: `requires`, typestate and derived `Patch`/`rules` replace hand-written validation and state checks.

## What C# can't express (checked at runtime here, at compile time in Bayan)

| Concern | C# version | Bayan version |
|---|---|---|
| Order lifecycle | `InvalidOperationException` on a wrong state; `order.Tracking` throws unless shipped | `ref this is .paid`, `Order is .shipped` parameter |
| Validation | Hand-written `Validated()` that every `with` must remember to call; `default(Sku)` skips the check | `requires`, checked at construction and by `with` |
| Exhaustiveness | `_ => throw` arms; adding a state still compiles | Exhaustive switches on unions and states |
| Untrusted input | Convention only; concatenating a query string into SQL compiles | `Untrusted<T>` plus sink types |
| Secrets | `Secret<T>` hides `ToString`, but nothing stops `Expose()` going into a DTO | Derivations refuse; `expose()` needs `because` |
| Purity and capabilities | Nothing marks the pricing library as pure | `capabilities: []`, no `uses` clause |
| Move-only keys | `SafeHandle` can be copied by reference; disposal is the caller's job | `struct unique` |
| Zero allocations | Needed a key-array sort to avoid a closure allocation; checked only by a test | `@budget(allocs: 0)` and the effect system (no `alloc`) |
| Units | Hand-written operators for `Grams`, `Kilograms` and `BasisPoints` | `unit` declarations |
