using Suq.Model;
using Suq.Warehouse;
using static Suq.Pricing.UnitLiterals;

namespace Suq.Tests;

public class WarehouseTests
{
    internal static PackItem[] Sample(int count)
    {
        var items = new PackItem[count];
        for (int i = 0; i < count; i++)
            items[i] = new(new Sku($"ITM-{1000 + i}"), G(100 + (i * 37) % 900), new ShelfSlot((byte)(1 + i % 6), (ushort)(i % 20)));
        return items;
    }

    [Fact]
    public void Heaviest_first_smallest_box_that_fits()
    {
        var plan = new PackPlan(8);
        PackItem[] items =
        [
            new(new Sku("RUG-0001"), Kg(4), new(3, 1)),
            new(new Sku("TEA-0001"), G(300), new(1, 4)),
            new(new Sku("MUG-0001"), G(500), new(1, 2)),
        ];
        Packing.Pack(plan, items);
        Assert.Equal(2, plan.BoxCount);
        Assert.Equal("M", plan.Boxes[0].Name);
        Assert.Equal(G(4800), plan.Load[0]);
        Assert.Equal("S", plan.Boxes[1].Name);
        Assert.Equal(G(450), plan.Load[1]);
    }

    [Fact]
    public void An_item_heavier_than_the_largest_box_fails()
    {
        PackItem[] items = [new(new Sku("BED-0001"), Kg(15), new(9, 1))];
        Assert.Throws<TooHeavyException>(() => Packing.Pack(new PackPlan(1), items));
    }

    [Fact]
    public void Picks_walk_aisle_by_aisle()
    {
        var items = Sample(40);
        var picks = new int[40];
        Packing.PickOrder(picks, new ShelfSlot[40], items);
        for (int n = 1; n < picks.Length; n++) Assert.True(items[picks[n - 1]].Slot <= items[picks[n]].Slot);
    }

    [Fact]
    public void Packing_40_items_allocates_nothing()
    {
        var items = Sample(40);
        var plan = new PackPlan(40);
        Packing.Pack(plan, items);
        long before = GC.GetAllocatedBytesForCurrentThread();
        for (int i = 0; i < 100; i++) Packing.Pack(plan, items);
        Assert.Equal(0, GC.GetAllocatedBytesForCurrentThread() - before);
    }

    [Fact]
    public void Label_requires_a_shipped_order()
    {
        var order = new Order { Id = new OrderId(1), Customer = new CustomerId(1), Currency = Pricing.Currency.Myr };
        Assert.Throws<InvalidOperationException>(() => Packing.TryWriteLabel(new char[64], order, out _));
    }
}
