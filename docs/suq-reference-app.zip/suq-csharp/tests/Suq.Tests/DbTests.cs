using Npgsql;
using Suq.Db;
using Suq.Model;
using Suq.Pricing;
using static Suq.Pricing.UnitLiterals;

namespace Suq.Tests;

/// <summary>Runs against a real database when SUQ_TEST_DATABASE is set; otherwise passes trivially.</summary>
public class DbTests
{
    static readonly string? Url = Environment.GetEnvironmentVariable("SUQ_TEST_DATABASE");

    static (OrdersStore, NpgsqlDataSource) Store()
    {
        var db = new NpgsqlSlimDataSourceBuilder(Url!).Build();
        return (new OrdersStore(db), db);
    }

    static Order Placed(long id, long customer)
    {
        var o = new Order { Id = new OrderId(id), Customer = new CustomerId(customer), Currency = Currency.Myr };
        o.AddLine(new() { Sku = new Sku("TEA-0001"), Qty = 2, UnitPrice = new Money(1200, Currency.Myr), UnitWeight = G(100) });
        o.AddLine(new() { Sku = new Sku("MUG-0001"), Qty = 1, UnitPrice = new Money(2500, Currency.Myr), UnitWeight = G(400) });
        o.Place();
        return o;
    }

    [Fact]
    public async Task Round_trips_every_state_through_copy_and_readers()
    {
        if (Url is null) return;
        var (store, db) = Store();
        await using var _ = db;
        long id = Random.Shared.NextInt64(1, long.MaxValue);

        long customer = Random.Shared.NextInt64(1, long.MaxValue);
        var order = Placed(id, customer);
        await store.InsertAsync(order, default);
        var loaded = (await store.FindAsync(new OrderId(id), default))!;
        Assert.IsType<OrderState.Placed>(loaded.State);
        Assert.Equal(2, loaded.Lines.Count);
        Assert.Equal(4900, loaded.Total.Cents);

        loaded.MarkPaid(new PaymentId("pay_1"));
        await store.SaveStateAsync(loaded, default);
        Assert.Equal(4900, (await store.LifetimeSpendAsync(new CustomerId(customer), Currency.Myr, default)).Cents);

        loaded.MarkShipped(new TrackingId("EX123456789MY"));
        await store.SaveStateAsync(loaded, default);
        var shipped = (await store.FindAsync(new OrderId(id), default))!;
        var s = Assert.IsType<OrderState.Shipped>(shipped.State);
        Assert.Equal("pay_1", s.Payment.Value);
        Assert.Equal("EX123456789MY", s.Tracking.Value);

        var csv = new StringWriter();
        await store.ExportLinesAsync(DateTime.UtcNow.AddMinutes(-1), csv, default);
        Assert.Contains($"{id},TEA-0001,2,1200,100", csv.ToString());
    }

    [Fact]
    public async Task A_corrupt_row_is_reported_not_loaded()
    {
        if (Url is null) return;
        var (store, db) = Store();
        await using var _ = db;
        long id = Random.Shared.NextInt64(1, long.MaxValue);
        await using (var cmd = db.CreateCommand("insert into orders (id, customer_id, currency, status) values ($1, 1, 'MYR', 'paid')"))
        {
            cmd.Parameters.Add(new NpgsqlParameter<long> { TypedValue = id });
            await cmd.ExecuteNonQueryAsync();                 // paid, but no payment_id
        }
        await Assert.ThrowsAsync<CorruptRowException>(() => store.FindAsync(new OrderId(id), default));
    }
}
