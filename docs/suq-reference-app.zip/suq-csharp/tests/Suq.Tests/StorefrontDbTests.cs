using System.Net;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Time.Testing;
using Npgsql;
using Suq.Carrier;
using Suq.Db;
using Suq.Model;
using Suq.Payments;
using Suq.Pricing;
using Suq.Storefront;
using Suq.Warehouse;
using static Suq.Pricing.UnitLiterals;

namespace Suq.Tests;

sealed class FixedSessions(CustomerId? who) : ISessions
{
    public Task<CustomerId?> IdentifyAsync(HttpRequest req, CancellationToken ct) => Task.FromResult(who);
}

sealed class FlakyShipper(int failures) : IShipper
{
    public int Calls;
    public Task<TrackingId> BookAsync(Parcel parcel, CancellationToken ct) =>
        Interlocked.Increment(ref Calls) <= failures
            ? throw new CarrierException(CarrierErrorKind.Rejected, "down")      // not retryable: fails fast
            : Task.FromResult(new TrackingId($"EX{parcel.Order.Value % 1_000_000_000:D9}MY"));
}

/// <summary>Needs SUQ_TEST_DATABASE; passes trivially without it.</summary>
public class StorefrontDbTests
{
    static readonly string? Url = Environment.GetEnvironmentVariable("SUQ_TEST_DATABASE");
    static readonly Policy Malaysia = new(Currency.Myr, Pct(8), [new FreeShippingOver(new Money(15000, Currency.Myr))],
        [new(Kg(1), new Money(800, Currency.Myr)), new(Kg(5), new Money(1500, Currency.Myr))]);

    sealed record Fixture(Suq.Storefront.Storefront Shop, OrdersStore Orders, NpgsqlDataSource Db, FakeHandler Gateway, FlakyShipper Shipper, Outbox Outbox, SecretKey Key) : IAsyncDisposable
    {
        public async ValueTask DisposeAsync() { Key.Dispose(); await Db.DisposeAsync(); }
    }

    static Fixture Make(CustomerId? session, int shipFailures = 0)
    {
        var db = new NpgsqlSlimDataSourceBuilder(Url!).Build();
        var clock = new FakeTimeProvider();
        var orders = new OrdersStore(db);
        var charge = new FakeHandler(clock, FakeHandler.Json(HttpStatusCode.OK, """{"id": "pay_42", "status": "succeeded"}"""));
        var key = SecretKey.Load(new byte[32]);
        var gateway = new Gateway(new HttpClient(charge), new Uri("https://pay.example"), new Secret<string>("k"), key);
        var shipper = new FlakyShipper(shipFailures);
        var outbox = new Outbox(clock, NullLogger<Outbox>.Instance);
        var shop = new Suq.Storefront.Storefront(orders, new DraftStore(db), new FixedSessions(session), gateway, shipper, outbox, Malaysia,
            new Dictionary<Sku, ShelfSlot>(), clock, NullLogger<Suq.Storefront.Storefront>.Instance);
        return new(shop, orders, db, charge, shipper, outbox, key);
    }

    static async Task<OrderId> PlaceOrder(OrdersStore orders, CustomerId customer)
    {
        var o = new Order { Id = new OrderId(Random.Shared.NextInt64(1, long.MaxValue)), Customer = customer, Currency = Currency.Myr };
        o.AddLine(new() { Sku = new Sku("TEA-0001"), Qty = 2, UnitPrice = new Money(1200, Currency.Myr), UnitWeight = G(100) });
        o.AddLine(new() { Sku = new Sku("MUG-0001"), Qty = 1, UnitPrice = new Money(2500, Currency.Myr), UnitWeight = G(400) });
        o.Place();
        await orders.InsertAsync(o, default);
        return o.Id;
    }

    static readonly AddressPatchDto Kl = new("Aisyah", "1 Jalan Ampang", null, "Kuala Lumpur", MalaysianState.KualaLumpur, "50450");
    static CustomerId NewCustomer() => new(Random.Shared.NextInt64(1, long.MaxValue));

    [Fact]
    public async Task Someone_elses_order_is_not_found()
    {
        if (Url is null) return;
        var owner = NewCustomer();
        await using var f = Make(session: NewCustomer());
        var id = await PlaceOrder(f.Orders, owner);
        Assert.IsType<NotFound>(await f.Shop.SaveAddress(id.Value.ToString(), Kl, new DefaultHttpContext().Request, default));
        Assert.IsType<NotFound>(await f.Shop.Track(id.Value.ToString(), new DefaultHttpContext().Request, default));
        Assert.IsType<NotFound>(await f.Shop.Pay(id.Value.ToString(), new PayRequest("tok_visa_4242"), new DefaultHttpContext().Request, default));
        Assert.Equal(0, f.Gateway.Calls);
    }

    [Fact]
    public async Task Pay_charges_the_quoted_total_then_ships()
    {
        if (Url is null) return;
        var me = NewCustomer();
        await using var f = Make(session: me);
        var id = await PlaceOrder(f.Orders, me);
        var req = new DefaultHttpContext().Request;
        Assert.IsType<NoContent>(await f.Shop.SaveAddress(id.Value.ToString(), Kl, req, default));

        var result = await f.Shop.Pay(id.Value.ToString(), new PayRequest("tok_visa_4242"), req, default);
        Assert.IsType<Ok<OrderDto>>(result);
        // lines 4900 + shipping 800 (600 g) = 5700; tax 8% = 456; total 6156
        Assert.Equal(6156, JsonDocument.Parse(f.Gateway.LastBody!).RootElement.GetProperty("amountCents").GetInt64());
        Assert.IsType<OrderState.Shipped>((await f.Orders.FindAsync(id, default))!.State);
    }

    [Fact]
    public async Task A_booking_that_failed_is_retried_and_recorded()
    {
        if (Url is null) return;
        var me = NewCustomer();
        await using var f = Make(session: me, shipFailures: 1);
        var id = await PlaceOrder(f.Orders, me);
        var req = new DefaultHttpContext().Request;
        await f.Shop.SaveAddress(id.Value.ToString(), Kl, req, default);

        Assert.IsType<Accepted<OrderDto>>(await f.Shop.Pay(id.Value.ToString(), new PayRequest("tok_visa_4242"), req, default));
        Assert.IsType<OrderState.Paid>((await f.Orders.FindAsync(id, default))!.State);
        Assert.Equal(1, f.Outbox.Count);

        await f.Shop.SweepOutboxAsync(default);
        Assert.Equal(0, f.Outbox.Count);
        Assert.IsType<OrderState.Shipped>((await f.Orders.FindAsync(id, default))!.State);
    }

    [Fact]
    public async Task Search_matches_wildcards_literally_and_lists_out_of_stock()
    {
        if (Url is null) return;
        await using var db = new NpgsqlSlimDataSourceBuilder(Url).Build();
        string tag = $"Z{Random.Shared.Next(100000, 999999)}";
        await using (var cmd = db.CreateCommand("""
            insert into products values ($1, $2 || ' 100% cotton', 1000, 'MYR', 3, false),
                                        ($3, $2 || ' 100 cotton', 1000, 'MYR', 0, false),
                                        ($4, $2 || ' 100% old', 1000, 'MYR', 9, true)
            """))
        {
            foreach (var v in new[] { $"AAA-{tag[1..5]}", tag, $"BBB-{tag[1..5]}", $"CCC-{tag[1..5]}" })
                cmd.Parameters.Add(new NpgsqlParameter<string> { TypedValue = v });
            await cmd.ExecuteNonQueryAsync();
        }
        var pct = (Ok<List<ProductDto>>)await Catalog.Search($"{tag} 100%", null, db, default);
        Assert.Equal($"{tag} 100% cotton", Assert.Single(pct.Value!).Name);       // `%` is literal; discontinued hidden

        var all = (Ok<List<ProductDto>>)await Catalog.Search(tag, null, db, default);
        Assert.Contains(all.Value!, p => p.Name == $"{tag} 100 cotton" && !p.InStock);
    }
}
