using Suq.Model;
using Suq.Pricing;
using static Suq.Pricing.UnitLiterals;

namespace Suq.Tests;

public class ModelTests
{
    static Line Tea => new() { Sku = new Sku("TEA-0001"), Qty = 2, UnitPrice = new Money(1200, Currency.Myr), UnitWeight = G(100) };
    static Order NewOrder(long id) => new() { Id = new OrderId(id), Customer = new CustomerId(1), Currency = Currency.Myr };

    [Fact]
    public void Sku_shape()
    {
        Assert.True(Sku.TryCreate("TEA-0001", out _));
        Assert.False(Sku.TryCreate("tea-0001", out _));
        Assert.False(Sku.TryCreate("TEA-01", out _));
    }

    [Fact]
    public void An_order_moves_through_its_states()
    {
        var order = NewOrder(7);
        order.AddLine(Tea);
        order.Place();
        order.MarkPaid(new PaymentId("pay_123"));
        order.MarkShipped(new TrackingId("EX123456789MY"));
        Assert.IsType<OrderState.Shipped>(order.State);
        Assert.Equal("EX123456789MY", order.Tracking.Value);
        Assert.Equal(2400, order.Total.Cents);
    }

    [Fact]
    public void A_failed_transition_leaves_the_state_unchanged()
    {
        var order = NewOrder(8);
        Assert.Equal(BasketErrorKind.Empty, Assert.Throws<BasketException>(order.Place).Kind);
        Assert.IsType<OrderState.Draft>(order.State);
    }

    [Fact]
    public void Wrong_state_is_a_runtime_error()     // compile error in Bayan
    {
        var order = NewOrder(10);
        Assert.Throws<InvalidOperationException>(() => order.MarkShipped(new TrackingId("EX123456789MY")));
        Assert.Throws<InvalidOperationException>(() => order.Tracking);
    }

    [Fact]
    public void Removed_lines_dont_count()
    {
        var order = NewOrder(9);
        order.AddLine(Tea);
        order.RemoveLine(Tea.Sku);
        Assert.Equal(0, order.Total.Cents);
        Assert.Throws<BasketException>(order.Place);
    }

    [Fact]
    public void An_incomplete_draft_reports_every_missing_field()
    {
        var draft = new AddressPatch { Name = "Aisyah", Postcode = "50450" };
        var e = Assert.Throws<ViolationsException>(draft.Complete);
        Assert.Equal(["City", "Line1", "State"], e.Violations.Select(v => v.Field).Order());
    }

    [Fact]
    public void East_Malaysian_postcodes()
    {
        var ok = new Address { Name = "Ah Kow", Line1 = "Lot 5, Jalan Gaya", City = "Kota Kinabalu", State = MalaysianState.Sabah, Postcode = new Postcode("88000") }.Validated();
        Assert.Throws<ViolationsException>(() => (ok with { Postcode = new Postcode("50450") }).Validated());
    }
}
