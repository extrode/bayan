using Suq.Pricing;
using static Suq.Pricing.UnitLiterals;

namespace Suq.Tests;

public class MoneyTests
{
    [Fact]
    public void Mixed_currencies_fail_instead_of_adding()
    {
        var myr = new Money(100, Currency.Myr);
        var sgd = new Money(100, Currency.Sgd);
        Assert.False(myr.TryAdd(sgd, out _));
        Assert.True(myr.TryAdd(myr, out var sum));
        Assert.Equal(200, sum.Cents);
        Assert.Throws<InvalidOperationException>(() => myr + sgd);
    }

    [Theory]
    [InlineData(1250, "MYR 12.50")]
    [InlineData(5, "MYR 0.05")]
    [InlineData(-300, "MYR -3.00")]
    public void Format(long cents, string text) => Assert.Equal(text, new Money(cents, Currency.Myr).ToString());

    [Fact]
    public void Tax_rounds_half_up() => Assert.Equal(85, new Money(1063, Currency.Myr).Times(Pct(8)).Cents);

    // Laws: no language support, so a hand-rolled property loop.
    [Fact]
    public void Add_commutes_and_zero_is_identity()
    {
        var rng = new Random(42);
        var currencies = Enum.GetValues<Currency>();
        for (int i = 0; i < 1000; i++)
        {
            var a = new Money(rng.NextInt64(-1_000_000, 1_000_000), currencies[rng.Next(currencies.Length)]);
            var b = new Money(rng.NextInt64(-1_000_000, 1_000_000), currencies[rng.Next(currencies.Length)]);
            Assert.Equal(a.TryAdd(b, out var ab), b.TryAdd(a, out var ba));
            Assert.Equal(ab, ba);
            Assert.Equal(a, a + Money.Zero(a.Currency));
        }
    }
}

public class QuoteTests
{
    internal static readonly Policy Standard = new(Currency.Myr, Pct(8),
        [
            new PercentOff(Pct(10), new Money(20000, Currency.Myr)),
            new BuyGetFree("TEA-0001", 2, 1),
            new FreeShippingOver(new Money(15000, Currency.Myr)),
        ],
        [new(Kg(1), new Money(800, Currency.Myr)), new(Kg(5), new Money(1500, Currency.Myr)), new(Kg(20), new Money(3500, Currency.Myr))]);

    [Fact]
    public void Buy_two_get_one_free_on_tea()
    {
        PriceLine[] lines = [new("TEA-0001", 3, new Money(1200, Currency.Myr), G(100))];
        var q = Pricing.Pricing.Price(lines, Standard);
        Assert.Equal(1200, q.Discount.Cents);
        Assert.Equal(800, q.Shipping.Cents);
        Assert.Equal(256, q.Tax.Cents);
        Assert.Equal(3456, q.Total.Cents);
    }

    [Fact]
    public void Free_shipping_over_RM150()
    {
        PriceLine[] lines = [new("RUG-0001", 1, new Money(16000, Currency.Myr), Kg(4))];
        Assert.Equal(0, Pricing.Pricing.Price(lines, Standard).Shipping.Cents);
    }

    [Fact]
    public void Over_20kg_cannot_be_quoted()
    {
        PriceLine[] lines = [new("BED-0001", 1, new Money(90000, Currency.Myr), Kg(25))];
        Assert.Throws<OverweightException>(() => Pricing.Pricing.Price(lines, Standard));
    }

    [Fact]
    public void Quoting_40_lines_allocates_nothing()
    {
        var basket = new PriceLine[40];
        for (int i = 0; i < 40; i++) basket[i] = new($"K{i}", 1 + i % 3, new Money(990 + i * 10, Currency.Myr), G(250));
        Pricing.Pricing.Price(basket, Standard);                                   // warm up
        long before = GC.GetAllocatedBytesForCurrentThread();
        for (int i = 0; i < 100; i++) Pricing.Pricing.Price(basket, Standard);
        Assert.Equal(0, GC.GetAllocatedBytesForCurrentThread() - before);
    }
}
