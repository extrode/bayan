using System.Net;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Time.Testing;
using Suq.Carrier;
using Suq.Lib;
using Suq.Model;
using Suq.Payments;
using Suq.Storefront;
using static Suq.Pricing.UnitLiterals;

namespace Suq.Tests;

sealed class ListLogger : ILogger
{
    public readonly List<(LogLevel Level, string Message)> Entries = [];
    public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;
    public bool IsEnabled(LogLevel level) => true;
    public void Log<TState>(LogLevel level, EventId id, TState state, Exception? e, Func<TState, Exception?, string> fmt) =>
        Entries.Add((level, fmt(state, e)));
}

/// <summary>Replies in order, repeating the last. The C# stand-in for <c>provide net: FakeNet(...)</c>.</summary>
sealed class FakeHandler(TimeProvider clock, params Func<CancellationToken, Task<HttpResponseMessage>>[] replies) : HttpMessageHandler
{
    public int Calls;
    public string? LastBody;
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
    {
        if (request.Content is not null) LastBody = await request.Content.ReadAsStringAsync(ct);
        return await replies[Math.Min(Interlocked.Increment(ref Calls) - 1, replies.Length - 1)](ct);
    }

    public static Func<CancellationToken, Task<HttpResponseMessage>> Json(HttpStatusCode code, string body) =>
        _ => Task.FromResult(new HttpResponseMessage(code) { Content = new StringContent(body, Encoding.UTF8, "application/json") });
    public static Func<CancellationToken, Task<HttpResponseMessage>> Timeout => _ => throw new TaskCanceledException("timeout");
    public Func<CancellationToken, Task<HttpResponseMessage>> Delay(TimeSpan d) => async ct => { await Task.Delay(d, clock, ct); return new(HttpStatusCode.OK); };
}

public class CarrierTests
{
    const string Booking = """{"accepted": true, "trackingNumber": "EX123456789MY", "service": "standard", "estimatedDays": 2}""";
    static readonly Parcel Sample = new(new OrderId(42), "M", G(4800));
    static readonly FakeTimeProvider Clock = new(new DateTimeOffset(2026, 12, 1, 0, 0, 0, TimeSpan.Zero));

    static LajuExpress Courier(FakeHandler h) => new(new HttpClient(h), new Uri("https://api.laju.example"), new Secret<string>("test-key"));

    static async Task<T> RunWithClock<T>(FakeTimeProvider clock, Task<T> task)
    {
        while (!task.IsCompleted) { clock.Advance(TimeSpan.FromMilliseconds(100)); await Task.Delay(1); }
        return await task;
    }

    [Fact]
    public async Task Retries_a_timeout_then_succeeds()
    {
        var clock = new FakeTimeProvider(Clock.GetUtcNow());
        var h = new FakeHandler(clock, FakeHandler.Timeout, FakeHandler.Json(HttpStatusCode.OK, Booking));
        var log = new ListLogger();
        var id = await RunWithClock(clock, Shipping.BookWithRetryAsync(Sample, Courier(h), clock, log, default));
        Assert.Equal("EX123456789MY", id.Value);
        Assert.Equal(2, h.Calls);
        Assert.Single(log.Entries, e => e.Level == LogLevel.Warning);
    }

    [Fact]
    public async Task A_rejection_is_not_retried()
    {
        var clock = new FakeTimeProvider(Clock.GetUtcNow());
        var h = new FakeHandler(clock, FakeHandler.Json(HttpStatusCode.UnprocessableEntity, """{"accepted": false, "trackingNumber": ""}"""));
        var e = await Assert.ThrowsAsync<CarrierException>(() => Shipping.BookWithRetryAsync(Sample, Courier(h), clock, new ListLogger(), default));
        Assert.Equal(CarrierErrorKind.Rejected, e.Kind);
        Assert.Equal(1, h.Calls);
    }

    [Fact]
    public async Task The_batch_deadline_cancels_slow_bookings()
    {
        var clock = new FakeTimeProvider(Clock.GetUtcNow());
        var h = new FakeHandler(clock);
        h = new FakeHandler(clock, h.Delay(TimeSpan.FromSeconds(10)));
        var task = Shipping.BookAllAsync([Sample, Sample], Courier(h), clock, new ListLogger(), default);
        var e = await Assert.ThrowsAsync<CarrierException>(() => RunWithClock(clock, task));
        Assert.Equal(CarrierErrorKind.Timeout, e.Kind);
    }
}

public class AccountTests
{
    [Fact]
    public void Every_broken_rule_is_reported()
    {
        var v = Accounts.Validate(new SignupForm("a@b", "x!", "x!", 9));
        Assert.Equal(["email", "username", "username", "password", "age", "password"], v.Select(x => x.Field));
    }
}

public class WebhookTests
{
    [Fact]
    public void A_tampered_body_is_not_authentic()
    {
        var keyBytes = Enumerable.Repeat((byte)7, 32).ToArray();
        using var key = SecretKey.Load(keyBytes);
        var good = Encoding.UTF8.GetBytes("""{"id":1}""");
        var tag = HMACSHA256.HashData(keyBytes, good);
        Assert.True(new Webhook(good, tag).IsAuthentic(key));
        Assert.False(new Webhook(Encoding.UTF8.GetBytes("""{"id":2}"""), tag).IsAuthentic(key));
    }

    [Fact]
    public void Password_hash_is_argon2id() => Assert.StartsWith("$argon2id$", Passwords.Hash("correct horse battery"));
}

public class StatsTests
{
    [Fact]
    public void Top_three_largest_first()
    {
        Span<int> top = stackalloc int[3];
        int n = Ranking.Top<int>(top, [5, 1, 9, 3, 7, 9]);
        Assert.Equal([9, 9, 7], top[..n].ToArray());
    }

    [Fact]
    public void A_tally_ignores_order()
    {
        var a = new Tally(); var b = new Tally();
        a.Record(2, new Sku("TEA-0001"));
        b.Record(3, new Sku("TEA-0001"));
        b.Record(0, new Sku("MUG-0001"));
        var both = a.MergeWith(b).Pruned();
        Assert.Equal(5, Assert.Single(both.Counts).Value);
        Assert.Equal(a.MergeWith(b).Counts.OrderBy(x => x.Key.Value), b.MergeWith(a).Counts.OrderBy(x => x.Key.Value));
    }

    [Fact]
    public void Staff_permissions()
    {
        var s = new Staff("Mei", "mei@suq.example", Roles.Supervisor);
        Assert.True(s.CanRefund);
        Assert.NotEqual(Permission.None, Roles.Owner & Roles.Supervisor);
    }
}
