namespace Suq.Pricing;

public readonly record struct PriceLine(string Key, int Qty, Money UnitPrice, Grams UnitWeight);

public abstract record Promotion;
public sealed record PercentOff(BasisPoints Rate, Money Minimum) : Promotion;
public sealed record BuyGetFree(string Key, int Buy, int Free) : Promotion;
public sealed record FreeShippingOver(Money Threshold) : Promotion;

public readonly record struct ShippingBand(Grams UpTo, Money Fee);

/// <summary>Arrays, not spans: a record can't hold a span. Checked in the constructor; arrays are
/// still mutable afterwards, so a caller can break the rules later (Bayan: <c>requires</c> on a span).</summary>
public sealed record Policy
{
    public Currency Currency { get; }
    public BasisPoints TaxRate { get; }
    public Promotion[] Promotions { get; }
    public ShippingBand[] Bands { get; }

    public Policy(Currency currency, BasisPoints taxRate, Promotion[] promotions, ShippingBand[] bands)
    {
        foreach (var p in promotions)
            if (!IsPricedIn(p, currency)) throw new ArgumentException($"promotion {p} is not in {currency.Code()}", nameof(promotions));
        for (int i = 0; i < bands.Length; i++)
        {
            if (bands[i].Fee.Currency != currency) throw new ArgumentException($"band {i} is not in {currency.Code()}", nameof(bands));
            if (i > 0 && bands[i].UpTo < bands[i - 1].UpTo) throw new ArgumentException("bands must ascend", nameof(bands));
        }
        (Currency, TaxRate, Promotions, Bands) = (currency, taxRate, promotions, bands);
    }

    static bool IsPricedIn(Promotion p, Currency c) => p switch
    {
        PercentOff x => x.Minimum.Currency == c,
        BuyGetFree => true,
        FreeShippingOver x => x.Threshold.Currency == c,
        _ => false,
    };
}

public readonly record struct Quote(Money Subtotal, Money Discount, Money Shipping, Money Tax)
{
    public Money Total => Subtotal - Discount + Shipping + Tax;
}

public sealed class OverweightException(Grams weight) : Exception($"no shipping band for {weight}")
{
    public Grams Weight { get; } = weight;
}

public static class Pricing
{
    /// <summary>Prices a basket. Nothing in the signature says it's pure; callers have to trust the docs.</summary>
    public static Quote Price(ReadOnlySpan<PriceLine> lines, Policy policy)
    {
        var subtotal = Money.Zero(policy.Currency);
        var weight = new Grams(0);
        foreach (ref readonly var line in lines)
        {
            subtotal = subtotal.Add(line.UnitPrice * line.Qty);
            weight += line.UnitWeight * line.Qty;
        }
        var discount = BestDiscount(subtotal, lines, policy);

        bool freeShipping = false;
        foreach (var promo in policy.Promotions)          // no LINQ: it would allocate a closure
            if (promo is FreeShippingOver f && subtotal.Cents >= f.Threshold.Cents) freeShipping = true;

        var fee = ShippingFee(weight, policy);                 // overweight fails even when shipping is free
        var shipping = freeShipping ? Money.Zero(policy.Currency) : fee;
        var tax = (subtotal - discount + shipping).Times(policy.TaxRate);
        return new Quote(subtotal, discount, shipping, tax);
    }

    static Money BestDiscount(Money subtotal, ReadOnlySpan<PriceLine> lines, Policy policy)
    {
        var best = Money.Zero(subtotal.Currency);
        foreach (var promo in policy.Promotions)
        {
            var amount = promo switch
            {
                PercentOff p => subtotal.Cents < p.Minimum.Cents || !subtotal.TryTimes(p.Rate, out var off) ? Money.Zero(subtotal.Currency) : off,
                BuyGetFree p => FreeUnits(p, lines, subtotal.Currency),
                FreeShippingOver => Money.Zero(subtotal.Currency),
                _ => throw new InvalidOperationException("unknown promotion"),   // not exhaustive
            };
            if (amount.Cents > best.Cents) best = amount;
        }
        return best;
    }

    static Money FreeUnits(BuyGetFree p, ReadOnlySpan<PriceLine> lines, Currency currency)
    {
        foreach (ref readonly var line in lines)
            if (line.Key == p.Key)
                return line.UnitPrice * (line.Qty / (p.Buy + p.Free) * p.Free);
        return Money.Zero(currency);
    }

    static Money ShippingFee(Grams weight, Policy policy)
    {
        foreach (var band in policy.Bands)
            if (weight <= band.UpTo) return band.Fee;
        throw new OverweightException(weight);
    }
}
