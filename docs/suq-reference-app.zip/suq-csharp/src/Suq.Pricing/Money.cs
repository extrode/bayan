using System.Diagnostics.CodeAnalysis;

namespace Suq.Pricing;

public enum Currency { Myr, Sgd, Usd }

public static class CurrencyExtensions
{
    public static string Code(this Currency c) => c switch
    {
        Currency.Myr => "MYR",
        Currency.Sgd => "SGD",
        Currency.Usd => "USD",
        _ => throw new ArgumentOutOfRangeException(nameof(c)),   // enums are open in C#
    };

    public static bool TryParseCode(string text, out Currency currency)
    {
        switch (text)
        {
            case "MYR": currency = Currency.Myr; return true;
            case "SGD": currency = Currency.Sgd; return true;
            case "USD": currency = Currency.Usd; return true;
            default: currency = default; return false;
        }
    }
}

public enum PricingErrorKind { CurrencyMismatch, Overflow }

public sealed class PricingException(PricingErrorKind kind, string message) : Exception(message)
{
    public PricingErrorKind Kind { get; } = kind;
}

/// <summary>An amount in minor units of one currency.</summary>
public readonly record struct Money(long Cents, Currency Currency) : ISpanFormattable
{
    public static Money Zero(Currency currency) => new(0, currency);

    public Money Add(Money other)
    {
        if (other.Currency != Currency)
            throw new PricingException(PricingErrorKind.CurrencyMismatch, $"expected {Currency.Code()}, got {other.Currency.Code()}");
        try { return new(checked(Cents + other.Cents), Currency); }
        catch (OverflowException) { throw new PricingException(PricingErrorKind.Overflow, "overflow"); }
    }

    public bool TryAdd(Money other, out Money sum)
    {
        if (other.Currency != Currency) { sum = default; return false; }
        long cents;
        try { cents = checked(Cents + other.Cents); }
        catch (OverflowException) { sum = default; return false; }
        sum = new(cents, Currency);
        return true;
    }

    public static Money operator +(Money a, Money b)
    {
        if (a.Currency != b.Currency) throw new InvalidOperationException("mixed currencies");
        return new(checked(a.Cents + b.Cents), a.Currency);
    }

    public static Money operator -(Money a, Money b)
    {
        if (a.Currency != b.Currency) throw new InvalidOperationException("mixed currencies");
        return new(checked(a.Cents - b.Cents), a.Currency);
    }

    public static Money operator *(Money a, int qty) => new(checked(a.Cents * qty), a.Currency);

    /// <summary>This amount at a rate, rounded half up. For non-negative amounts.</summary>
    public Money Times(BasisPoints rate)
    {
        try { return new(checked(Cents * rate.Value + 5000) / 10000, Currency); }   // the +5000 can overflow too
        catch (OverflowException) { throw new PricingException(PricingErrorKind.Overflow, "overflow"); }
    }

    public bool TryTimes(BasisPoints rate, out Money result)
    {
        try { result = Times(rate); return true; }
        catch (PricingException) { result = default; return false; }
    }

    public bool TryFormat(Span<char> destination, out int written, ReadOnlySpan<char> format, IFormatProvider? provider)
    {
        long whole = Math.Abs(Cents);
        return destination.TryWrite($"{Currency.Code()} {(Cents < 0 ? "-" : "")}{whole / 100}.{whole % 100:00}", out written);
    }

    public string ToString([StringSyntax(StringSyntaxAttribute.NumericFormat)] string? format, IFormatProvider? provider) => ToString();

    public override string ToString()
    {
        Span<char> buf = stackalloc char[32];
        return TryFormat(buf, out int n, default, null) ? new string(buf[..n]) : "?";
    }
}
