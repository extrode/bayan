namespace Suq.Pricing;

/// <summary>Mass in grams. Every operator is written by hand; C# has no units of measure.</summary>
public readonly record struct Grams(long Value) : IComparable<Grams>
{
    public static Grams operator +(Grams a, Grams b) => new(checked(a.Value + b.Value));
    public static Grams operator -(Grams a, Grams b) => new(checked(a.Value - b.Value));
    public static Grams operator *(Grams a, int qty) => new(checked(a.Value * qty));
    public static Grams operator *(int qty, Grams a) => new(checked(a.Value * qty));
    public static bool operator <(Grams a, Grams b) => a.Value < b.Value;
    public static bool operator >(Grams a, Grams b) => a.Value > b.Value;
    public static bool operator <=(Grams a, Grams b) => a.Value <= b.Value;
    public static bool operator >=(Grams a, Grams b) => a.Value >= b.Value;
    public int CompareTo(Grams other) => Value.CompareTo(other.Value);

    /// <summary>Saturating subtraction, the equivalent of Bayan's <c>-|</c>.</summary>
    public Grams SaturatingMinus(Grams b) => new(Math.Max(0, Value - b.Value));

    public override string ToString() => $"{Value} g";
}

/// <summary>Converts implicitly to <see cref="Grams"/>, never back (mirrors Bayan's finer-unit rule).</summary>
public readonly record struct Kilograms(long Value)
{
    public static implicit operator Grams(Kilograms kg) => new(checked(kg.Value * 1000));
}

/// <summary>A rate in hundredths of a percent.</summary>
public readonly record struct BasisPoints(long Value)
{
    public static BasisPoints Percent(long pct) => new(checked(pct * 100));
}

public static class UnitLiterals
{
    public static Grams G(long v) => new(v);
    public static Grams Kg(long v) => new Kilograms(v);
    public static BasisPoints Pct(long v) => BasisPoints.Percent(v);
}
