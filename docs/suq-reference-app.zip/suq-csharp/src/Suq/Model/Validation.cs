namespace Suq.Model;

/// <summary>One broken rule. Bayan derives these from <c>requires</c>; here every rule is written twice
/// (once as a check, once as metadata for the client) or not exposed at all.</summary>
public readonly record struct Violation(string Field, string Rule);

public sealed class ViolationsException(IReadOnlyList<Violation> violations) : Exception("validation failed")
{
    public IReadOnlyList<Violation> Violations { get; } = violations;
}

internal sealed class Rules
{
    readonly List<Violation> _found = [];
    public void Check(bool ok, string field, string rule) { if (!ok) _found.Add(new(field, rule)); }
    public void ThrowIfAny() { if (_found.Count > 0) throw new ViolationsException(_found); }
}
