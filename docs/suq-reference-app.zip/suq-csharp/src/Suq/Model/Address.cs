using System.Text.Json.Serialization;

namespace Suq.Model;

[JsonConverter(typeof(JsonStringEnumConverter<MalaysianState>))]
public enum MalaysianState
{
    Johor, Kedah, Kelantan, Melaka, NegeriSembilan, Pahang, Penang, Perak, Perlis,
    Sabah, Sarawak, Selangor, Terengganu, KualaLumpur, Labuan, Putrajaya,
}

public sealed record Address
{
    public required string Name { get; init; }
    public required string Line1 { get; init; }
    public string? Line2 { get; init; }
    public required string City { get; init; }
    public required MalaysianState State { get; init; }
    public required Postcode Postcode { get; init; }

    /// <summary>Must be called after every construction and every <c>with</c>; nothing enforces that.</summary>
    public Address Validated()
    {
        var r = new Rules();
        r.Check(Shapes.RuneCount(Name) is >= 1 and <= 80, nameof(Name), "length 1..80");
        r.Check(Shapes.RuneCount(Line1) is >= 1 and <= 120, nameof(Line1), "length 1..120");
        r.Check(Line2 is null || Shapes.RuneCount(Line2) <= 120, nameof(Line2), "length ..120");
        r.Check(Shapes.RuneCount(City) is >= 1 and <= 60, nameof(City), "length 1..60");
        r.Check(State is not (MalaysianState.Sabah or MalaysianState.Sarawak or MalaysianState.Labuan)
            || Postcode.Value.StartsWith('8') || Postcode.Value.StartsWith('9'), nameof(Postcode), "east Malaysia 8xxxx/9xxxx");
        r.ThrowIfAny();
        return this;
    }
}

/// <summary>Hand-written twin of <see cref="Address"/> with every field optional (Bayan: <c>Address.Patch</c>).</summary>
public sealed record AddressPatch
{
    public string? Name { get; init; }
    public string? Line1 { get; init; }
    public string? Line2 { get; init; }
    public string? City { get; init; }
    public MalaysianState? State { get; init; }
    public string? Postcode { get; init; }

    public Address Complete()
    {
        var r = new Rules();
        r.Check(Name is not null, nameof(Name), "required");
        r.Check(Line1 is not null, nameof(Line1), "required");
        r.Check(City is not null, nameof(City), "required");
        r.Check(State is not null, nameof(State), "required");
        r.Check(Postcode is not null && Model.Postcode.TryCreate(Postcode, out _), nameof(Postcode), "5 digits");
        r.ThrowIfAny();
        return new Address { Name = Name!, Line1 = Line1!, Line2 = Line2, City = City!, State = State!.Value, Postcode = new Postcode(Postcode!) }.Validated();
    }
}
