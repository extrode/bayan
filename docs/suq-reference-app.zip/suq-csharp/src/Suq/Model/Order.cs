using System.Text.Json.Serialization;
using Suq.Pricing;

namespace Suq.Model;

[JsonConverter(typeof(JsonStringEnumConverter<LineStatus>))]
public enum LineStatus { Active, Removed, Backordered }

public sealed record Line
{
    public required Sku Sku { get; init; }
    public required int Qty { get; init; }
    public required Money UnitPrice { get; init; }
    public required Grams UnitWeight { get; init; }
    public LineStatus Status { get; init; } = LineStatus.Active;

    public Money Amount => UnitPrice * Qty;
    public Grams Weight => UnitWeight * Qty;
    public bool IsInactive => Status is LineStatus.Removed or LineStatus.Backordered;
    public PriceLine ToPriceLine() => new(Sku.Value, Qty, UnitPrice, UnitWeight);

    public Line Validated()
    {
        var r = new Rules();
        r.Check(Qty is >= 1 and <= 999, nameof(Qty), "1..999");
        r.Check(UnitWeight > new Grams(0), nameof(UnitWeight), "> 0 g");
        r.ThrowIfAny();
        return this;
    }
}

public enum BasketErrorKind { Empty, TooManyLines }

public sealed class BasketException(BasketErrorKind kind) : Exception(kind.ToString())
{
    public BasketErrorKind Kind { get; } = kind;
}

// One record per state. Payload lives on the state, but nothing stops code reading
// `order.State` as the wrong type: every access is a runtime cast or a pattern.
public abstract record OrderState
{
    public sealed record Draft : OrderState;
    public sealed record Placed : OrderState;
    public sealed record Paid(PaymentId Payment) : OrderState;
    public sealed record Shipped(PaymentId Payment, TrackingId Tracking) : OrderState;
    public sealed record Cancelled(string Reason) : OrderState;

    public string Name => this switch
    {
        Draft => "draft", Placed => "placed", Paid => "paid", Shipped => "shipped", Cancelled => "cancelled",
        _ => throw new InvalidOperationException(),
    };
}

public sealed class Order
{
    public const int MaxLines = 200;

    public required OrderId Id { get; init; }
    public required CustomerId Customer { get; init; }
    public required Currency Currency { get; init; }
    public List<Line> Lines { get; init; } = [];
    public OrderState State { get; private set; } = new OrderState.Draft();

    /// <summary>Restores an order loaded from storage in any state.</summary>
    public static Order Restore(OrderId id, CustomerId customer, Currency currency, List<Line> lines, OrderState state) =>
        new() { Id = id, Customer = customer, Currency = currency, Lines = lines, State = state };

    public Money Total
    {
        get
        {
            var sum = Money.Zero(Currency);
            foreach (var line in Lines) if (!line.IsInactive) sum += line.Amount;
            return sum;
        }
    }

    public Grams Weight
    {
        get
        {
            var sum = new Grams(0);
            foreach (var line in Lines) if (!line.IsInactive) sum += line.Weight;
            return sum;
        }
    }

    public string StatusLabel => State switch
    {
        OrderState.Draft => "Draft",
        OrderState.Placed => "Awaiting payment",
        OrderState.Paid => "Paid",
        OrderState.Shipped => "On its way",
        OrderState.Cancelled => "Cancelled",
        _ => throw new InvalidOperationException("unknown state"),   // adding a state compiles fine
    };

    public TrackingId Tracking => State is OrderState.Shipped s ? s.Tracking : throw new InvalidOperationException("not shipped");
    public PaymentId Payment => State switch
    {
        OrderState.Paid p => p.Payment,
        OrderState.Shipped s => s.Payment,
        _ => throw new InvalidOperationException("not paid"),
    };

    public void AddLine(Line line)
    {
        Require<OrderState.Draft>();
        if (Lines.Count >= MaxLines) throw new BasketException(BasketErrorKind.TooManyLines);
        if (line.UnitPrice.Currency != Currency)
            throw new PricingException(PricingErrorKind.CurrencyMismatch, $"expected {Currency.Code()}");
        Lines.Add(line.Validated());
    }

    public void RemoveLine(Sku sku)
    {
        if (State is not (OrderState.Draft or OrderState.Placed)) throw new InvalidOperationException($"cannot remove lines when {State.Name}");
        for (int i = 0; i < Lines.Count; i++)
            if (Lines[i].Sku == sku) Lines[i] = Lines[i] with { Status = LineStatus.Removed };
    }

    public void Place()
    {
        Require<OrderState.Draft>();
        if (!Lines.Exists(l => !l.IsInactive)) throw new BasketException(BasketErrorKind.Empty);
        State = new OrderState.Placed();
    }

    public void MarkPaid(PaymentId payment)
    {
        Require<OrderState.Placed>();
        State = new OrderState.Paid(payment);
    }

    public void MarkShipped(TrackingId tracking)
    {
        var paid = Require<OrderState.Paid>();
        State = new OrderState.Shipped(paid.Payment, tracking);
    }

    public void Cancel(string reason)
    {
        if (State is not (OrderState.Draft or OrderState.Placed)) throw new InvalidOperationException($"cannot cancel when {State.Name}");
        State = new OrderState.Cancelled(reason);
    }

    T Require<T>() where T : OrderState =>
        State as T ?? throw new InvalidOperationException($"order {Id} is {State.Name}, expected {typeof(T).Name.ToLowerInvariant()}");
}
