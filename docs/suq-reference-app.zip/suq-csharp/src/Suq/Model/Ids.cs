using System.Diagnostics.CodeAnalysis;
using System.Text.RegularExpressions;

namespace Suq.Model;

/// <summary>Thrown by constructors of validated types. Bayan: a <c>requires</c> clause.</summary>
public sealed class ValidationException(string field, string rule) : Exception($"{field}: {rule}")
{
    public string Field { get; } = field;
    public string Rule { get; } = rule;
}

public static partial class Shapes
{
    [GeneratedRegex("^[A-Z]{3}-[0-9]{4}$")]
    public static partial Regex Sku();

    public static bool IsAsciiAlphanumeric(string s) { foreach (var c in s) if (!char.IsAsciiLetterOrDigit(c)) return false; return true; }
    public static bool IsAsciiDigits(string s) { foreach (var c in s) if (!char.IsAsciiDigit(c)) return false; return true; }
    public static bool IsAsciiPrintable(string s) { foreach (var c in s) if (c < 0x20 || c > 0x7e) return false; return true; }
    public static bool IsEmailShaped(string s) { int at = s.IndexOf('@'); return at > 0 && s.IndexOf('.', at) > at + 1 && !s.EndsWith('.'); }
    public static int RuneCount(string s) { int n = 0; foreach (var _ in s.EnumerateRunes()) n++; return n; }
}

// Each validated type repeats the same shape: constructor check, TryCreate, a value.
// `default(Sku)` still bypasses the check — C# structs always have a zero value.

public readonly record struct Sku
{
    public string Value { get; }
    public Sku(string value) { if (!Shapes.Sku().IsMatch(value)) throw new ValidationException(nameof(Sku), "shape"); Value = value; }
    public static bool TryCreate(string? s, [NotNullWhen(true)] out Sku? sku) { sku = s is not null && Shapes.Sku().IsMatch(s) ? new Sku(s) : null; return sku is not null; }
    public override string ToString() => Value;
}

public readonly record struct OrderId
{
    public long Value { get; }
    public OrderId(long value) { if (value <= 0) throw new ValidationException(nameof(OrderId), "> 0"); Value = value; }
    public static bool TryParse(string? s, [NotNullWhen(true)] out OrderId? id) { id = long.TryParse(s, out var v) && v > 0 ? new OrderId(v) : null; return id is not null; }
    public override string ToString() => Value.ToString();
}

public readonly record struct CustomerId
{
    public long Value { get; }
    public CustomerId(long value) { if (value <= 0) throw new ValidationException(nameof(CustomerId), "> 0"); Value = value; }
    public override string ToString() => Value.ToString();
}

public readonly record struct PaymentId
{
    public string Value { get; }
    public PaymentId(string value) { if (value.Length is < 1 or > 64 || !Shapes.IsAsciiPrintable(value)) throw new ValidationException(nameof(PaymentId), "1..64 printable"); Value = value; }
    public override string ToString() => Value;
}

public readonly record struct TrackingId
{
    public string Value { get; }
    public TrackingId(string value) { if (value.Length is < 8 or > 40 || !Shapes.IsAsciiAlphanumeric(value)) throw new ValidationException(nameof(TrackingId), "8..40 alphanumeric"); Value = value; }
    public override string ToString() => Value;
}

public readonly record struct CardToken
{
    public string Value { get; }
    public CardToken(string value) { if (!value.StartsWith("tok_", StringComparison.Ordinal) || value.Length is < 8 or > 64) throw new ValidationException(nameof(CardToken), "tok_…"); Value = value; }
}

public readonly record struct Email
{
    public string Value { get; }
    public Email(string value) { if (value.Length > 254 || !Shapes.IsEmailShaped(value)) throw new ValidationException(nameof(Email), "email"); Value = value; }
}

public readonly record struct Postcode
{
    public string Value { get; }
    public Postcode(string value) { if (!IsValid(value)) throw new ValidationException(nameof(Postcode), "5 digits"); Value = value; }
    static bool IsValid(string s) => s.Length == 5 && Shapes.IsAsciiDigits(s);
    public static bool TryCreate(string? s, [NotNullWhen(true)] out Postcode? p) { p = s is not null && IsValid(s) ? new Postcode(s) : null; return p is not null; }
}

public readonly record struct PageSize
{
    public int Value { get; }
    public PageSize(int value) { if (value is < 1 or > 100) throw new ValidationException(nameof(PageSize), "1..100"); Value = value; }
    public static bool TryParse(string? s, [NotNullWhen(true)] out PageSize? size) { size = int.TryParse(s, out var v) && v is >= 1 and <= 100 ? new PageSize(v) : null; return size is not null; }
}
