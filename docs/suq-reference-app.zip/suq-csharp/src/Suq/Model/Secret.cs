namespace Suq.Model;

/// <summary>Prints as *** . Serializers still see <see cref="Expose"/> if someone maps it — unlike Bayan,
/// nothing stops a DTO copying the value out.</summary>
public readonly struct Secret<T>(T value)
{
    public T Expose() => value;
    public override string ToString() => "***";
}
