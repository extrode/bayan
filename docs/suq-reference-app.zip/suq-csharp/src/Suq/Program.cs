using Npgsql;
using Suq;
using Suq.Carrier;
using Suq.Db;
using Suq.Model;
using Suq.Payments;
using Suq.Pricing;
using Suq.Storefront;
using Suq.Warehouse;
using static Suq.Pricing.UnitLiterals;

AppDomain.CurrentDomain.UnhandledException += (_, e) => Console.Error.WriteLine(e.ExceptionObject);

var builder = WebApplication.CreateSlimBuilder(args);
builder.Services.ConfigureHttpJsonOptions(o => o.SerializerOptions.TypeInfoResolverChain.Insert(0, SuqJson.Default));

string Env(string name) => Environment.GetEnvironmentVariable($"SUQ_{name}") ?? throw new InvalidOperationException($"SUQ_{name} is not set");
var databaseUrl = new Secret<string>(Env("DATABASE_URL"));

var malaysia = new Policy(Currency.Myr, Pct(8),
    [new FreeShippingOver(new Money(15000, Currency.Myr)), new PercentOff(Pct(10), new Money(30000, Currency.Myr))],
    [new(Kg(1), new Money(800, Currency.Myr)), new(Kg(5), new Money(1500, Currency.Myr)), new(Kg(20), new Money(3500, Currency.Myr))]);

var db = new NpgsqlSlimDataSourceBuilder(databaseUrl.Expose()).Build();
var http = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
builder.Services.AddSingleton(db);
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddSingleton<OrdersStore>();
builder.Services.AddSingleton<DraftStore>();
builder.Services.AddSingleton<Outbox>();
builder.Services.AddSingleton<ISessions, CookieSessions>();
builder.Services.AddSingleton(malaysia);
builder.Services.AddSingleton<IReadOnlyDictionary<Sku, ShelfSlot>>(new Dictionary<Sku, ShelfSlot>());
builder.Services.AddSingleton<IShipper>(new LajuExpress(http, new Uri(Env("COURIER_URL")), new Secret<string>(Env("COURIER_KEY"))));
builder.Services.AddSingleton(new Gateway(http, new Uri(Env("GATEWAY_URL")), new Secret<string>(Env("GATEWAY_KEY")),
    SecretKey.Load(Convert.FromHexString(Env("WEBHOOK_KEY")))));
builder.Services.AddSingleton<Storefront>();
builder.Services.AddHostedService<OutboxSweeper>();

var app = builder.Build();
app.Logger.LogInformation("starting, database {Url}", databaseUrl);   // prints *** only because Secret overrides ToString

app.MapGet("/products", Catalog.Search);
app.MapGet("/search", (string? q) => Catalog.SearchPage(q));
app.MapPost("/signup", Accounts.SignUp);
app.MapPut("/orders/{id}/address", (string id, AddressPatchDto patch, HttpRequest req, Storefront s, CancellationToken ct) => s.SaveAddress(id, patch, req, ct));
app.MapPost("/orders/{id}/pay", (string id, PayRequest body, HttpRequest req, Storefront s, CancellationToken ct) => s.Pay(id, body, req, ct));
app.MapGet("/orders/{id}/track", (string id, HttpRequest req, Storefront s, CancellationToken ct) => s.Track(id, req, ct));
app.MapGet("/orders/{id}", (string id, HttpRequest req, Storefront s, CancellationToken ct) => s.OrderPage(id, req, ct));
app.MapPost("/webhooks/payments", (HttpRequest req, Storefront s, CancellationToken ct) => s.PaymentWebhook(req, ct));
app.Run($"http://0.0.0.0:{Environment.GetEnvironmentVariable("SUQ_PORT") ?? "8080"}");

sealed class CookieSessions(NpgsqlDataSource db) : ISessions
{
    public async Task<CustomerId?> IdentifyAsync(HttpRequest req, CancellationToken ct)
    {
        if (!req.Cookies.TryGetValue("suq_session", out var token)) return null;
        await using var cmd = db.CreateCommand("select customer_id from sessions where token = $1 and expires_at > now()");
        cmd.Parameters.Add(new NpgsqlParameter<string> { TypedValue = token });
        try { return await cmd.ExecuteScalarAsync(ct) is long id && id > 0 ? new CustomerId(id) : null; }
        catch (NpgsqlException) { return null; }
    }
}
