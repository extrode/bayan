using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Suq.Model;
using Suq.Pricing;

namespace Suq.Payments;

public enum PaymentErrorKind { Declined, Unavailable, MalformedReply }

public sealed class PaymentException(PaymentErrorKind kind, string? code = null) : Exception(kind.ToString())
{
    public PaymentErrorKind Kind { get; } = kind;
    public string? Code { get; } = code;
}

[JsonConverter(typeof(JsonStringEnumConverter<ChargeStatus>))]
public enum ChargeStatus { Succeeded, Declined }

public sealed record ChargeRequest(long AmountCents, string Currency, string Source, string IdempotencyKey);
public sealed record ChargeReply(string Id, ChargeStatus Status);

[JsonConverter(typeof(JsonStringEnumConverter<PaymentEventKind>))]
public enum PaymentEventKind { Refunded, Chargeback }
public sealed record PaymentEvent(string Payment, PaymentEventKind Kind);

public sealed class Gateway(HttpClient http, Uri baseUri, Secret<string> apiKey, SecretKey webhookKey)
{
    public SecretKey WebhookKey => webhookKey;

    public async Task<PaymentId> ChargeAsync(Money amount, CardToken card, OrderId order, CancellationToken ct)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, new Uri(baseUri, "/v1/charges"))
        {
            Content = JsonContent.Create(new ChargeRequest(amount.Cents, amount.Currency.Code(), card.Value, $"order-{order.Value}"), SuqJson.Default.ChargeRequest),
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", apiKey.Expose());
        HttpResponseMessage response;
        try { response = await http.SendAsync(request, ct); }
        catch (HttpRequestException) { throw new PaymentException(PaymentErrorKind.Unavailable); }
        using (response)
        {
            if ((int)response.StatusCode >= 500) throw new PaymentException(PaymentErrorKind.Unavailable);
            ChargeReply? reply;
            try { reply = await response.Content.ReadFromJsonAsync(SuqJson.Default.ChargeReply, ct); }
            catch (JsonException) { throw new PaymentException(PaymentErrorKind.MalformedReply); }
            if (reply is null) throw new PaymentException(PaymentErrorKind.MalformedReply);
            if (reply.Status == ChargeStatus.Declined)
                throw new PaymentException(PaymentErrorKind.Declined,
                    response.Headers.TryGetValues("x-decline-code", out var v) ? v.FirstOrDefault() : "unknown");
            try { return new PaymentId(reply.Id); }
            catch (ValidationException) { throw new PaymentException(PaymentErrorKind.MalformedReply); }
        }
    }

    public static PaymentEvent ReadWebhook(Webhook hook, SecretKey key)
    {
        if (!hook.IsAuthentic(key)) throw new UnauthorizedAccessException("forged webhook");
        var e = JsonSerializer.Deserialize(hook.Body.Span, SuqJson.Default.PaymentEvent) ?? throw new JsonException("empty");
        _ = new PaymentId(e.Payment);   // validate; easy to forget
        return e;
    }
}
