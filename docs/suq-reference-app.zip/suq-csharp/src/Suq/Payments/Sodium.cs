using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace Suq.Payments;

internal static partial class Native
{
    const string Lib = "libsodium";
    [LibraryImport(Lib)] internal static partial int sodium_init();
    [LibraryImport(Lib)] internal static partial nint sodium_malloc(nuint size);
    [LibraryImport(Lib)] internal static partial void sodium_free(nint ptr);
    [LibraryImport(Lib)] internal static unsafe partial int crypto_auth_hmacsha256_verify(byte* tag, byte* msg, ulong len, byte* key);
    [LibraryImport(Lib)] internal static unsafe partial int crypto_pwhash_str(byte* output, byte* pass, ulong len, ulong ops, nuint mem);
}

/// <summary>A key in guarded memory. Disposal frees and wipes it — if the caller remembers to dispose;
/// copying the reference gives two owners (Bayan: <c>struct unique</c>).</summary>
public sealed class SecretKey : SafeHandle
{
    public const int Length = 32;
    SecretKey() : base(0, ownsHandle: true) { }
    public override bool IsInvalid => handle == 0;
    protected override bool ReleaseHandle() { Native.sodium_free(handle); return true; }

    public static unsafe SecretKey Load(ReadOnlySpan<byte> bytes)
    {
        if (bytes.Length != Length) throw new ArgumentException($"expected {Length} bytes, got {bytes.Length}");
        if (Native.sodium_init() < 0) throw new InvalidOperationException("sodium_init failed");
        var key = new SecretKey();
        key.SetHandle(Native.sodium_malloc(Length));
        if (key.IsInvalid) throw new OutOfMemoryException();
        bytes.CopyTo(new Span<byte>((void*)key.handle, Length));
        return key;
    }

    internal unsafe byte* Pointer => (byte*)handle;
}

public readonly record struct Webhook(ReadOnlyMemory<byte> Body, ReadOnlyMemory<byte> Tag)
{
    public unsafe bool IsAuthentic(SecretKey key)
    {
        if (Tag.Length != 32) return false;
        bool added = false;
        key.DangerousAddRef(ref added);
        try
        {
            fixed (byte* tag = Tag.Span)
            fixed (byte* msg = Body.Span)
                return Native.crypto_auth_hmacsha256_verify(tag, msg, (ulong)Body.Length, key.Pointer) == 0;
        }
        finally { if (added) key.DangerousRelease(); }
    }
}

public static class Passwords
{
    public static unsafe string Hash(string password)
    {
        if (Native.sodium_init() < 0) throw new InvalidOperationException("sodium_init failed");
        Span<byte> output = stackalloc byte[128];
        byte[] pass = System.Text.Encoding.UTF8.GetBytes(password);
        try
        {
            fixed (byte* o = output)
            fixed (byte* p = pass)
                if (Native.crypto_pwhash_str(o, p, (ulong)pass.Length, 2, 64 * 1024 * 1024) != 0)
                    throw new InvalidOperationException("hashing failed");
            return System.Text.Encoding.ASCII.GetString(output[..output.IndexOf((byte)0)]);
        }
        finally { CryptographicOperations.ZeroMemory(pass); }
    }
}
