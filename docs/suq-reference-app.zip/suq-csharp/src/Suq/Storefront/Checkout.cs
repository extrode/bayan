using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using Npgsql;
using Suq.Carrier;
using Suq.Db;
using Suq.Model;
using Suq.Payments;
using Suq.Pricing;
using Suq.Warehouse;

namespace Suq.Storefront;

public interface ISessions
{
    Task<CustomerId?> IdentifyAsync(HttpRequest req, CancellationToken ct);
}

public sealed class DraftStore(NpgsqlDataSource db)
{
    public async Task SaveAsync(AddressPatchDto patch, OrderId order, CancellationToken ct)
    {
        await using var cmd = db.CreateCommand("""
            insert into address_drafts (order_id, patch) values ($1, $2::jsonb)
            on conflict (order_id) do update set patch = excluded.patch
            """);
        cmd.Parameters.Add(new NpgsqlParameter<long> { TypedValue = order.Value });
        cmd.Parameters.Add(new NpgsqlParameter<string> { TypedValue = JsonSerializer.Serialize(patch, SuqJson.Default.AddressPatchDto) });
        await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task<AddressPatchDto?> LoadAsync(OrderId order, CancellationToken ct)
    {
        await using var cmd = db.CreateCommand("select patch::text from address_drafts where order_id = $1");
        cmd.Parameters.Add(new NpgsqlParameter<long> { TypedValue = order.Value });
        return await cmd.ExecuteScalarAsync(ct) is string json ? JsonSerializer.Deserialize(json, SuqJson.Default.AddressPatchDto) : null;
    }
}

public sealed class Storefront(
    OrdersStore orders, DraftStore drafts, ISessions sessions, Gateway gateway, IShipper shipper,
    Outbox outbox, Policy policy, IReadOnlyDictionary<Sku, ShelfSlot> slots, TimeProvider clock, ILogger<Storefront> log)
{
    static readonly HashSet<string> CourierHosts = ["track.laju.example"];

    /// <summary>The order, only if the session's customer owns it; someone else's order is "not found".</summary>
    async Task<Order?> LoadOwnOrderAsync(string id, HttpRequest req, CancellationToken ct)
    {
        if (await sessions.IdentifyAsync(req, ct) is not { } customer) return null;
        if (!OrderId.TryParse(id, out var orderId)) return null;
        var order = await orders.FindAsync(orderId.Value, ct);
        return order is not null && order.Customer == customer ? order : null;
    }

    public async Task<IResult> SaveAddress(string id, AddressPatchDto patch, HttpRequest req, CancellationToken ct)
    {
        Order? order;
        try { order = await LoadOwnOrderAsync(id, req, ct); }
        catch (Exception e) when (e is NpgsqlException or CorruptRowException) { return Results.StatusCode(503); }
        if (order is null) return Results.NotFound();
        try { await drafts.SaveAsync(patch, order.Id, ct); }
        catch (NpgsqlException) { return Results.StatusCode(503); }
        return Results.NoContent();
    }

    public async Task<IResult> Pay(string id, PayRequest body, HttpRequest req, CancellationToken ct)
    {
        CardToken card;
        try { card = new CardToken(body.Card ?? ""); }
        catch (ValidationException) { return Results.BadRequest(); }

        Order? order;
        try { order = await LoadOwnOrderAsync(id, req, ct); }
        catch (Exception e) when (e is NpgsqlException or CorruptRowException) { return Results.StatusCode(503); }
        if (order is null) return Results.NotFound();
        var orderId = (OrderId?)order.Id;
        if (order.State is not OrderState.Placed) return Results.Conflict(new Dictionary<string, string> { ["state"] = order.StatusLabel });

        AddressPatchDto? draft;
        try { draft = await drafts.LoadAsync(orderId.Value, ct); }
        catch (Exception e) when (e is NpgsqlException or JsonException) { return Results.StatusCode(503); }
        if (draft is null) return Results.UnprocessableEntity(new Dictionary<string, string> { ["address"] = "missing" });
        Address address;
        try { address = draft.ToPatch().Complete(); }
        catch (ViolationsException e) { return Results.UnprocessableEntity(e.Violations); }

        // Charge what the customer was shown: the quote, with discount, shipping and tax.
        Quote quote;
        try { quote = Pricing.Pricing.Price(CollectionsMarshal.AsSpan(PriceLines(order)), policy); }
        catch (Exception e) when (e is PricingException or OverweightException)
        {
            return Results.UnprocessableEntity(new Dictionary<string, string> { ["order"] = "cannot be shipped" });
        }
        PaymentId payment;
        try { payment = await gateway.ChargeAsync(quote.Total, card, orderId.Value, ct); }
        catch (PaymentException e) when (e.Kind == PaymentErrorKind.Declined)
        {
            return Results.Json(new Dictionary<string, string> { ["code"] = e.Code ?? "unknown" }, SuqJson.Default.DictionaryStringString, statusCode: 402);
        }
        catch (PaymentException) { return Results.StatusCode(503); }
        order.MarkPaid(payment);
        try { await orders.SaveStateAsync(order, ct); }
        catch (NpgsqlException) { return Results.StatusCode(500); }

        TrackingId tracking;
        try { tracking = await ShipAsync(order, address, ct); }
        catch (Exception e) when (e is CarrierException or TooHeavyException)
        {
            log.LogWarning("order {Id} paid; shipping queued: {Error}", orderId.Value.Value, e.Message);
            return Results.Accepted(value: OrderDto.Of(order));
        }
        order.MarkShipped(tracking);
        try { await orders.SaveStateAsync(order, ct); }
        catch (NpgsqlException) { return Results.StatusCode(500); }
        return Results.Ok(OrderDto.Of(order));
    }

    async Task<TrackingId> ShipAsync(Order order, Address address, CancellationToken ct)
    {
        int units = 0;
        foreach (var l in order.Lines) if (!l.IsInactive) units += l.Qty;
        var items = new PackItem[units];
        Packing.Items(items, order.Lines, slots);
        var plan = new PackPlan(units);
        Packing.Pack(plan, items);

        var parcels = new List<Parcel>(plan.BoxCount);
        for (int b = 0; b < plan.BoxCount; b++) parcels.Add(new Parcel(order.Id, plan.Boxes[b].Name, plan.Load[b]));
        try
        {
            var tracking = await Shipping.BookAllAsync(parcels, shipper, clock, log, ct);
            log.LogInformation("order {Id}: {Count} parcels to {City}", order.Id.Value, parcels.Count, address.City);
            return tracking[0];   // the Shipped state holds one tracking number
        }
        catch (CarrierException)
        {
            foreach (var p in parcels) outbox.Add(new BookWithRetryOp(p, shipper));
            throw;
        }
    }

    public async Task<IResult> Track(string id, HttpRequest req, CancellationToken ct)
    {
        Order? order;
        try { order = await LoadOwnOrderAsync(id, req, ct); }
        catch (Exception e) when (e is NpgsqlException or CorruptRowException) { return Results.StatusCode(503); }
        if (order is null) return Results.NotFound();
        if (order.State is not OrderState.Shipped shipped) return Results.Conflict(new Dictionary<string, string> { ["state"] = order.StatusLabel });
        var url = new Uri($"https://track.laju.example/{Uri.EscapeDataString(shipped.Tracking.Value)}");
        if (!CourierHosts.Contains(url.Host)) return Results.StatusCode(500);
        return Results.Redirect(url.ToString());
    }

    public async Task<IResult> OrderPage(string id, HttpRequest req, CancellationToken ct)
    {
        if (!OrderId.TryParse(id, out var orderId)) return Results.NotFound();
        if (await sessions.IdentifyAsync(req, ct) is not { } customer) return Results.Unauthorized();

        var found = orders.FindAsync(orderId.Value, ct);
        var spend = orders.LifetimeSpendAsync(customer, policy.Currency, ct);
        try { await Task.WhenAll(found, spend); }
        catch (NpgsqlException) { return Results.StatusCode(503); }
        var order = await found;
        if (order is null || order.Customer != customer) return Results.NotFound();

        Quote quote;
        try { quote = Pricing.Pricing.Price(CollectionsMarshal.AsSpan(PriceLines(order)), policy); }
        catch (Exception e) when (e is PricingException or OverweightException) { return Results.StatusCode(500); }

        var html = new StringBuilder()
            .Append("<h1>Order ").Append(order.Id.Value).Append("</h1><p>")
            .Append(System.Net.WebUtility.HtmlEncode(order.StatusLabel))
            .Append("</p><p>Total: ").Append(System.Net.WebUtility.HtmlEncode(quote.Total.ToString()))
            .Append("</p><p>Lifetime: ").Append(System.Net.WebUtility.HtmlEncode((await spend).ToString()))
            .Append("</p>");
        return Results.Content(html.ToString(), "text/html; charset=utf-8");
    }

    static List<PriceLine> PriceLines(Order order)
    {
        var lines = new List<PriceLine>();
        foreach (var l in order.Lines) if (!l.IsInactive) lines.Add(l.ToPriceLine());
        return lines;
    }

    /// <summary>Retries queued bookings and records each success, so an order paid during a
    /// courier outage still ends up shipped.</summary>
    public async Task SweepOutboxAsync(CancellationToken ct)
    {
        foreach (var (parcel, tracking) in await outbox.RetryAsync(ct))
        {
            try { await RecordShipmentAsync(tracking, parcel.Order, ct); }
            catch (Exception e) when (e is NpgsqlException or CorruptRowException)
            {
                log.LogError("order {Id}: booked {Tracking}, not recorded: {Error}", parcel.Order.Value, tracking.Value, e.Message);
            }
        }
    }

    async Task RecordShipmentAsync(TrackingId tracking, OrderId id, CancellationToken ct)
    {
        var order = await orders.FindAsync(id, ct);
        if (order?.State is not OrderState.Paid) return;   // another parcel of the same order got there first
        order.MarkShipped(tracking);
        await orders.SaveStateAsync(order, ct);
    }

    public async Task<IResult> PaymentWebhook(HttpRequest req, CancellationToken ct)
    {
        if (req.ContentLength is null or > 4096) return Results.StatusCode(413);   // before reading or MAC-ing
        var header = req.Headers["x-signature"].ToString();
        byte[] tag;
        try { tag = Convert.FromHexString(header); }
        catch (FormatException) { return Results.Unauthorized(); }
        var body = new byte[req.ContentLength.Value];
        try { await req.Body.ReadExactlyAsync(body, ct); }
        catch (EndOfStreamException) { return Results.BadRequest(); }
        try
        {
            var e = Gateway.ReadWebhook(new Webhook(body, tag), gateway.WebhookKey);
            log.LogInformation("payment {Payment}: {Kind}", e.Payment, e.Kind);
            return Results.NoContent();
        }
        catch (UnauthorizedAccessException) { return Results.Unauthorized(); }
        catch (Exception e) when (e is JsonException or ValidationException) { return Results.BadRequest(); }
    }
}

/// <summary>Runs the outbox sweeper once a minute for the life of the host.</summary>
public sealed class OutboxSweeper(Storefront shop, TimeProvider clock, ILogger<OutboxSweeper> log) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(1), clock);
        while (await timer.WaitForNextTickAsync(ct))
        {
            try { await shop.SweepOutboxAsync(ct); }
            catch (Exception e) when (e is not OperationCanceledException) { log.LogError(e, "outbox sweep failed"); }
        }
    }
}
