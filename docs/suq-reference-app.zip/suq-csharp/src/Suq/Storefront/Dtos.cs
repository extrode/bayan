using System.Text.Json;
using System.Text.Json.Serialization;
using Suq.Carrier;
using Suq.Model;
using Suq.Payments;
using Suq.Pricing;

namespace Suq;

public sealed record SignupForm(string? Email, string? Username, string? Password, int Age);
public sealed record AccountDto(long Id, string Username);
public sealed record ProductDto(string Sku, string Name, string Price, bool InStock);
public sealed record PayRequest(string? Card);
public sealed record OrderDto(long Id, string Status, string Total, List<LineDto> Lines)
{
    public static OrderDto Of(Order o) => new(o.Id.Value, o.StatusLabel, o.Total.ToString(), o.Lines.ConvertAll(LineDto.Of));
}
public sealed record LineDto(string Sku, int Qty, string UnitPrice, LineStatus Status)
{
    public static LineDto Of(Line l) => new(l.Sku.Value, l.Qty, l.UnitPrice.ToString(), l.Status);
}
public sealed record AddressPatchDto(string? Name, string? Line1, string? Line2, string? City, MalaysianState? State, string? Postcode)
{
    public AddressPatch ToPatch() => new() { Name = Name, Line1 = Line1, Line2 = Line2, City = City, State = State, Postcode = Postcode };
}

// NativeAOT needs every serialized type listed here by hand.
[JsonSourceGenerationOptions(JsonSerializerDefaults.Web, MaxDepth = 4)]
[JsonSerializable(typeof(SignupForm))]
[JsonSerializable(typeof(AccountDto))]
[JsonSerializable(typeof(List<ProductDto>))]
[JsonSerializable(typeof(PayRequest))]
[JsonSerializable(typeof(OrderDto))]
[JsonSerializable(typeof(AddressPatchDto))]
[JsonSerializable(typeof(IReadOnlyList<Violation>))]
[JsonSerializable(typeof(Dictionary<string, string>))]
[JsonSerializable(typeof(ParcelDto))]
[JsonSerializable(typeof(BookingReply))]
[JsonSerializable(typeof(ChargeRequest))]
[JsonSerializable(typeof(ChargeReply))]
[JsonSerializable(typeof(PaymentEvent))]
[JsonSerializable(typeof(Quote))]
public sealed partial class SuqJson : JsonSerializerContext;
