using Npgsql;
using Suq.Model;
using Suq.Payments;

namespace Suq.Storefront;

public static class Accounts
{
    /// <summary>Every rule written as code; none of it is visible to a client as data.</summary>
    public static List<Violation> Validate(SignupForm f)
    {
        var v = new List<Violation>();
        bool emailOk = f.Email is not null && f.Email.Length <= 254 && Shapes.IsEmailShaped(f.Email);
        if (!emailOk) v.Add(new("email", "type(Email)"));
        var u = f.Username ?? "";
        if (Shapes.RuneCount(u) is < 3 or > 32) v.Add(new("username", "length(3..32)"));
        if (!Shapes.IsAsciiAlphanumeric(u) || u.Length == 0) v.Add(new("username", "asciiAlphanumeric"));
        var p = f.Password ?? "";
        if (Shapes.RuneCount(p) is < 8 or > 128) v.Add(new("password", "length(8..128)"));
        if (f.Age is < 13 or > 120) v.Add(new("age", "range(13..120)"));
        if (emailOk && p == f.Email) v.Add(new("password", "differs(email)"));
        if (p == u) v.Add(new("password", "differs(username)"));
        return v;
    }

    public static async Task<IResult> SignUp(SignupForm form, NpgsqlDataSource db, ILogger<SignupForm> log, CancellationToken ct)
    {
        var violations = Validate(form);
        if (violations.Count > 0) return Results.UnprocessableEntity(violations);

        var hash = await Task.Run(() => Passwords.Hash(form.Password!), ct);   // CPU-bound: off the request thread
        await using var cmd = db.CreateCommand("""
            insert into users (email, username, password_hash) values ($1, $2, $3) returning id
            """);
        cmd.Parameters.Add(new NpgsqlParameter<string> { TypedValue = form.Email! });
        cmd.Parameters.Add(new NpgsqlParameter<string> { TypedValue = form.Username! });
        cmd.Parameters.Add(new NpgsqlParameter<string> { TypedValue = hash });
        try
        {
            var id = (long)(await cmd.ExecuteScalarAsync(ct))!;
            log.LogInformation("new account {Id}", id);
            return Results.Created($"/accounts/{id}", new AccountDto(id, form.Username!));
        }
        catch (PostgresException e) when (e.SqlState == PostgresErrorCodes.UniqueViolation)
        {
            return Results.Conflict(new Dictionary<string, string> { ["field"] = "email" });
        }
    }
}
