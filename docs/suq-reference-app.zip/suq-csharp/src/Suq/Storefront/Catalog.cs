using System.Net;
using System.Text;
using Npgsql;
using Suq.Model;
using Suq.Pricing;

namespace Suq.Storefront;

public static class Catalog
{
    public static async Task<IResult> Search(string? q, string? limit, NpgsqlDataSource db, CancellationToken ct)
    {
        if (string.IsNullOrEmpty(q) || Shapes.RuneCount(q) > 100) return Results.BadRequest();
        if (!PageSize.TryParse(limit ?? "20", out var size)) return Results.BadRequest();

        await using var cmd = db.CreateCommand("""
            select sku, name, price_cents, currency, stock, discontinued
            from products where name ilike '%' || $1 || '%' escape '!' order by name limit $2
            """);
        // Parameter, not concatenation (which also compiles). `!`, `%` and `_` are escaped so they match literally.
        cmd.Parameters.Add(new NpgsqlParameter<string> { TypedValue = q.Replace("!", "!!").Replace("%", "!%").Replace("_", "!_") });
        cmd.Parameters.Add(new NpgsqlParameter<int> { TypedValue = size.Value.Value });
        var results = new List<ProductDto>(size.Value.Value);
        try
        {
            await using var r = await cmd.ExecuteReaderAsync(ct);
            while (await r.ReadAsync(ct))
            {
                int stock = r.GetInt32(4);
                if (r.GetBoolean(5)) continue;                     // discontinued; out of stock is still listed
                var currency = CurrencyExtensions.TryParseCode(r.GetString(3), out var c) ? c : Currency.Myr;
                results.Add(new ProductDto(r.GetString(0), r.GetString(1), new Money(r.GetInt64(2), currency).ToString(), stock > 0));
            }
        }
        catch (NpgsqlException) { return Results.StatusCode(503); }
        return Results.Ok(results);
    }

    /// <summary>Escaping is the caller's job; leaving out <c>HtmlEncode</c> compiles.</summary>
    public static IResult SearchPage(string? q)
    {
        var html = new StringBuilder("<h1>Results for ").Append(WebUtility.HtmlEncode(q ?? "")).Append("</h1>");
        return Results.Content(html.ToString(), "text/html; charset=utf-8");
    }
}
