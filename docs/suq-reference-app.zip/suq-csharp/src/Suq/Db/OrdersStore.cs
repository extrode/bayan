using Npgsql;
using NpgsqlTypes;
using Suq.Model;
using Suq.Pricing;

namespace Suq.Db;

public sealed class CorruptRowException(string table, long id) : Exception($"corrupt row {table}#{id}");

/// <summary>No row types: column order and names are repeated in every query and reader
/// (Bayan derives <c>Row</c> and <c>copyIn</c> from the struct).</summary>
public sealed class OrdersStore(NpgsqlDataSource db)
{
    public async Task InsertAsync(Order order, CancellationToken ct)
    {
        if (order.State is not OrderState.Placed) throw new InvalidOperationException("only placed orders are inserted");
        await using var conn = await db.OpenConnectionAsync(ct);
        await using var tx = await conn.BeginTransactionAsync(ct);   // rolled back on dispose unless committed

        await using (var cmd = new NpgsqlCommand("""
            insert into orders (id, customer_id, currency, status, placed_at)
            values ($1, $2, $3, 'placed', now())
            """, conn, tx))
        {
            cmd.Parameters.Add(new NpgsqlParameter<long> { TypedValue = order.Id.Value });
            cmd.Parameters.Add(new NpgsqlParameter<long> { TypedValue = order.Customer.Value });
            cmd.Parameters.Add(new NpgsqlParameter<string> { TypedValue = order.Currency.Code() });
            await cmd.ExecuteNonQueryAsync(ct);
        }

        await using (var copy = await conn.BeginBinaryImportAsync(
            "copy order_lines (order_id, sku, qty, unit_price_cents, unit_weight, status) from stdin (format binary)", ct))
        {
            foreach (var line in order.Lines)
            {
                await copy.StartRowAsync(ct);
                await copy.WriteAsync(order.Id.Value, NpgsqlDbType.Bigint, ct);
                await copy.WriteAsync(line.Sku.Value, NpgsqlDbType.Text, ct);
                await copy.WriteAsync(line.Qty, NpgsqlDbType.Integer, ct);
                await copy.WriteAsync(line.UnitPrice.Cents, NpgsqlDbType.Bigint, ct);
                await copy.WriteAsync(line.UnitWeight.Value, NpgsqlDbType.Bigint, ct);
                await copy.WriteAsync(line.Status.ToString().ToLowerInvariant(), NpgsqlDbType.Text, ct);
            }
            await copy.CompleteAsync(ct);
        }
        await tx.CommitAsync(ct);
    }

    public async Task SaveStateAsync(Order order, CancellationToken ct)
    {
        var (payment, tracking, reason) = order.State switch
        {
            OrderState.Paid p => (p.Payment.Value, null, null),
            OrderState.Shipped s => (s.Payment.Value, s.Tracking.Value, (string?)null),
            OrderState.Cancelled c => (null, null, c.Reason),
            _ => ((string?)null, (string?)null, (string?)null),
        };
        await using var cmd = db.CreateCommand("""
            update orders set status = $2, payment_id = $3, tracking_id = $4, cancel_reason = $5 where id = $1
            """);
        cmd.Parameters.Add(new NpgsqlParameter<long> { TypedValue = order.Id.Value });
        cmd.Parameters.Add(new NpgsqlParameter<string> { TypedValue = order.State.Name });
        cmd.Parameters.Add(new NpgsqlParameter { Value = (object?)payment ?? DBNull.Value });
        cmd.Parameters.Add(new NpgsqlParameter { Value = (object?)tracking ?? DBNull.Value });
        cmd.Parameters.Add(new NpgsqlParameter { Value = (object?)reason ?? DBNull.Value });
        await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task<Order?> FindAsync(OrderId id, CancellationToken ct)
    {
        await using var conn = await db.OpenConnectionAsync(ct);
        long customerId; string currencyCode, status; string? paymentId, trackingId, cancelReason;
        await using (var cmd = new NpgsqlCommand(
            "select customer_id, currency, status, payment_id, tracking_id, cancel_reason from orders where id = $1", conn))
        {
            cmd.Parameters.Add(new NpgsqlParameter<long> { TypedValue = id.Value });
            await using var r = await cmd.ExecuteReaderAsync(ct);
            if (!await r.ReadAsync(ct)) return null;
            customerId = r.GetInt64(0);
            currencyCode = r.GetString(1);
            status = r.GetString(2);
            paymentId = r.IsDBNull(3) ? null : r.GetString(3);
            trackingId = r.IsDBNull(4) ? null : r.GetString(4);
            cancelReason = r.IsDBNull(5) ? null : r.GetString(5);
        }
        if (!CurrencyExtensions.TryParseCode(currencyCode, out var currency)) throw new CorruptRowException("orders", id.Value);

        var lines = new List<Line>();
        await using (var cmd = new NpgsqlCommand(
            "select sku, qty, unit_price_cents, unit_weight, status from order_lines where order_id = $1 order by sku", conn))
        {
            cmd.Parameters.Add(new NpgsqlParameter<long> { TypedValue = id.Value });
            await using var r = await cmd.ExecuteReaderAsync(ct);
            while (await r.ReadAsync(ct))
            {
                try
                {
                    lines.Add(new Line
                    {
                        Sku = new Sku(r.GetString(0)),
                        Qty = r.GetInt32(1),
                        UnitPrice = new Money(r.GetInt64(2), currency),
                        UnitWeight = new Grams(r.GetInt64(3)),
                        Status = Enum.Parse<LineStatus>(r.GetString(4), ignoreCase: true),
                    }.Validated());
                }
                catch (Exception e) when (e is ValidationException or ViolationsException or ArgumentException)
                {
                    throw new CorruptRowException("order_lines", id.Value);
                }
            }
        }

        try
        {
            OrderState state = status switch
            {
                "draft" => new OrderState.Draft(),
                "placed" => new OrderState.Placed(),
                "paid" => new OrderState.Paid(new PaymentId(paymentId!)),
                "shipped" => new OrderState.Shipped(new PaymentId(paymentId!), new TrackingId(trackingId!)),
                "cancelled" => new OrderState.Cancelled(cancelReason ?? ""),
                _ => throw new CorruptRowException("orders", id.Value),
            };
            return Order.Restore(id, new CustomerId(customerId), currency, lines, state);
        }
        catch (Exception e) when (e is ValidationException or NullReferenceException or ArgumentNullException)
        {
            throw new CorruptRowException("orders", id.Value);
        }
    }

    public async Task<Money> LifetimeSpendAsync(CustomerId customer, Currency currency, CancellationToken ct)
    {
        await using var cmd = db.CreateCommand("""
            select l.unit_price_cents, l.qty
            from order_lines l join orders o on o.id = l.order_id
            where o.customer_id = $1 and o.currency = $2
              and o.status in ('paid', 'shipped') and l.status = 'active'
            """);
        cmd.Parameters.Add(new NpgsqlParameter<long> { TypedValue = customer.Value });
        cmd.Parameters.Add(new NpgsqlParameter<string> { TypedValue = currency.Code() });
        await using var r = await cmd.ExecuteReaderAsync(ct);
        var total = Money.Zero(currency);
        while (await r.ReadAsync(ct)) total += new Money(r.GetInt64(0), currency) * r.GetInt32(1);
        return total;
    }

    /// <summary>Streams lines as CSV. One reused buffer stands in for Bayan's per-row arena.</summary>
    public async Task ExportLinesAsync(DateTime start, TextWriter output, CancellationToken ct)
    {
        await output.WriteAsync("order_id,sku,qty,unit_price_cents,unit_weight_g\n");
        await using var cmd = db.CreateCommand("""
            select l.order_id, l.sku, l.qty, l.unit_price_cents, l.unit_weight
            from order_lines l join orders o on o.id = l.order_id
            where o.placed_at >= $1 order by l.order_id
            """);
        cmd.Parameters.Add(new NpgsqlParameter<DateTime> { TypedValue = start });
        await using var r = await cmd.ExecuteReaderAsync(ct);
        var buf = new char[256];
        while (await r.ReadAsync(ct))
        {
            if (!buf.AsSpan().TryWrite($"{r.GetInt64(0)},{r.GetString(1)},{r.GetInt32(2)},{r.GetInt64(3)},{r.GetInt64(4)}\n", out int n))
                throw new InvalidOperationException("row too long");
            await output.WriteAsync(buf.AsMemory(0, n), ct);
        }
    }
}
