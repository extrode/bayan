using Suq.Model;

namespace Suq.Lib;

public static class Ranking
{
    /// <summary>Keeps the <paramref name="dst"/>.Length largest items, largest first.</summary>
    public static int Top<T>(Span<T> dst, ReadOnlySpan<T> items) where T : IComparable<T>
    {
        int n = 0;
        foreach (var item in items)
        {
            if (n < dst.Length) n++;
            else if (item.CompareTo(dst[n - 1]) <= 0) continue;
            int i = n - 1;
            while (i > 0 && dst[i - 1].CompareTo(item) < 0) { dst[i] = dst[i - 1]; i--; }
            dst[i] = item;
        }
        return n;
    }
}

public sealed class Tally
{
    public Dictionary<Sku, long> Counts { get; } = [];

    public void EnsureCapacity(int entries) => Counts.EnsureCapacity(entries);
    public void Record(int qty, Sku sku) => Counts[sku] = Counts.GetValueOrDefault(sku) + qty;

    public Tally MergeWith(Tally other)
    {
        var merged = new Tally();
        foreach (var (k, v) in Counts) merged.Counts[k] = v;
        foreach (var (k, v) in other.Counts) merged.Counts[k] = merged.Counts.GetValueOrDefault(k) + v;
        return merged;
    }

    public void Prune()
    {
        foreach (var (k, v) in Counts) if (v == 0) Counts.Remove(k);
    }

    /// <summary>Hand-written copy form (Bayan derives <c>pruned()</c> from <c>prune</c>).</summary>
    public Tally Pruned() { var t = MergeWith(new Tally()); t.Prune(); return t; }
}

[Flags]
public enum Permission { None = 0, Refund = 1, EditPrices = 2, ViewReports = 4, ManageStaff = 8 }

public static class Roles
{
    public const Permission Packer = Permission.None;
    public const Permission Supervisor = Permission.Refund | Permission.ViewReports;
    public const Permission Owner = Permission.Refund | Permission.EditPrices | Permission.ViewReports | Permission.ManageStaff;
}

public record Person(string Name, string Email);

/// <summary>Inheritance stands in for Bayan's <c>embed</c>.</summary>
public sealed record Staff(string Name, string Email, Permission Permissions) : Person(Name, Email)
{
    public bool CanRefund => Permissions.HasFlag(Permission.Refund);
}

public interface IReport
{
    int Rows { get; }
    void WriteHeader(System.Text.StringBuilder dst);
    void WriteRow(System.Text.StringBuilder dst, int i);
    void Render(System.Text.StringBuilder dst)
    {
        WriteHeader(dst);
        for (int i = 0; i < Rows; i++) WriteRow(dst, i);
    }
}
