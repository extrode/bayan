using Suq.Model;
using Suq.Pricing;

namespace Suq.Warehouse;

public readonly record struct ShelfSlot(byte Aisle, ushort Bay) : IComparable<ShelfSlot>
{
    public int CompareTo(ShelfSlot other) => Aisle != other.Aisle ? Aisle.CompareTo(other.Aisle) : Bay.CompareTo(other.Bay);
    public static bool operator <(ShelfSlot a, ShelfSlot b) => a.CompareTo(b) < 0;
    public static bool operator >(ShelfSlot a, ShelfSlot b) => a.CompareTo(b) > 0;
    public static bool operator <=(ShelfSlot a, ShelfSlot b) => a.CompareTo(b) <= 0;
    public static bool operator >=(ShelfSlot a, ShelfSlot b) => a.CompareTo(b) >= 0;
}

public readonly record struct PackItem(Sku Sku, Grams Weight, ShelfSlot Slot);

public readonly record struct BoxSize(string Name, Grams Capacity, Grams Tare);

public sealed class TooHeavyException(Sku sku, Grams weight) : Exception($"{sku} ({weight}) fits no box")
{
    public Sku Sku { get; } = sku;
    public Grams Weight { get; } = weight;
}

/// <summary>Caller-owned buffers, sized once. Box arrays are indexed by box number and item arrays
/// by item number — both plain <c>int</c>, so mixing them up compiles (Bayan: <c>BoxId</c>).</summary>
public sealed class PackPlan
{
    public readonly BoxSize[] Boxes;
    public readonly Grams[] Load;        // includes the box's tare
    public readonly int[] BoxOf;
    readonly int[] _order;
    readonly long[] _keys;
    public int BoxCount { get; private set; }

    public PackPlan(int items)
    {
        Boxes = new BoxSize[items];
        Load = new Grams[items];
        BoxOf = new int[items];
        _order = new int[items];
        _keys = new long[items];
    }

    public int? BoxWithRoom(Grams weight)
    {
        for (int b = 0; b < BoxCount; b++)
            if (Load[b] + weight <= Boxes[b].Capacity) return b;
        return null;
    }

    public int Open(BoxSize size)
    {
        if (BoxCount == Boxes.Length) throw new InvalidOperationException("plan full");
        Boxes[BoxCount] = size;
        Load[BoxCount] = size.Tare;
        return BoxCount++;
    }

    public Grams Room(int box) => Boxes[box].Capacity.SaturatingMinus(Load[box]);

    internal Span<int> Order(int n) => _order.AsSpan(0, n);
    internal Span<long> Keys(int n) => _keys.AsSpan(0, n);
    internal void Clear() => BoxCount = 0;
}

public static class Packing
{
    public static readonly BoxSize[] BoxSizes =
    [
        new("S", UnitLiterals.Kg(2), UnitLiterals.G(150)),
        new("M", UnitLiterals.Kg(5), UnitLiterals.G(300)),
        new("L", UnitLiterals.Kg(12), UnitLiterals.G(600)),
    ];

    public static BoxSize? SmallestBox(Grams weight)
    {
        foreach (var size in BoxSizes)
            if (size.Capacity - size.Tare >= weight) return size;
        return null;
    }

    /// <summary>First-fit decreasing. Zero allocations: sorting uses a key array instead of a lambda,
    /// which would capture <paramref name="items"/> and allocate a closure.</summary>
    public static void Pack(PackPlan plan, ReadOnlySpan<PackItem> items)
    {
        if (items.Length > plan.BoxOf.Length) throw new InvalidOperationException("plan too small");
        plan.Clear();
        var order = plan.Order(items.Length);
        var keys = plan.Keys(items.Length);
        for (int i = 0; i < items.Length; i++)
        {
            order[i] = i;
            keys[i] = -items[i].Weight.Value * 1_000_000 + i;   // heaviest first, stable
        }
        keys.Sort(order);

        foreach (int i in order)
        {
            var item = items[i];
            var size = SmallestBox(item.Weight) ?? throw new TooHeavyException(item.Sku, item.Weight);
            int box = plan.BoxWithRoom(item.Weight) ?? plan.Open(size);
            plan.Load[box] += item.Weight;
            plan.BoxOf[i] = box;
        }
    }

    public static int Items(Span<PackItem> dst, IReadOnlyList<Line> lines, IReadOnlyDictionary<Sku, ShelfSlot> slots)
    {
        int n = 0;
        foreach (var line in lines)
        {
            if (line.IsInactive) continue;
            var slot = slots.TryGetValue(line.Sku, out var s) ? s : new ShelfSlot(0, 0);
            for (int q = 0; q < line.Qty; q++) dst[n++] = new PackItem(line.Sku, line.UnitWeight, slot);
        }
        return n;
    }

    public static void PickOrder(Span<int> dst, Span<ShelfSlot> scratch, ReadOnlySpan<PackItem> items)
    {
        for (int i = 0; i < items.Length; i++) { dst[i] = i; scratch[i] = items[i].Slot; }
        scratch[..items.Length].Sort(dst[..items.Length]);
    }

    /// <summary>FNV-1a, reduced to one digit. <c>unchecked</c> is the C# spelling of Bayan's <c>*%</c>.</summary>
    public static byte CheckDigit(string text)
    {
        uint h = 2166136261;
        foreach (char c in text) h = unchecked((h ^ (byte)c) * 16777619);
        return (byte)(h % 10);
    }

    /// <summary>Only shipped orders have a tracking number; checked at runtime by <see cref="Order.Tracking"/>.</summary>
    public static bool TryWriteLabel(Span<char> dst, Order order, out int written) =>
        dst.TryWrite($"SUQ {order.Id.Value} / {order.Tracking.Value} / {CheckDigit(order.Tracking.Value)}", out written);

    public static ushort NextLabelSeq(ref ushort seq) => unchecked(++seq);
}
