using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Suq.Model;
using Suq.Pricing;

namespace Suq.Carrier;

public enum CarrierErrorKind { Timeout, Rejected, Unavailable }

public sealed class CarrierException(CarrierErrorKind kind, string message) : Exception(message)
{
    public CarrierErrorKind Kind { get; } = kind;
    public bool IsRetryable => Kind is not CarrierErrorKind.Rejected;
}

public readonly record struct Parcel(OrderId Order, string Box, Grams Weight);

/// <summary>Nothing here says the implementation does network I/O, or may not.</summary>
public interface IShipper
{
    string Name => "carrier";
    Task<TrackingId> BookAsync(Parcel parcel, CancellationToken ct);
}

/// <summary>Hand-written to match the courier's sample reply (Bayan generates it from the sample at compile time).</summary>
public sealed record BookingReply(bool Accepted, string TrackingNumber, string Service, int EstimatedDays);

public sealed class LajuExpress(HttpClient http, Uri baseUri, Secret<string> apiKey) : IShipper
{
    public string Name => "Laju Express";

    public async Task<TrackingId> BookAsync(Parcel parcel, CancellationToken ct)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, new Uri(baseUri, "/v1/shipments"))
        {
            Content = JsonContent.Create(ParcelDto.Of(parcel), SuqJson.Default.ParcelDto),
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", apiKey.Expose());

        HttpResponseMessage response;
        try { response = await http.SendAsync(request, ct); }
        catch (TaskCanceledException) when (!ct.IsCancellationRequested) { throw new CarrierException(CarrierErrorKind.Timeout, "courier timed out"); }
        catch (HttpRequestException e) { throw new CarrierException(CarrierErrorKind.Unavailable, e.Message); }

        using (response)
        {
            if ((int)response.StatusCode >= 500) throw new CarrierException(CarrierErrorKind.Unavailable, $"courier returned {(int)response.StatusCode}");
            BookingReply? reply;
            try { reply = await response.Content.ReadFromJsonAsync(SuqJson.Default.BookingReply, ct); }
            catch (JsonException) { throw new CarrierException(CarrierErrorKind.Rejected, "unreadable reply"); }
            if (reply is null || !reply.Accepted) throw new CarrierException(CarrierErrorKind.Rejected, "booking refused");
            // Nothing marks reply.TrackingNumber as third-party data; validating it is a convention.
            try { return new TrackingId(reply.TrackingNumber); }
            catch (ValidationException) { throw new CarrierException(CarrierErrorKind.Rejected, "malformed tracking number"); }
        }
    }
}

public sealed record ParcelDto(long Order, string Box, long WeightGrams)
{
    public static ParcelDto Of(Parcel p) => new(p.Order.Value, p.Box, p.Weight.Value);
}

public static partial class Shipping
{
    public static async Task<TrackingId> BookWithRetryAsync(
        Parcel parcel, IShipper shipper, TimeProvider clock, ILogger logger, CancellationToken ct, int attempts = 3)
    {
        var wait = TimeSpan.FromMilliseconds(200);
        for (int attempt = 1; attempt < attempts; attempt++)
        {
            try { return await shipper.BookAsync(parcel, ct); }
            catch (CarrierException e) when (e.IsRetryable)
            {
                LogRetry(logger, parcel.Order.Value, shipper.Name, attempt, attempts);
            }
            await Task.Delay(wait, clock, ct);
            wait *= 2;
        }
        return await shipper.BookAsync(parcel, ct);
    }

    /// <summary>All parcels concurrently with a 5 s deadline. Cancelling the rest on the first failure
    /// is manual in C#: WhenAll waits for every task.</summary>
    public static async Task<TrackingId[]> BookAllAsync(
        IReadOnlyList<Parcel> parcels, IShipper shipper, TimeProvider clock, ILogger logger, CancellationToken ct)
    {
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(5), clock);
        using var link = deadline.Token.Register(cts.Cancel);
        var tasks = new Task<TrackingId>[parcels.Count];
        for (int i = 0; i < parcels.Count; i++)
            tasks[i] = BookWithRetryAsync(parcels[i], shipper, clock, logger, cts.Token);
        try
        {
            return await Task.WhenAll(tasks);
        }
        catch (OperationCanceledException) when (deadline.IsCancellationRequested)
        {
            throw new CarrierException(CarrierErrorKind.Timeout, "batch deadline");
        }
        catch
        {
            cts.Cancel();
            throw;
        }
    }

    [LoggerMessage(LogLevel.Warning, "retrying {Order} with {Shipper}, attempt {Attempt} of {Attempts}")]
    static partial void LogRetry(ILogger logger, long order, string shipper, int attempt, int attempts);
}

/// <summary>A pending booking as a value (Bayan derives this as <c>BookWithRetryOp</c>).</summary>
public sealed record BookWithRetryOp(Parcel Parcel, IShipper Shipper)
{
    public Task<TrackingId> InvokeAsync(TimeProvider clock, ILogger logger, CancellationToken ct) =>
        Shipping.BookWithRetryAsync(Parcel, Shipper, clock, logger, ct);
}

public sealed class Outbox(TimeProvider clock, ILogger<Outbox> logger)
{
    readonly Lock _gate = new();
    readonly List<BookWithRetryOp> _pending = [];

    public void Add(BookWithRetryOp op) { lock (_gate) _pending.Add(op); }

    /// <summary>Retries every pending booking and returns the successes; failures go back in.
    /// The lock is never held across an await (C# rejects <c>await</c> inside <c>lock</c> too).</summary>
    public async Task<List<(Parcel Parcel, TrackingId Tracking)>> RetryAsync(CancellationToken ct)
    {
        BookWithRetryOp[] batch;
        lock (_gate) { batch = [.. _pending]; _pending.Clear(); }
        var booked = new List<(Parcel, TrackingId)>();
        foreach (var op in batch)
        {
            try { booked.Add((op.Parcel, await op.InvokeAsync(clock, logger, ct))); }
            catch (CarrierException) { lock (_gate) _pending.Add(op); }
        }
        return booked;
    }

    public int Count { get { lock (_gate) return _pending.Count; } }
}
