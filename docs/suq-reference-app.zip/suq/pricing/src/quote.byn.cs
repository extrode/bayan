// quote.byn — pricing a basket: subtotal, best promotion, shipping by weight, tax
module suq.pricing

/// One line as pricing sees it. Pricing knows nothing about orders or SKUs.
public struct PriceLine {
    public key: string
    public qty: i32
    public unitPrice: Money
    public unitWeight: Grams
}

public union Promotion {
    percentOff(rate: BasisPoints, minimum: Money)
    buyGetFree(key: string, buy: i32, free: i32)
    freeShippingOver(threshold: Money)

    /// Whether every amount in this promotion is in `currency`.
    public isPricedIn(currency: Currency) -> bool => this switch {
        .percentOff p => p.minimum.currency == currency,
        .buyGetFree => true,
        .freeShippingOver p => p.threshold.currency == currency,
    }
}

public struct ShippingBand {
    public upTo: Grams
    public fee: Money
}

/// Everything a quote depends on. Thresholds are compared in cents, so every amount must
/// be in the policy's currency; the rules make a mixed policy impossible to construct.
public struct Policy {
    public currency: Currency
    public taxRate: BasisPoints
    public promotions: Span<Promotion>
    public bands: Span<ShippingBand>

    requires promotions.all(it.isPricedIn(currency)) at .promotions
    requires bands.all(it.fee.currency == currency) at .bands
    requires bands.isSorted(by: it.upTo) at .bands
}

@derive(Json)
public struct Quote {
    public subtotal: Money
    public discount: Money
    public shipping: Money
    public tax: Money

    public total: Money => subtotal - discount + shipping + tax
}

public union error QuoteError {
    overweight(weight: Grams)
}

/// Prices a basket. No `uses` clause, so it can't allocate, suspend or do I/O,
/// and the package's empty capability list would reject it if it tried.
public quote(lines: Span<PriceLine>, by policy: Policy) -> Quote fails PricingError, QuoteError {
    var subtotal = Money.zero(policy.currency)
    var weight: Grams = 0g
    for line in lines {
        subtotal = try subtotal.add(line.unitPrice * line.qty)
        weight += line.unitWeight * line.qty
    }
    let discount = pickBestDiscount(subtotal, from: lines, by: policy)
    let freeShipping = policy.promotions.any(it is .freeShippingOver p and subtotal.cents >= p.threshold.cents)

    let fee = try lookUpShippingFee(weight, by: policy)       // overweight fails even when shipping is free
    let shipping = freeShipping ? Money.zero(policy.currency) : fee
    let tax = try (subtotal - discount + shipping).multiply(by: policy.taxRate)
    return Quote { subtotal, discount, shipping, tax }
}

/// The single best promotion wins; promotions don't stack.
pickBestDiscount(subtotal: Money, from lines: Span<PriceLine>, by policy: Policy) -> Money {
    var best = Money.zero(subtotal.currency)
    for promo in policy.promotions {
        let amount = promo switch {
            .percentOff p => discountPercent(subtotal, by: p),
            .buyGetFree p => discountFreeUnits(p, from: lines, as: subtotal.currency),
            .freeShippingOver => Money.zero(subtotal.currency),
        }
        best = amount if amount.cents > best.cents
    }
    return best
}

discountPercent(subtotal: Money, by p: Promotion is .percentOff) -> Money {
    return Money.zero(subtotal.currency) if subtotal.cents < p.minimum.cents
    return subtotal.tryMultiply(by: p.rate) ?? Money.zero(subtotal.currency)
}

discountFreeUnits(p: Promotion is .buyGetFree, from lines: Span<PriceLine>, as currency: Currency) -> Money {
    let line = lines.first(it.key == p.key) ?? return Money.zero(currency)
    let free = line.qty / (p.buy + p.free) * p.free
    return line.unitPrice * free
}

lookUpShippingFee(weight: Grams, by policy: Policy) -> Money fails QuoteError {
    for band in policy.bands {
        return band.fee if weight <= band.upTo
    }
    fail .overweight(weight)
}

// ── Tests ──────────────────────────────────────────────────────────

const rm = Currency.myr

const standard = Policy {
    currency: rm,
    taxRate: 8pct,
    promotions: [
        .percentOff(rate: 10pct, minimum: Money { cents: 20000, currency: rm }),
        .buyGetFree(key: "TEA-0001", buy: 2, free: 1),
        .freeShippingOver(threshold: Money { cents: 15000, currency: rm }),
    ],
    bands: [
        ShippingBand { upTo: 1kg, fee: Money { cents: 800, currency: rm } },
        ShippingBand { upTo: 5kg, fee: Money { cents: 1500, currency: rm } },
        ShippingBand { upTo: 20kg, fee: Money { cents: 3500, currency: rm } },
    ],
}

/// Built at compile time: no setup cost in tests or benchmarks.
comptime makeBasket(size: i32) -> List<PriceLine> {
    var lines = List<PriceLine>()
    for i in 0..size {
        lines.append(PriceLine {
            key: $"K{i}",
            qty: 1 + i % 3,
            unitPrice: Money { cents: 990 + i * 10, currency: rm },
            unitWeight: 250g,
        })
    }
    return lines
}

const basket40 = makeBasket(40)

test "buy two, get one free on tea" {
    let lines = [PriceLine { key: "TEA-0001", qty: 3, unitPrice: Money { cents: 1200, currency: rm }, unitWeight: 100g }]
    let q = try quote(lines, by: standard)
    assert q.discount is Money { cents: 1200 }
    assert q.shipping is Money { cents: 800 }
    assert q.tax is Money { cents: 256 }
    assert q.total is Money { cents: 3456 }
}

test "free shipping over RM150 beats the weight band" {
    let lines = [PriceLine { key: "RUG-0001", qty: 1, unitPrice: Money { cents: 16000, currency: rm }, unitWeight: 4kg }]
    let q = try quote(lines, by: standard)
    assert q.shipping is Money { cents: 0 }
}

test "over 20kg cannot be quoted" {
    let lines = [PriceLine { key: "BED-0001", qty: 1, unitPrice: Money { cents: 90000, currency: rm }, unitWeight: 25kg }]
    assert quote(lines, by: standard) fails QuoteError.overweight
}

@budget(allocs: 0)
bench "quote a 40-line basket" {
    let _ = try quote(basket40.asSpan, by: standard)
}
