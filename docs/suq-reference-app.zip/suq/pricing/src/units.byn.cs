// units.byn — units of measure for pricing and packing
module suq.pricing

/// Mass. Every weight in Sūq is stored in grams.
public unit Grams(g): i64

/// 1kg = 1000g. Kilograms convert implicitly to grams (finer), never back.
public unit Kilograms(kg) = 1000g

/// A rate in hundredths of a percent: 800bp is 8%.
public unit BasisPoints(bp): i64

/// 1pct = 100bp. Lets policies say `8pct` and still compute in basis points.
public unit Percent(pct) = 100bp
