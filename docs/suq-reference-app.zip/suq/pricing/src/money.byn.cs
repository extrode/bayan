// money.byn — currency-safe amounts
module suq.pricing

/// Currencies Sūq sells in. A closed union: outside text becomes a `Currency`
/// only through `Currency.tryParse`.
@derive(Json)
public union Currency {
    myr
    sgd
    usd

    public code: string => this switch {
        .myr => "MYR",
        .sgd => "SGD",
        .usd => "USD",
    }
}

public union error PricingError {
    currencyMismatch(expected: Currency, got: Currency)
    overflow
}

/// An amount in minor units (sen, cents) of one currency.
/// Money is a struct, not a unit: units can't stop MYR being added to SGD.
///
/// ```
/// let price = Money { cents: 1250, currency: .myr }
/// assert price.format() == "MYR 12.50"
/// assert (price * 3).cents == 3750
/// ```
@derive(Json)
public struct Money {
    public cents: i64
    public currency: Currency

    public static zero(currency: Currency) -> Money => Money { cents: 0, currency }

    /// Fails on mixed currencies or overflow. The derived `tryAdd` returns null instead.
    public add(other: Money) -> Money fails PricingError {
        fail .currencyMismatch(expected: currency, got: other.currency) if other.currency != currency
        let sum = checked(cents + other.cents) ?? fail .overflow
        return Money { cents: sum, currency }
    }

    /// Mixed currencies trap, like integer overflow (open question O7).
    public static operator +(a: Money, b: Money) -> Money {
        panic("mixed currencies") if a.currency != b.currency
        return Money { cents: a.cents + b.cents, currency: a.currency }
    }

    public static operator -(a: Money, b: Money) -> Money {
        panic("mixed currencies") if a.currency != b.currency
        return Money { cents: a.cents - b.cents, currency: a.currency }
    }

    /// Quantities are dimensionless: `Money × i32 → Money`.
    public static operator *(a: Money, qty: i32) -> Money =>
        Money { cents: a.cents * qty, currency: a.currency }

    /// This amount at a rate, rounded half up to the minor unit. For non-negative amounts.
    public multiply(by rate: BasisPoints) -> Money fails PricingError {
        let scaled = checked(cents * (rate / 1bp) + 5000) ?? fail .overflow   // the +5000 can overflow too
        return Money { cents: scaled / 10000, currency }
    }

    /// Writes "MYR 12.50". The allocating `format()` is derived from this.
    public formatInto(ref dst: StrBuf) {
        dst.append(currency.code)
        dst.append(' ')
        dst.append('-') if cents < 0
        let whole = cents.abs()
        dst.append(whole / 100)
        dst.append('.')
        dst.append(whole % 100, width: 2, fill: '0')
    }
}

// ── Laws (opt-in through package.byn) ──────────────────────────────

law addCommutes(a: Money, b: Money) {
    a.tryAdd(b) == b.tryAdd(a)
}

law zeroIsIdentity(m: Money) {
    m + Money.zero(m.currency) == m
}

// ── Tests ──────────────────────────────────────────────────────────

test "mixed currencies fail instead of adding" {
    let myr = Money { cents: 100, currency: .myr }
    let sgd = Money { cents: 100, currency: .sgd }
    assert myr.tryAdd(sgd) is null
    assert myr.tryAdd(myr) is Money { cents: 200 }
}

@cases(
    (cents: 1250, text: "MYR 12.50"),
    (cents: 5, text: "MYR 0.05"),
    (cents: -300, text: "MYR -3.00"),
)
test "format" (cents: i64, text: string) {
    assert Money { cents, currency: .myr }.format() == text
}

test "8% of 10.63 rounds half up to 0.85" {
    assert try Money { cents: 1063, currency: .myr }.multiply(by: 8pct) is Money { cents: 85 }
}
