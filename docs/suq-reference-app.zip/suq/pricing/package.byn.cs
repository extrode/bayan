// package.byn — suq.pricing: pure pricing rules, shared by the storefront and admin scripts
Package {
    name: "suq.pricing",
    version: "0.1.0",
    edition: 2026,
    capabilities: [],                 // no net, fs, clock, random or env, transitively
    laws: Laws { enabled: true },     // laws are opt-in, per package
    diagnostics: Diagnostics { prefix: "SQP" },
    style: Style {
        booleans: .words,
    },
}
