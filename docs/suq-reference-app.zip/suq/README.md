# Sūq (سوق) — Bayan reference application

A commerce and warehouse system that uses every round-3 Bayan feature, most of them twice. It doubles as the language-design test and as the compiler's end-to-end test (HANDOFF §21).

Files are `*.byn.cs` so previews get syntax highlighting. Rename them to `*.byn`.

```
package.byn             app manifest: capabilities, native libsodium, laws, style.booleans = .words
pricing/                suq.pricing — a pure package (capabilities: []): money, units, quotes
src/model/              ids, address (Patch, struct rules), order (typestate)
src/warehouse/          zero-allocation packing, typed indices, labels
src/carrier/            courier API: effects, retries, fiber groups, provide-based tests
src/db/                 Postgres: Row, binary COPY, transactions, streaming, arenas
src/payments/           libsodium FFI, unique keys, Secret, webhooks
src/storefront/         HTTP handlers: validation, trust layers, typestate narrowing
src/lib/                generics, derived verb forms, laws, Set-of-union permissions
src/main.byn            Panic.onPanic, Config, real effect handlers, routes
scripts/restock.byn     scripting mode, Args/Config derivations
samples/                comptime inputs (courier reply)
fail/                   compile-fail corpus (38 snippets)
tools/check_round3.py   mechanical round-3 checker
docs/                   coverage matrix, friction log
```

## Checks

```
python3 tools/check_round3.py .               # 19 files, 0 problems
python3 tools/check_round3.py --self-test .   # 38/38 compile-fail snippets caught, each by its own rule only
```

The checker catches mechanical issues: semicolons, synonyms, input forms (including name-first declarations), particles, `because`, waqf breaks, bare unit literals, and keywords used as names. Semantic rules were checked by hand: effects, typestate, taint, visibility across modules, and verb naming. The fixes are recorded in `docs/bayan-reference-app-friction.md`.

## Open questions assumed

O1–O10 follow the round-3 audit recommendations. For O2, counts (`length`, `runeCount`) are plain integers, and byte units are for sizes and offsets.
