#!/usr/bin/env python3
"""check_round3.py — mechanical checks of Sūq's Bayan sources against the round-3 HANDOFF.

Not a parser: it strips comments and string literals, then applies line rules that a real
`bayan` front end would enforce. Each rule cites its HANDOFF section.

    python3 tools/check_round3.py [root]      # exit 1 if anything is found
"""
import re
import sys
from pathlib import Path

PARTICLES = {"from", "to", "at", "by", "for", "as"}
UNITS = {"Grams", "Kilograms", "BasisPoints", "Percent", "Millis", "Seconds", "Bytes", "KiB", "MiB"}
EXEMPT_DECLS = ("operator", "law ", "extern")   # F-09: positional by nature


def strip(src: str) -> list[str]:
    """Blank out comments and string contents, keeping line structure and the quotes."""
    out, i, n = [], 0, len(src)
    buf = []
    while i < n:
        c = src[i]
        if src.startswith("//", i):
            while i < n and src[i] != "\n":
                i += 1
            continue
        if src.startswith('"""', i):
            j = src.find('"""', i + 3)
            j = n if j < 0 else j
            buf.append('""""""')
            buf.append("\n" * src.count("\n", i, j))
            i = j + 3
            continue
        if c == '"':
            interp = i > 0 and src[i - 1] == "$"
            j = i + 1
            holes = []
            while j < n and src[j] != '"' and src[j] != "\n":
                if interp and src[j] == "{":
                    k = src.find("}", j)
                    holes.append(src[j + 1:k])
                    j = k + 1
                    continue
                j += 2 if src[j] == "\\" else 1
            # interpolation holes are code, so they are checked too
            buf.append('"' + " ".join("{" + h + "}" for h in holes) + '"')
            i = j + 1
            continue
        if c == "'" and i + 2 < n and (src[i + 2] == "'" or src[i + 1] == "\\"):
            j = src.find("'", i + 2)
            buf.append("'r'")
            i = j + 1
            continue
        buf.append(c)
        i += 1
    return "".join(buf).split("\n")


def split_params(s: str) -> list[str]:
    parts, depth, cur = [], 0, ""
    for ch in s:
        if ch in "(<[{":
            depth += 1
        elif ch in ")>]}":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip():
        parts.append(cur.strip())
    return parts


DECL = re.compile(r"^\s*(?:public\s+|static\s+|comptime\s+)*([a-z]\w*)(?:<[^>]*>)?\((.*)\)\s*(->|becomes|fails|uses|where|=>|\{|$)")

RULES = [
    # (section, regex on stripped code, message)
    ("§3", re.compile(r";"), "semicolon"),
    ("§6", re.compile(r"/\*"), "block comment"),
    ("SPEC §15", re.compile(r"[!=]=\s*null\b"), "null check with ==/!= (use `is null` / `is not null`)"),
    ("SPEC §15", re.compile(r"\b(int|long|short|byte|uint|ulong|ushort|sbyte|float|double|decimal)\b"), "C# alias type name"),
    ("§10", re.compile(r"\bchar\b"), "`char` (use `rune`)"),
    ("SPEC §15", re.compile(r"\bforeach\b"), "`foreach`"),
    ("§2", re.compile(r"\b(unique\s+struct|distinct\s+type|error\s+union|error\s+set|set\s+error)\b"), "modifier-first declaration keyword"),
    ("§13", re.compile(r"\b(noalloc|nosuspend|suspends)\b"), "removed effect keyword"),
    ("§4", re.compile(r"^\s*\[[A-Z]\w*(\(|\])"), "`[Attr]` attribute (use `@attr`)"),
    ("§4", re.compile(r"@[A-Z]"), "attribute names are camelCase"),
    ("§3", re.compile(r"^\s*else\b"), "`else` must follow `}` on the same line"),
    ("§5", re.compile(r"&&|\|\||(?<![\w)\]])!(?!=)"), "symbol boolean in a `.words` project"),
    ("§8", re.compile(r"\.in\(|\.floor\(\)|\.ceil\(\)"), "removed unit conversion form"),
    ("§11", re.compile(r"\brequires\s+value\b"), "`requires value` (use `it`)"),
    ("§7", re.compile(r"case\s+_\s+except"), "`case _ except` (use `case not`)"),
    ("O4", re.compile(r"\bon\s+\.\w+\s*$"), "`on .field` (use `at .field`)"),
    ("O5", re.compile(r"=>\s*(void|never)\b"), "`=>` in a function type (use `->`)"),
    ("§12", re.compile(r"\bLog\.\w+"), "`Log.x` (log is the verb; the level is `as:`)"),
    ("grammar", re.compile(r"\btoString\("), "`toString()` (use `format()`)"),
    ("SPEC", re.compile(r'""\s*\+|\+\s*""'), "string `+` (deferred; use interpolation)"),
    ("§13", re.compile(r"\bcontext\s*\("), "`context (…)` block (use `provide`)"),
    ("§13", re.compile(r",\s*at:\s*\.(debug|info|warning|error)"), "log level with `at:` (use `as:`)"),
    ("§18", re.compile(r"\btry\b[^\n]*\bcatch\b"), "`try` and `catch` on the same call"),
    ("§3", re.compile(r"^\s*(\+|\*|/|%|&|\||\?(?![.?])|:|and\b|or\b)"), "line starts with a binary operator (no waqf join)"),
    ("§2", re.compile(r"^\s*(?:(?:var|let)\s+)?[A-Z]\w*(?:<[^>]*>)?\s+[a-z]\w*\s*=(?!>)"), "type-first binding"),
    ("O9", re.compile(r"\b\w+\s*:\s*(" + "|".join(UNITS) + r")\s*=\s*-?\d+\s*$"), "bare literal for a unit type"),
    ("F-08", re.compile(r'\btry\s+[A-Z]\w*\(("[^"]*"|\d+)\)'), "`try` on a literal construction"),
    ("keyword", re.compile(r"\b(let|var)\s+(checked|with|in|is|fail|because|provide|become)\b"), "keyword used as a name"),
]

BECAUSE_NEEDED = re.compile(r"@allow\(|\bunsafe\b|Unchecked\(\)|\.expose\(\)|@json\(expose\)")


def check_file(path: Path) -> list[str]:
    problems = []
    raw = path.read_text().split("\n")
    lines = strip(path.read_text())
    blank = True
    stack = ["module"]          # kinds of the enclosing blocks
    for no, (code, orig) in enumerate(zip(lines, raw), 1):
        ctx = stack[-1]
        loc = f"{path}:{no}"
        if no == 1 and code.startswith("#!"):
            continue
        if code.lstrip().startswith("#:"):
            continue
        for sec, rx, msg in RULES:
            if rx.search(code):
                problems.append(f"{loc}: [{sec}] {msg}\n    {orig.strip()}")
        if BECAUSE_NEEDED.search(code) and not re.search(r"\bbecause\s+\"", orig) and "extern" not in code:
            problems.append(f"{loc}: [§4] bypass without `because`\n    {orig.strip()}")
        # parenthesized control-flow heads are allowed only when the condition contains a brace
        m = re.match(r"^\s*(?:\}\s*else\s+)?(if|while|unless)\s*\((.*)\)\s*\{\s*$", code)
        # `for (a, b) in xs` destructures a tuple; only `for (x in xs)` puts `in` inside the parentheses
        f = re.match(r"^\s*for\s*\((?:let |var )?[^()]*\bin\b.*\)\s*\{\s*$", code)
        if (m and "{" not in m.group(2)) or f:
            problems.append(f"{loc}: [SPEC §15] parenthesized condition\n    {orig.strip()}")
        # §15 particles: at most one unlabeled required parameter
        d = DECL.match(code) if ctx in ("module", "struct", "interface", "extension") else None
        if d and not any(x in code for x in EXEMPT_DECLS) and d.group(1) not in {"if", "for", "while", "switch", "unless", "test", "bench", "catch"}:
            unlabeled = []
            for p in split_params(d.group(2)):
                p = re.sub(r"^ref\s+", "", p)
                if p in ("this", "") or p.startswith("this ") or "=" in p.split(":", 1)[-1] and ":" in p:
                    continue
                if ":" not in p:
                    continue
                head = p.split(":", 1)[0].split()
                if len(head) == 2 and head[0] in PARTICLES:
                    continue
                if len(head) == 2 and head[0] not in PARTICLES:
                    problems.append(f"{loc}: [§15] `{head[0]}` is not a particle\n    {orig.strip()}")
                    continue
                unlabeled.append(head[0])
            if len(unlabeled) > 1:
                problems.append(f"{loc}: [§15] {len(unlabeled)} unlabeled parameters ({', '.join(unlabeled)})\n    {orig.strip()}")
        # §3: a blank line ends a statement; flag a dangling continuation before a blank line
        if code.strip() == "" and not blank:
            prev = lines[no - 2].rstrip()
            if re.search(r"(\+|-|\*|/|,|=|=>|\band|\bor|\()\s*$", prev) and not prev.strip().startswith("//"):
                problems.append(f"{path}:{no - 1}: [§3] statement continues into a blank line\n    {raw[no - 2].strip()}")
        blank = code.strip() == ""
        # maintain the block stack
        kind = "block"
        m = re.match(r"^\s*(?:public\s+)?(struct|union|interface|extension|extern)\b", code)
        if m:
            kind = m.group(1)
        for ch in code:
            if ch == "{":
                stack.append(kind if kind != "block" or len(stack) == 0 else kind)
                kind = "block"
            elif ch == "}" and len(stack) > 1:
                stack.pop()
    return problems


def self_test(root: Path) -> int:
    """Every snippet in fail/ must trigger the diagnostic named on its `// expect:` line."""
    failed = 0
    files = sorted((root / "fail").glob("*.byn.cs"))
    for f in files:
        expect = re.search(r"// expect: (.+)", f.read_text()).group(1).strip()
        got = check_file(f)
        if not any(expect in g for g in got):
            failed += 1
            print(f"MISSED {f.name}: expected '{expect}', got {got or 'nothing'}")
    print(f"self-test: {len(files) - failed}/{len(files)} compile-fail snippets caught")
    return 1 if failed else 0


def main() -> int:
    if "--self-test" in sys.argv:
        return self_test(Path(sys.argv[2] if len(sys.argv) > 2 else "."))
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
    files = sorted(p for p in root.rglob("*.byn.cs") if "fail" not in p.parts)
    problems = [p for f in files for p in check_file(f)]
    for p in problems:
        print(p)
    print(f"\n{len(files)} files, {len(problems)} problems")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
