#!/usr/bin/env python3
"""check_round3.py — mechanical checks of Sūq's Bayan sources against the round-3 HANDOFF.

Not a parser: it strips comments and string literals, then applies line rules that a real
`bayan` front end would enforce. Each rule cites its HANDOFF section.

    python3 tools/check_round3.py [root]      # exit 1 if anything is found
"""
import re
import sys
from pathlib import Path

PARTICLES = {"from", "to", "at", "by", "for", "as"}
UNITS = {"Grams", "Kilograms", "BasisPoints", "Percent", "Millis", "Seconds", "Bytes", "KiB", "MiB"}
EXEMPT_DECLS = ("operator", "law ", "extern")   # F-09: positional by nature


def strip(src: str) -> list[str]:
    """Blank out comments and string contents, keeping line structure and the quotes."""
    out, i, n = [], 0, len(src)
    buf = []
    while i < n:
        c = src[i]
        if src.startswith("//", i):
            while i < n and src[i] != "\n":
                i += 1
            continue
        if src.startswith('"""', i):
            j = src.find('"""', i + 3)
            j = n if j < 0 else j
            buf.append('""""""')
            buf.append("\n" * src.count("\n", i, j))
            i = j + 3
            continue
        if c == '"':
            interp = i > 0 and src[i - 1] == "$"
            j = i + 1
            holes = []
            while j < n and src[j] != '"' and src[j] != "\n":
                if interp and src[j] == "{":
                    k = src.find("}", j)
                    holes.append(src[j + 1:k])
                    j = k + 1
                    continue
                j += 2 if src[j] == "\\" else 1
            # interpolation holes are code, so they are checked too
            buf.append('"' + " ".join("{" + h + "}" for h in holes) + '"')
            i = j + 1
            continue
        if c == "'" and i + 2 < n and (src[i + 2] == "'" or src[i + 1] == "\\"):
            j = src.find("'", i + 2)
            buf.append("'r'")
            i = j + 1
            continue
        buf.append(c)
        i += 1
    return "".join(buf).split("\n")


def split_params(s: str) -> list[str]:
    parts, depth, cur = [], 0, ""
    for ch in s:
        if ch in "(<[{":
            depth += 1
        elif ch in ")>]}":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip():
        parts.append(cur.strip())
    return parts


# Declarations are type-first (`public Grams shippingWeight(Order order)`, `Sku sku`); local
# bindings are name-first (`let w: Grams = 0g`). A field and a local binding look alike, so the
# enclosing block decides: struct, union, interface, extension and extern bodies hold
# declarations; function bodies and the module level (scripts) hold statements.
DECL_CTX = ("module", "struct", "union", "interface", "extension", "extern")
FIELD_CTX = ("struct", "union", "interface", "extension", "extern")
BUILTIN = re.compile(r"dyn|[iuf]\d+|isize|usize|bool|string|rune|void|never")
TYPE = r"(?:dyn\s+)?\*?(?:mut\s+)?[A-Za-z_][\w.]*(?:<(?:[^<>]|<[^<>]*>)*>)?\??"
TYPE_START = r"(?=[A-Z(*]|(?:" + BUILTIN.pattern + r")\b)"
NOT_A_TYPE = (r"(?:return|try|await|assert|fail|become|defer|let|var|const|using|if|for|while|unless|switch|"
              r"test|bench|law|catch|provide|measure|else|not|move|state|requires|embed|type|import|module|"
              r"union|struct|interface|extension|extern|public|static|comptime|operator|async|log|print|panic)\b")
# modifiers, return type (type-first), name, generic parameters, then the opening parenthesis
HEAD = re.compile(rf"^(\s*)((?:(?:public|static|comptime)\s+)*)(?:(?!{NOT_A_TYPE})({TYPE})\s+)?(operator\s*[^\s(]+|[a-z]\w*)(<[^>]*>)?\(")
TAIL = re.compile(r"\s*(becomes\b|fails\b|uses\b|where\b|=>|\{|$)")
ARROW = re.compile(r"\s*->\s*(.+?)\s*(?=\bbecomes\b|\bfails\b|\buses\b|\bwhere\b|=>|\{|$)")
# `[ref] [label] name: Type [is .state] [= default]`, the name-first input form of a parameter or payload
NAME_FIRST_PARAM = re.compile(r"^(ref\s+)?(?:([a-z]\w*)\s+)?([a-z]\w*)\s*:\s*" + TYPE_START + r"(.+)$")
NAME_FIRST_FIELD = re.compile(r"^(\s*)((?:(?:public|static)\s+)*)([a-z]\w*)\s*:\s*" + TYPE_START + r"(.+)$")
PAYLOAD = re.compile(r"^\s*(?:state\s+)?[a-z]\w*\((.*)\)\s*$")


def decl(code: str, ctx: str):
    """(indent, modifiers, return type or None, name, params, rest) of a function declaration, else None."""
    m = HEAD.match(code)
    if not m:
        return None
    i, depth = m.end(), 1
    while i < len(code) and depth:
        depth += {"(": 1, ")": -1}.get(code[i], 0)
        i += 1
    if depth:
        return None
    indent, mods, ret, name, gen, params, rest = *m.groups()[:4], m.group(5) or "", code[m.end():i - 1], code[i:]
    tail = TAIL.match(rest)
    # a call at the module level (scripts) has no return type, `->`, modifier or body
    if not ((ret and tail) or ARROW.match(rest) or mods or (tail and tail.group(1)) or ctx in ("interface", "extern")):
        return None
    return indent, mods, ret, name + gen, params, rest


def type_first_param(p: str) -> str:
    m = NAME_FIRST_PARAM.match(p)
    if not m:
        return p
    ref, label, name, rest = m.groups()
    ty, refine, default = re.match(r"(.+?)(\s+is\s+.+?)?(\s*=(?!>).*)?$", rest).groups()
    return f"{ref or ''}{label + ' ' if label else ''}{ty} {name}{refine or ''}{default or ''}"


def with_strings(fix: str, orig: str) -> str:
    """Put the string literals that `strip` blanked back into a fix-it."""
    lits = iter(re.findall(r'"(?:[^"\\\n]|\\.)*"', orig))
    return re.sub(r'"[^"\n]*"', lambda m: next(lits, m.group(0)), fix)


def type_first_decl(d) -> str:
    indent, mods, ret, name, params, rest = d
    arrow = ARROW.match(rest)
    if arrow:
        ret, rest = arrow.group(1), rest[arrow.end():]
    rest = " " + rest.strip() if rest.strip() else ""
    return f"{mods}{ret or 'void'} {name}({', '.join(type_first_param(p) for p in split_params(params))}){rest}"

RULES = [
    # (section, regex on stripped code, message)
    ("§3", re.compile(r";"), "semicolon"),
    ("§6", re.compile(r"/\*"), "block comment"),
    ("SPEC §15", re.compile(r"[!=]=\s*null\b"), "null check with ==/!= (use `is null` / `is not null`)"),
    ("SPEC §15", re.compile(r"\b(int|long|short|byte|uint|ulong|ushort|sbyte|float|double|decimal)\b"), "C# alias type name"),
    ("§10", re.compile(r"\bchar\b"), "`char` (use `rune`)"),
    ("SPEC §15", re.compile(r"\bforeach\b"), "`foreach`"),
    ("§2", re.compile(r"\b(unique\s+struct|distinct\s+type|error\s+union|error\s+set|set\s+error)\b"), "modifier-first declaration keyword"),
    ("§13", re.compile(r"\b(noalloc|nosuspend|suspends)\b"), "removed effect keyword"),
    ("§4", re.compile(r"^\s*\[[A-Z]\w*(\(|\])"), "`[Attr]` attribute (use `@attr`)"),
    ("§4", re.compile(r"@[A-Z]"), "attribute names are camelCase"),
    ("§3", re.compile(r"^\s*else\b"), "`else` must follow `}` on the same line"),
    ("§5", re.compile(r"&&|\|\||(?<![\w)\]])!(?!=)"), "symbol boolean in a `.words` project"),
    ("§8", re.compile(r"\.in\(|\.floor\(\)|\.ceil\(\)"), "removed unit conversion form"),
    ("§11", re.compile(r"\brequires\s+value\b"), "`requires value` (use `it`)"),
    ("§7", re.compile(r"case\s+_\s+except"), "`case _ except` (use `case not`)"),
    ("O4", re.compile(r"\bon\s+\.\w+\s*$"), "`on .field` (use `at .field`)"),
    ("O5", re.compile(r"=>\s*(void|never)\b"), "`=>` in a function type (use `->`)"),
    ("§12", re.compile(r"\bLog\.\w+"), "`Log.x` (log is the verb; the level is `as:`)"),
    ("grammar", re.compile(r"\btoString\("), "`toString()` (use `format()`)"),
    ("SPEC", re.compile(r'""\s*\+|\+\s*""'), "string `+` (deferred; use interpolation)"),
    ("§13", re.compile(r"\bcontext\s*\("), "`context (…)` block (use `provide`)"),
    ("§13", re.compile(r",\s*at:\s*\.(debug|info|warning|error)"), "log level with `at:` (use `as:`)"),
    ("§18", re.compile(r"\btry\b[^\n]*\bcatch\b"), "`try` and `catch` on the same call"),
    ("§3", re.compile(r"^\s*(\+|\*|/(?!\*)|%|&|\||\?(?![.?])|:|and\b|or\b)"), "line starts with a binary operator (no waqf join)"),
    ("§2", re.compile(r"^\s*(?:(?:var|let)\s+)?[A-Z]\w*(?:<[^>]*>)?\s+[a-z]\w*\s*=(?!>)"), "type-first binding"),
    ("O9", re.compile(r"\b(?:\w+\s*:\s*(?:" + "|".join(UNITS) + r")|(?:" + "|".join(UNITS) + r")\s+\w+)\s*=\s*-?\d+\s*$"), "bare literal for a unit type"),
    ("F-08", re.compile(r'\btry\s+[A-Z]\w*\(("[^"]*"|\d+)\)'), "`try` on a literal construction"),
    ("keyword", re.compile(r"\b(let|var)\s+(checked|with|in|is|fail|because|provide|become)\b"), "keyword used as a name"),
]

BECAUSE_NEEDED = re.compile(r"@allow\(|\bunsafe\b|Unchecked\(\)|\.expose\(\)|@json\(expose\)")


def check_file(path: Path) -> list[str]:
    problems = []
    raw = path.read_text().split("\n")
    lines = strip(path.read_text())
    blank = True
    stack = ["module"]          # kinds of the enclosing blocks
    parens = 0                  # open `(` carried over from earlier lines (a multi-line parameter list)
    for no, (code, orig) in enumerate(zip(lines, raw), 1):
        ctx = stack[-1]
        loc = f"{path}:{no}"
        if no == 1 and code.startswith("#!"):
            continue
        if code.lstrip().startswith("#:"):
            continue
        for sec, rx, msg in RULES:
            if msg == "type-first binding" and (ctx in FIELD_CTX or parens > 0):
                continue        # a type-first field or parameter, not a local binding
            if msg.startswith("line starts with a binary operator") and ctx in FIELD_CTX and code.lstrip().startswith("*"):
                continue        # a pointer type leading a field or extern declaration (`*mut u8 ptr`)
            if rx.search(code):
                problems.append(f"{loc}: [{sec}] {msg}\n    {orig.strip()}")
        if BECAUSE_NEEDED.search(code) and not re.search(r"\bbecause\s+\"", orig) and "extern" not in code:
            problems.append(f"{loc}: [§4] bypass without `because`\n    {orig.strip()}")
        # parenthesized control-flow heads are allowed only when the condition contains a brace
        m = re.match(r"^\s*(?:\}\s*else\s+)?(if|while|unless)\s*\((.*)\)\s*\{\s*$", code)
        # `for (a, b) in xs` destructures a tuple; only `for (x in xs)` puts `in` inside the parentheses
        f = re.match(r"^\s*for\s*\((?:let |var )?[^()]*\bin\b.*\)\s*\{\s*$", code)
        if (m and "{" not in m.group(2)) or f:
            problems.append(f"{loc}: [SPEC §15] parenthesized condition\n    {orig.strip()}")
        # §2: declarations are type-first; `-> T` and `name: Type` are input forms
        d = decl(code.rstrip(), ctx) if ctx in DECL_CTX else None
        fix = type_first_decl(d) if d else None
        if d and not d[2]:
            problems.append(f"{loc}: [§2] name-first return (input form; the return type leads, `void` when nothing is returned)\n    {orig.strip()}\n    fix-it: {with_strings(fix, orig)}")
        t = re.match(r'^\s*(?:test\s+""\s*|law\s+[a-z]\w*)\((.*)\)', code)
        params = d[4] if d else t.group(1) if t else None
        if params is not None and any(NAME_FIRST_PARAM.match(p) for p in split_params(params)):
            if not d:
                fix = code[:t.start(1)].strip() + ", ".join(type_first_param(p) for p in split_params(params)) + code[t.end(1):]
            problems.append(f"{loc}: [§2] name-first declaration `name: Type` (input form; the type goes first)\n    {orig.strip()}\n    fix-it: {with_strings(fix, orig)}")
        fd = NAME_FIRST_FIELD.match(code.rstrip()) if ctx in ("struct", "union", "interface", "extension") else None
        if fd:
            _, mods, name, rest = fd.groups()
            ty, tail = re.match(r"(.+?)(\s*(?:=>|=|\{).*)?$", rest).groups()
            fix = f"{mods}{ty} {name}{tail or ''}"
            problems.append(f"{loc}: [§2] name-first declaration `name: Type` (input form; the type goes first)\n    {orig.strip()}\n    fix-it: {with_strings(fix, orig)}")
        pl = PAYLOAD.match(code) if ctx == "union" or (ctx == "struct" and code.lstrip().startswith("state ")) else None
        if pl and not d and any(NAME_FIRST_PARAM.match(p) for p in split_params(pl.group(1))):
            fix = code[:pl.start(1)].strip() + ", ".join(type_first_param(p) for p in split_params(pl.group(1))) + ")"
            problems.append(f"{loc}: [§2] name-first declaration `name: Type` (input form; the type goes first)\n    {orig.strip()}\n    fix-it: {with_strings(fix, orig)}")
        # §15 particles: at most one unlabeled required parameter (type-first: `[particle] Type name`)
        if d and d[2] and ctx != "extern" and not any(x in code for x in EXEMPT_DECLS):
            unlabeled = []
            for p in split_params(d[4]):
                p = re.sub(r"^ref\s+", "", p)
                if p in ("this", "") or p.startswith("this ") or NAME_FIRST_PARAM.match(p) or re.search(r"=(?!>)", p):
                    continue        # receiver, input form (reported above), or optional with a default
                words = p.split()
                if words[0] in PARTICLES:
                    continue
                if len(words) >= 3 and re.fullmatch(r"[a-z]\w*", words[0]) and not BUILTIN.fullmatch(words[0]) and words[1] != "is":
                    problems.append(f"{loc}: [§15] `{words[0]}` is not a particle\n    {orig.strip()}")
                    continue
                unlabeled.append(words[words.index("is") - 1] if "is" in words else words[-1])
            if len(unlabeled) > 1:
                problems.append(f"{loc}: [§15] {len(unlabeled)} unlabeled parameters ({', '.join(unlabeled)})\n    {orig.strip()}")
        # §3: a blank line ends a statement; flag a dangling continuation before a blank line
        if code.strip() == "" and not blank:
            prev = lines[no - 2].rstrip()
            if re.search(r"(\+|-|\*|(?<!\*)/|,|=|=>|\band|\bor|\()\s*$", prev) and not prev.strip().startswith("//"):
                problems.append(f"{path}:{no - 1}: [§3] statement continues into a blank line\n    {raw[no - 2].strip()}")
        blank = code.strip() == ""
        # maintain the block stack
        kind = "block"
        m = re.match(r"^\s*(?:public\s+)?(struct|union|interface|extension|extern)\b", code)
        if m:
            kind = m.group(1)
        for ch in code:
            if ch == "{":
                stack.append(kind if kind != "block" or len(stack) == 0 else kind)
                kind = "block"
            elif ch == "}" and len(stack) > 1:
                stack.pop()
            elif ch == "(":
                parens += 1
            elif ch == ")" and parens > 0:
                parens -= 1
    return problems


def self_test(root: Path) -> int:
    """Every snippet in fail/ must trigger the diagnostic named on its `// expect:` line."""
    failed = 0
    files = sorted((root / "fail").glob("*.byn.cs"))
    for f in files:
        expect = re.search(r"// expect: (.+)", f.read_text()).group(1).strip()
        got = check_file(f)
        if not any(expect in g for g in got):
            failed += 1
            print(f"MISSED {f.name}: expected '{expect}', got {got or 'nothing'}")
        elif not all(expect in g for g in got):
            failed += 1
            print(f"EXTRA {f.name}: expected only '{expect}', got {got}")
    print(f"self-test: {len(files) - failed}/{len(files)} compile-fail snippets caught, each by its own rule only")
    return 1 if failed else 0


def main() -> int:
    if "--self-test" in sys.argv:
        return self_test(Path(sys.argv[2] if len(sys.argv) > 2 else "."))
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
    files = sorted(p for p in root.rglob("*.byn.cs") if "fail" not in p.parts)
    problems = [p for f in files for p in check_file(f)]
    for p in problems:
        print(p)
    print(f"\n{len(files)} files, {len(problems)} problems")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
