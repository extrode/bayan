// package.byn — the Sūq application (rename *.byn.cs → *.byn; .cs is for preview highlighting)
Package {
    name: "suq",
    version: "0.1.0",
    edition: 2026,
    capabilities: [.net, .fs, .clock, .random, .env],
    dependencies: [
        "suq.pricing": Dependency { path: "pricing", capabilities: [] },
        "std.db.pg": Dependency { version: "0.1", capabilities: [.net] },
        "std.http": Dependency { version: "0.1", capabilities: [.net] },
    ],
    native: [
        "sodium": Native { link: "libsodium", version: "1.0.20" },
    ],
    laws: Laws { enabled: true },     // src/lib/stats.byn declares laws
    diagnostics: Diagnostics { prefix: "SUQ" },
    style: Style {
        booleans: .words,
    },
    testing: Testing {
        coverage: 90pct,
        mutationScore: 80pct,
    },
}
