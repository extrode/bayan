// expect: name-first declaration
// fix-it: `timeout(Millis after)` (`bayan fmt` puts the type first)
union error CarrierError {
    timeout(after: Millis)
}
