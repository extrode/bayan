// expect: `{ get }`
// fix-it: `string name`
interface IShipper {
    string name { get }
}
