// expect: type-first binding
// fix-it: `let w: Grams = 0g`
let Grams w = 0g
