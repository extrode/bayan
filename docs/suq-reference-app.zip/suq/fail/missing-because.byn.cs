// expect: bypass without `because`
let raw = key.expose()
