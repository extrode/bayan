// expect: `[Attr]` attribute
[Derive(Json)]
struct Line {
}
