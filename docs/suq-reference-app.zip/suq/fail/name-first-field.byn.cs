// expect: name-first declaration
// fix-it: `Sku sku` (`bayan fmt` puts the type first)
struct Line {
    sku: Sku
}
