// expect: string `+`
// fix-it: `$"Hello {name}"`
let s = "Hello " + name
