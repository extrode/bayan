// expect: `requires value`
type distinct Age = i32 requires value in 0..=150
