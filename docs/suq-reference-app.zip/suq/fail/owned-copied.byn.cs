// expect: `owned()`/`copied()`
// fix-it: `items.copy()`
let mine = items.owned()
