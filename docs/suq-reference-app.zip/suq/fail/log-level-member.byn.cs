// expect: `Log.x`
// fix-it: `log("weighing", as: .debug)`
Log.debug("weighing")
