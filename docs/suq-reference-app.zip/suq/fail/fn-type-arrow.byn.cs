// expect: `=>` in a function type
struct Checkout {
    onPaid: Order => void uses net
}
