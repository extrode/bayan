// expect: `=>` in a function type
// fix-it: `type OnPaid = Order -> void uses net`
type OnPaid = Order => void uses net
