// expect: `=>` in a function type
// fix-it: `(Order -> void uses net) onPaid`
struct Checkout {
    (Order => void uses net) onPaid
}
