// expect: block comment
// fix-it: rewrite as `//` lines
/* weighs the parcel */
