// expect: `char` (use `rune`)
let c: char = 'a'
