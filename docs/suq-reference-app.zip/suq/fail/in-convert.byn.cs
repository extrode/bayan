// expect: removed unit conversion form
// fix-it: `size.rounded<KiB>()`
log($"{size.in(KiB)}")
