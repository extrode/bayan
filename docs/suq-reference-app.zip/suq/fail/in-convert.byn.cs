// expect: removed unit conversion form
// fix-it: `size.convert(to: KiB)`
log($"{size.in(KiB)}")
