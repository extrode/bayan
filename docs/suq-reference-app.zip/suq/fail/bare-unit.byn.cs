// expect: bare literal for a unit type
// fix-it: `0g`
let w: Grams = 0
