// expect: `context (…)` block
context (net: fake) {
}
