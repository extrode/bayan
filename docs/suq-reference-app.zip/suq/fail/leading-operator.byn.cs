// expect: line starts with a binary operator
let total = subtotal
    + shipping
