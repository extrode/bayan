// expect: log level with `at:`
log("retry", at: .debug)
