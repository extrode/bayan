// expect: `on .field`
struct Form {
    requires password != username on .password
}
