// expect: attribute names are camelCase
@Derive(Json)
struct Line {
}
