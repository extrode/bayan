// expect: `foreach`
foreach line in lines {
}
