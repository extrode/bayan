// expect: keyword used as a name
let checked = 1
