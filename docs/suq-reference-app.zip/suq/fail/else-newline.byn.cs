// expect: `else` must follow `}` on the same line
if ok {
}
else {
}
