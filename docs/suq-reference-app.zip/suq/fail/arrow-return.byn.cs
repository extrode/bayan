// expect: name-first return
// fix-it: `public Grams shippingWeight(Order order) {` (`bayan fmt` moves the return type first)
public shippingWeight(Order order) -> Grams {
}
