// expect: `using let`
// fix-it: `let conn = try db.open()`
using let conn = try db.open()
