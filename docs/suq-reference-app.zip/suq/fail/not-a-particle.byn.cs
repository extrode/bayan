// expect: is not a particle
// fix-it: use one of from, to, at, by, for, as
public copy(src: Path, into dst: Path) {
}
