// expect: is not a particle
// fix-it: use one of from, to, at, by, for, as
public void copy(Path src, into Path dst) {
}
