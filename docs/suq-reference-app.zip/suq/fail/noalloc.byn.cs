// expect: removed effect keyword
// fix-it: delete it; no `uses` clause already means pure
public crc(data: Span<u8>) -> u32 noalloc {
}
