// expect: per-line `state`
// fix-it: `states { draft placed }`
struct Order {
    state draft
}
