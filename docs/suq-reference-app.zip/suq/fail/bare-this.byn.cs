// expect: bare `this` receiver
// fix-it: `void close(move this)`
struct Conn {
    public void close(this) {
    }
}
