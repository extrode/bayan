// expect: `toString()`
let s = total.toString()
