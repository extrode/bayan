// expect: parenthesized condition
// fix-it: `for x in xs {`
for (let x in xs) {
}
