// expect: removed unit rounding form
// fix-it: `weight.rounded<Kilograms>()`
let kg = weight.roundUp()
