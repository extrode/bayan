// expect: statement continues into a blank line
let total = subtotal +

    shipping
