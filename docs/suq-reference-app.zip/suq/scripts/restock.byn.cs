#!/usr/bin/env bayan
#:io blocking
// restock.byn — load a supplier's stock file into `products.stock`.
//
//   bayan run scripts/restock.byn -- --file supplier.csv --dry-run
//
// Scripting mode: top-level statements, `try` at the top exits with a non-zero code
// and prints the error.

import std.db.pg
import std.io
import suq.model.{ Sku }

@derive(Args)
struct Options {
    /// CSV with `sku,qty` lines; `#` starts a comment line.
    Path file
    /// Roll back at the end instead of committing.
    bool dryRun = false
    /// Stop after this many bad lines.
    i32 maxErrors = 10
        requires it in 0..=1000
}

@derive(Config)
struct Env {
    Secret<string> databaseUrl
}

type distinct StockQty = i32 requires it in 0..=100000

let options = try Options.parse(Args.current)
let env = try Env.load(prefix: "SUQ_")

using let pool = try Pool.connect(env.databaseUrl)
using let conn = try pool.open()
using let tx = try conn.begin()
defer failing tx.rollback()
defer log("dry run: rolled back") if options.dryRun      // evaluated now, when registered

var updated: i64 = 0
var bad = 0
var lineNo = 0
// The file's content is from a user-chosen path, so each line is `Untrusted<string>`.
// Lines are counted before skipping comments, so error line numbers match the file.
for try raw in try File.open(options.file).lines() {
    lineNo += 1
    let line = raw.trim()
    continue if line.isEmpty or line.startsWith("#")
    let parts = line.split(',')
    let sku = Sku.tryParse(parts[0].trim())
    let qty = parts.length == 2 ? StockQty.tryParse(parts[1].trim()) : null
    if sku is null or qty is null {          // after this block, both are narrowed to non-null
        log($"line {lineNo}: skipped", as: .warning)
        bad += 1
        fail BadInput.tooManyErrors(count: bad) if bad > options.maxErrors
        continue
    }
    updated += try tx.execute(sql"update products set stock = $2 where sku = $1", sku.value, qty.value)
}

if options.dryRun {
    tx.rollback()
} else {
    try tx.commit()
}
print($"{updated} products updated, {bad} lines skipped")

union error BadInput {
    tooManyErrors(i32 count)
}
