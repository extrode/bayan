// gateway.byn — charging cards and reading payment webhooks
module suq.payments

import std.http
import std.json
import suq.model
import suq.pricing.{ Money }

public union error PaymentError {
    declined(code: string)
    unavailable
    malformedReply
}

@derive(Json)
public union ChargeStatus {
    succeeded
    declined
}

/// Every field is a type with `requires` or a plain union, so decoding a third-party
/// body gives a trusted `ChargeReply`, not `Untrusted<ChargeReply>` (O10).
@derive(Json)
struct ChargeReply {
    id: PaymentId
    status: ChargeStatus
}

@derive(Json)
struct ChargeRequest {
    amountCents: i64
    currency: string
    source: CardToken
    idempotencyKey: string
}

/// Holds a `unique` key, so the gateway is itself move-only (F-12).
public struct unique Gateway {
    public base: Url
    public apiKey: Secret<string>
    public webhookKey: SecretKey
    public http: Http.Client

    /// Charges a card once. The idempotency key makes retries safe on the gateway's side.
    public charge(amount: Money, from card: CardToken, for order: OrderId) -> PaymentId
        fails PaymentError uses net, alloc, suspend {
        let request = ChargeRequest {
            amountCents: amount.cents,
            currency: amount.currency.code,
            source: card,
            idempotencyKey: $"order-{order.value}",
        }
        let auth = HeaderValue.bearer(apiKey.expose() because "sent only to the payment gateway, over TLS")
        let response = http.post(base.resolve("/v1/charges"), json: request, headers: [.authorization: auth]) catch _ => fail .unavailable
        fail .unavailable if response.status.isServerError
        let reply = ChargeReply.fromJson(response.body, maxDepth: 3, maxBytes: 8KiB) catch _ => fail .malformedReply
        return reply.status switch {
            .succeeded => reply.id,
            .declined => fail .declined(code: readDeclineCode(response)),
        }
    }
}

readDeclineCode(response: Http.Response) -> string uses alloc {
    let code = response.header("x-decline-code") ?? return "unknown"
    return code.trustUnchecked() because "shown to staff in the admin only, never rendered into a page"
}

// ── Webhooks ───────────────────────────────────────────────────────

@derive(Json)
public union PaymentEventKind {
    refunded
    chargeback
}

@derive(Json)
public struct PaymentEvent {
    public payment: PaymentId
    public kind: PaymentEventKind
}

public union error WebhookError {
    forged
    unreadable
}

/// Authenticates first, then decodes. A body that fails the MAC is never parsed.
public readWebhook(hook: Webhook, by key: SecretKey) -> PaymentEvent fails WebhookError uses alloc {
    fail .forged unless hook.isAuthentic(by: key)
    return PaymentEvent.fromJson(hook.body, maxDepth: 2, maxBytes: 4KiB) catch _ => fail .unreadable
}
