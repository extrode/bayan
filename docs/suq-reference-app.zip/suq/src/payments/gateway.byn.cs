// gateway.byn — charging cards and reading payment webhooks
module suq.payments

import std.http
import std.json
import suq.model
import suq.pricing.{ Money }

public union error PaymentError {
    declined(string code)
    unavailable
    malformedReply
}

@derive(Json)
public union ChargeStatus {
    succeeded
    declined
}

/// Every field is a type with `requires` or a plain union, so decoding a third-party
/// body gives a trusted `ChargeReply`, not `Untrusted<ChargeReply>` (O10).
@derive(Json)
struct ChargeReply {
    PaymentId id
    ChargeStatus status
}

@derive(Json)
struct ChargeRequest {
    i64 amountCents
    string currency
    CardToken source
    string idempotencyKey
}

/// Holds a `unique` key, so the gateway is itself move-only (F-12).
public struct unique Gateway {
    public Url base
    public Secret<string> apiKey
    public SecretKey webhookKey
    public Http.Client http

    /// Charges a card once. The idempotency key makes retries safe on the gateway's side.
    public PaymentId charge(Money amount, from CardToken card, for OrderId order)
        fails PaymentError uses net, alloc, suspend {
        let request = ChargeRequest {
            amountCents: amount.cents,
            currency: amount.currency.code,
            source: card,
            idempotencyKey: $"order-{order.value}",
        }
        let auth = HeaderValue.bearer(apiKey.expose() because "sent only to the payment gateway, over TLS")
        let response = http.post(base.resolve("/v1/charges"), json: request, headers: [.authorization: auth]) catch _ => fail .unavailable
        fail .unavailable if response.status.isServerError
        let reply = ChargeReply.fromJson(response.body, maxDepth: 3, maxBytes: 8KiB) catch _ => fail .malformedReply
        return reply.status switch {
            .succeeded => reply.id,
            .declined => fail .declined(code: readDeclineCode(response)),
        }
    }
}

string readDeclineCode(Http.Response response) uses alloc {
    let code = response.header("x-decline-code") ?? return "unknown"
    return code.trustUnchecked() because "shown to staff in the admin only, never rendered into a page"
}

// ── Webhooks ───────────────────────────────────────────────────────

@derive(Json)
public union PaymentEventKind {
    refunded
    chargeback
}

@derive(Json)
public struct PaymentEvent {
    public PaymentId payment
    public PaymentEventKind kind
}

public union error WebhookError {
    forged
    unreadable
}

/// Authenticates first, then decodes. A body that fails the MAC is never parsed.
public PaymentEvent readWebhook(Webhook hook, by SecretKey key) fails WebhookError uses alloc {
    fail .forged unless hook.isAuthentic(by: key)
    return PaymentEvent.fromJson(hook.body, maxDepth: 2, maxBytes: 4KiB) catch _ => fail .unreadable
}
