// sodium.byn — the slice of libsodium Sūq needs: HMAC verification, password hashing,
// and guarded memory for keys
module suq.payments

/// C declarations, linked through `native` in package.byn. Extern parameters mirror the
/// C signature, so they are positional (F-09).
extern "sodium" {
    sodium_init() -> i32
    sodium_malloc(size: usize) -> *mut u8 uses alloc
    sodium_free(ptr: *mut u8)
    crypto_auth_hmacsha256_verify(tag: *u8, msg: *u8, len: u64, key: *u8) -> i32
    crypto_pwhash_str(out: *mut u8, pass: *u8, len: u64, ops: u64, mem: usize) -> i32 uses alloc
    crypto_pwhash_str_verify(hash: *u8, pass: *u8, len: u64) -> i32 uses alloc
}

// Counts are plain integers; byte units are for sizes and offsets (open question O2).
const hmacKeyLength = 32
const hmacTagLength = 32
const pwhashLength = 128

public union error KeyError {
    wrongLength(expected: i64, got: i64)
    outOfMemory
    initFailed
}

/// libsodium must be initialised before any other call. Idempotent and thread-safe.
ensureSodium() -> bool {
    return unsafe because "sodium_init takes no arguments and may be called repeatedly" { sodium_init() } >= 0
}

/// A key in guarded memory (`sodium_malloc`: guard pages, zeroed on free).
/// Move-only: there is exactly one owner, and dropping it frees and wipes the key.
public struct unique SecretKey {
    ptr: *mut u8
    len: i64

    public static load(bytes: Secret<Span<u8>>) -> SecretKey fails KeyError uses alloc {
        fail .initFailed unless ensureSodium()
        // The config's own copy stays in ordinary memory until exit (F-33).
        let raw = bytes.expose() because "copied straight into guarded memory"
        fail .wrongLength(expected: hmacKeyLength, got: raw.length) if raw.length != hmacKeyLength
        let ptr = unsafe because "sodium_malloc returns null or a block of the requested size" {
            sodium_malloc(usize(raw.length))
        }
        fail .outOfMemory if ptr is null
        unsafe because "ptr was just allocated with raw.length bytes" {
            copyMemory(from: raw.pointer, to: ptr, count: raw.length)
        }
        return SecretKey { ptr, len: raw.length }
    }

    public drop(ref this) {
        unsafe because "ptr came from sodium_malloc and is freed exactly once (unique)" {
            sodium_free(ptr)
        }
    }
}

/// A webhook delivery: the raw body and the tag from its `X-Signature` header.
public struct Webhook {
    public body: Untrusted<Span<u8>>
    public tag: Untrusted<Span<u8>>

    /// Constant-time HMAC-SHA256 check. Pure: no `uses`.
    public isAuthentic(by key: SecretKey) -> bool {
        return false if tag.length != hmacTagLength
        let msg = body.trustUnchecked() because "only read by the constant-time MAC check"
        let mac = tag.trustUnchecked() because "length checked above; compared in constant time"
        let result = unsafe because "tag is 32 bytes; key.ptr holds 32 bytes; msg length passed explicitly" {
            crypto_auth_hmacsha256_verify(mac.pointer, msg.pointer, u64(msg.length), key.ptr)
        }
        return result == 0
    }
}

/// An Argon2id hash in libsodium's string format. Safe to store and to log.
public type distinct PasswordHash = string requires it.startsWith("$argon2id$")

public union error HashError {
    failed
}

public hashPassword(password: string) -> PasswordHash fails HashError uses alloc {
    fail .failed unless ensureSodium()
    var out = FixedList<u8>(capacity: pwhashLength)
    let status = unsafe because "out has crypto_pwhash_STRBYTES bytes" {
        crypto_pwhash_str(out.pointer, password.pointer, u64(password.length), 2, usize(64MiB / 1B))
    }
    fail .failed if status != 0
    return PasswordHash(out.decodeCString()) catch _ => fail .failed
}

test "a tampered body is not authentic" {
    using let key = try SecretKey.load(Secret(Span(repeating: 7, count: 32)))
    let good = Webhook { body: Untrusted(b"{\"id\":1}"), tag: Untrusted(sampleTag) }
    let bad = Webhook { body: Untrusted(b"{\"id\":2}"), tag: Untrusted(sampleTag) }
    assert good.isAuthentic(by: key)
    assert not bad.isAuthentic(by: key)
}

/// HMAC-SHA256 of `{"id":1}` under 32 bytes of 0x07, computed once at compile time.
const sampleTag = comptime Hmac.sha256(b"{\"id\":1}", by: Span(repeating: 7, count: 32))
