// address.byn — delivery addresses (Malaysia only in v1)
module suq.model

@derive(Json)
public union MalaysianState {
    johor
    kedah
    kelantan
    melaka
    negeriSembilan
    pahang
    penang
    perak
    perlis
    sabah
    sarawak
    selangor
    terengganu
    kualaLumpur
    labuan
    putrajaya
}

/// Checked at construction. The checkout form autosaves an `Address.Patch`
/// (every field optional, no rules) and calls `complete()` at payment.
@derive(Json)
public struct Address {
    public string name
        requires it.runeCount in 1..=80
    public string line1
        requires it.runeCount in 1..=120
    public string? line2
        requires it is null or it.runeCount <= 120
    public string city
        requires it.runeCount in 1..=60
    public MalaysianState state           // a field, not typestate: `state` is contextual (O8)
    public Postcode postcode

    /// Sabah, Sarawak and Labuan postcodes start with 8 or 9.
    requires not (state is .sabah or .sarawak or .labuan) or
        postcode.value.startsWith("8") or postcode.value.startsWith("9") at .postcode
}

test "an incomplete draft reports every missing and broken field" {
    let draft = Address.Patch { name: "Aisyah", postcode: Postcode("50450") }
    let address = draft.complete() catch e => {
        assert e.violations.map(it.field).sorted() == [.line1, .city, .state]
        return
    }
    panic($"expected violations, got {address}")
}

test "east Malaysian postcodes" {
    let ok = try Address {
        name: "Ah Kow",
        line1: "Lot 5, Jalan Gaya",
        city: "Kota Kinabalu",
        state: .sabah,
        postcode: Postcode("88000"),
    }
    assert ok with { postcode: Postcode("50450") } fails ValidationError<Address>
}
