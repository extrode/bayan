// ids.byn — identifiers and validated text. A value that exists is a valid value.
module suq.model

/// `ABC-1234`: three capital letters, a dash, four digits. Compiled at compile time.
const skuShape = comptime Regex.compile("^[A-Z]{3}-[0-9]{4}$")

public type distinct Sku = string requires it.matches(skuShape)
public type distinct OrderId = i64 requires it > 0
public type distinct CustomerId = i64 requires it > 0
public type distinct PaymentId = string requires it.length in 1..=64 and it.isAsciiPrintable
public type distinct TrackingId = string requires it.length in 8..=40 and it.isAsciiAlphanumeric
public type distinct CardToken = string requires it.startsWith("tok_") and it.length in 8..=64
public type distinct Email = string requires it.isEmailShaped and it.length <= 254
public type distinct Postcode = string requires it.length == 5 and it.isAsciiDigits

/// A page size from a query string. Sizes from outside need a bound (SPEC §17).
public type distinct PageSize = i32 requires it in 1..=100

test "sku shape" {
    assert Sku.tryFrom("TEA-0001") is not null
    assert Sku.tryFrom("tea-0001") is null
    assert Sku.tryFrom("TEA-01") is null
}
