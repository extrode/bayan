// stats.byn — small generic library: top-N, sales tallies, staff permissions
module suq.lib

import suq.model.{ Sku }

/// Keeps the `dst.capacity` largest items, largest first, without sorting everything.
/// Generic over any comparable type; checked against `Comparable` at the definition.
/// The allocating `selectTop(from:)` is derived.
public void selectTopInto<T>(ref FixedList<T> dst, from Span<T> items) fails CapacityError where T: Comparable {
    dst.clear()
    for item in items {
        if dst.length < dst.capacity {
            try dst.insert(item, at: dst.firstIndex(it < item) ?? dst.length)
        } else if item > dst[^1] {
            dst.removeLast()
            try dst.insert(item, at: dst.firstIndex(it < item) ?? dst.length)
        }
    }
}

/// Units sold per SKU over a period.
public struct Tally {
    public Map<Sku, i64> counts

    /// Form II (causative, contract-only): idempotent, returns nothing.
    public void ensureCapacity(ref this, i32 entries) uses alloc {
        counts.reserve(entries)
    }

    public void record(ref this, i32 qty, for Sku sku) uses alloc {
        counts.update(sku, by: it + qty, from: 0)
    }

    /// Form III (with another): combines two tallies.
    public Tally mergeWith(Tally other) uses alloc {
        // Owning collections are never copied implicitly (F-14).
        var merged = Tally { counts: counts.copied() }
        for (sku, n) in other.counts {
            merged.counts.update(sku, by: it + n, from: 0)
        }
        return merged
    }

    /// Form V (reflexive, `ref this`): drops SKUs that sold nothing.
    /// The copying `pruned()` is derived and adds `alloc`.
    public void prune(ref this) {
        counts.removeAll(it.value == 0)
    }

    public bool isEmpty => counts.isEmpty
}

law mergeCommutes(Tally a, Tally b) {
    a.mergeWith(b) == b.mergeWith(a)
}

law mergeIdentity(Tally a) {
    a.mergeWith(Tally { counts: [:] }) == a
}

/// Staff permissions: a `Set` of a union replaces C# `[Flags]` enums.
@derive(Json)
public union Permission {
    refund
    editPrices
    viewReports
    manageStaff
}

public const packer: Set<Permission> = []
public const supervisor: Set<Permission> = [.refund, .viewReports]
public const owner: Set<Permission> = [.refund, .editPrices, .viewReports, .manageStaff]

/// A staff member embeds `Person`: `name` and `email` are promoted.
public struct Person {
    public string name
    public string email
}

public struct Staff {
    embed Person                    // promoted fields keep Person's own visibility
    public Set<Permission> permissions

    public bool canRefund => permissions.contains(.refund)
}

/// Reports implement two hooks; `render` is a default method shared by all of them.
interface IReport {
    void writeHeader(ref StrBuf dst)
    void writeRow(ref StrBuf dst, at Index i)
    i32 rows

    void render(ref StrBuf dst) {
        writeHeader(ref dst)
        for i in 0..rows {
            writeRow(ref dst, at: i)
        }
    }
}

test "top three, largest first" {
    var top = FixedList<i32>(capacity: 3)
    try selectTopInto(ref top, from: [5, 1, 9, 3, 7, 9])
    assert top == [9, 9, 7]
}

test "a tally ignores order" {
    var a = Tally { counts: [:] }
    var b = Tally { counts: [:] }
    a.record(2, for: Sku("TEA-0001"))
    b.record(3, for: Sku("TEA-0001"))
    b.record(0, for: Sku("MUG-0001"))
    let both = a.mergeWith(b).pruned()
    assert both.counts == [Sku("TEA-0001"): 5]
}

test "staff permissions" {
    let s = Staff { name: "Mei", email: "mei@suq.example", permissions: supervisor }
    assert s.canRefund
    assert s.name == "Mei"
    assert not owner.isDisjoint(from: supervisor)
}
