// carrier.byn — booking parcels with a courier: effects, retries, deadlines, fibers
module suq.carrier

import std.http
import std.json
import suq.model
import suq.pricing.{ Grams, Kilograms }
import suq.warehouse.{ PackError }

public union error CarrierError {
    timeout(Millis after)
    rejected(string reason)
    unavailable
}

/// Worth retrying: everything except an outright rejection.
public union error Retryable = CarrierError except .rejected

public union error ShipError = CarrierError, PackError

@derive(Json)
public struct Parcel {
    public OrderId order
    public Symbol box
    public Grams weight

    /// Carriers bill whole kilograms, rounded up.
    public Kilograms billedWeight => weight.ceiling<Kilograms>()
}

/// Effects on interface methods are an upper bound (SPEC §13, option A):
/// a fake may use fewer, never more.
public interface IShipper {
    TrackingId book(Parcel parcel) fails CarrierError uses net, alloc, suspend
    string name => "carrier"
}

/// The courier's reply, generated at compile time from a real sample.
/// Third-party responses are `Untrusted` (SPEC §17), and this type has free strings,
/// so decoding it gives `Untrusted<BookingReply>` (O10).
type BookingReply = comptime Json.typeFrom("samples/laju-booking-reply.json")

/// A Malaysian courier's REST API.
public struct LajuExpress : IShipper {
    public Url base
    public Secret<string> apiKey
    public Http.Client http

    public string name => "Laju Express"

    public TrackingId book(Parcel parcel) fails CarrierError uses net, alloc, suspend {
        let auth = HeaderValue.bearer(apiKey.expose() because "sent only to the courier, over TLS")
        let response = http.post(base.resolve("/v1/shipments"), json: parcel, headers: [.authorization: auth]) catch switch {
            HttpError.timeout e => fail .timeout(after: e.after),
            HttpError => fail .unavailable,
        }
        fail .unavailable if response.status.isServerError
        let reply = BookingReply.fromJson(response.body, maxDepth: 4, maxBytes: 16KiB) catch _ => fail .rejected(reason: "unreadable reply")
        // `reply.accepted` is `Untrusted<bool>`; only the comparison is a clean fact (F-11).
        fail .rejected(reason: "booking refused") unless reply.accepted == true
        // Constructing a type with `requires` is the only thing that removes taint.
        return TrackingId(reply.trackingNumber) catch _ => fail .rejected(reason: "malformed tracking number")
    }
}

/// Books with retries on transient failures. Waiting goes through `clock`,
/// so under a fake clock the test runs instantly.
@forms(Op)
public TrackingId bookWithRetry(Parcel parcel, by dyn IShipper shipper, i64 attempts = 3)
    fails CarrierError uses net, alloc, suspend, clock {
    var wait = 200ms
    for attempt in 1..attempts {
        let tracking = shipper.book(parcel) catch switch {
            Retryable => null,
            CarrierError e => fail e,
        }
        return tracking if tracking is not null
        log($"retrying {parcel.order} ({parcel.billedWeight}) with {shipper.name}, attempt {attempt} of {attempts}", as: .warning)
        Clock.sleep(wait)
        wait *= 2
    }
    return try shipper.book(parcel)
}

/// Books every parcel concurrently, one fiber each. The group's deadline covers the
/// whole batch; leaving the scope early (a failure, or the deadline) cancels the rest.
public List<TrackingId> bookAll(ReadOnlySpan<Parcel> parcels, by dyn IShipper shipper)
    fails CarrierError uses net, alloc, suspend, clock {
    let group = Io.group<TrackingId>(timeout: 5s)
    for parcel in parcels {
        group.spawn(() => bookWithRetry(parcel, by: shipper))
    }
    return await group.all() catch switch {
        Canceled => fail .timeout(after: 5s),
        CarrierError e => fail e,
    }
}

/// Failed bookings wait here as plain values (maṣdar, `BookWithRetryOp`), not closures.
public struct Outbox {
    List<BookWithRetryOp> pending

    public static Outbox empty() => Outbox { pending: [] }

    public void append(ref this, BookWithRetryOp op) uses alloc {
        pending.append(op)
    }

    /// Takes every pending entry, leaving the outbox empty.
    public List<BookWithRetryOp> drain(ref this) {
        return pending.drain()
    }
}

/// Retries every pending booking and returns the ones that succeeded; failures go back in.
/// The lock is held only to take and return entries: a guard alive across a suspension
/// point is a compile error (SPEC §13.4).
public List<(Parcel, TrackingId)> retryOutbox(Mutex<Outbox> outbox) uses net, alloc, suspend, clock {
    let batch = outbox.lock().drain()             // the guard is a temporary: released here
    var booked = List<(Parcel, TrackingId)>()
    for op in batch {
        let tracking = op.tryInvoke()
        if tracking is not null {
            booked.append((op.parcel, tracking))
        } else {
            outbox.lock().append(op)
        }
    }
    return booked
}

// ── Tests: effects replaced with `provide` ─────────────────────────

const sampleParcel = Parcel { order: OrderId(42), box: "M", weight: 4800g }
const bookingSample = comptime File.read("samples/laju-booking-reply.json")

/// Builds the courier client over whatever `net` handler is provided.
LajuExpress connectLaju() => LajuExpress {
    base: Url("https://api.laju.example"),
    apiKey: Secret("test-key"),
    http: Http.Client(),
}

test "retries a timeout, then succeeds" {
    let net = FakeNet(replies: [.timeout, .json(200, bookingSample)])
    let logs = LogRecorder()
    provide net: net, clock: FakeClock(at: Date(year: 2026, month: 12, day: 1)), log: logs {
        let id = try bookWithRetry(sampleParcel, by: connectLaju())
        assert id.value == "EX123456789MY"
    }
    assert net.calls == 2
    assert logs.count(it.level is .warning) == 1
}

test "a rejection is not retried" {
    let net = FakeNet(replies: [.json(422, """{"accepted": false, "trackingNumber": ""}""")])
    provide net: net, clock: FakeClock(at: Date(year: 2026, month: 12, day: 1)) {
        assert bookWithRetry(sampleParcel, by: connectLaju()) fails CarrierError.rejected
    }
    assert net.calls == 1
}

test "the batch deadline cancels slow bookings" {
    let net = FakeNet(replies: [.delay(10s)])
    provide net: net, clock: FakeClock(at: Date(year: 2026, month: 12, day: 1)) {
        assert bookAll([sampleParcel, sampleParcel], by: connectLaju()) fails CarrierError.timeout
    }
}
