// main.byn — wiring: config, real effect handlers, routes
module suq

import std.db.pg
import std.http
import suq.carrier
import suq.db
import suq.lib
import suq.model
import suq.payments
import suq.pricing
import suq.storefront
import suq.warehouse

/// Read from `SUQ_*` environment variables at startup. Startup config is trusted.
@derive(Config)
struct AppConfig {
    Secret<string> databaseUrl
    u16 port = 8080
    Url courierUrl
    Secret<string> courierKey
    Url gatewayUrl
    Secret<string> gatewayKey
    Secret<List<u8>> webhookKey  // owned bytes: a mutable `Span` field would make the struct unique (§31)
}

/// Stored handler type. Its effects are an upper bound for every route (option A).
type Handler = Request -> Response uses db, alloc, suspend, clock

const malaysia = Policy {
    currency: .myr,
    taxRate: 8pct,
    promotions: [
        .freeShippingOver(threshold: Money { cents: 15000, currency: .myr }),
        .percentOff(rate: 10pct, minimum: Money { cents: 30000, currency: .myr }),
    ],
    bands: [
        ShippingBand { upTo: 1kg, fee: Money { cents: 800, currency: .myr } },
        ShippingBand { upTo: 5kg, fee: Money { cents: 1500, currency: .myr } },
        ShippingBand { upTo: 20kg, fee: Money { cents: 3500, currency: .myr } },
    ],
}

union error StartupError = ConfigError, DbError, KeyError, HttpError

public void main() fails StartupError {                  // main infers its effects, bounded by the package
    // Must be the first statement; assigned once; libraries can't set it.
    // `PanicHandler` is `Panic -> void uses console`: it may write to stderr and nothing else.
    Panic.handler = p => Stderr.write(p)

    let config = try AppConfig.load(prefix: "SUQ_")
    provide net: Net.system(), clock: Clock.system(), random: Random.system() {
        let pool = try Pool.connect(config.databaseUrl)
        let http = Http.Client(timeout: 10s)
        var shop = Storefront {
            orders: OrdersStore { db: pool },
            drafts: DraftStore { db: pool },
            users: UsersStore { db: pool },
            catalog: Catalog { db: pool },
            sessions: CookieSessions { db: pool },
            gateway: Gateway {
                base: config.gatewayUrl,
                apiKey: config.gatewayKey,
                webhookKey: try SecretKey.load(config.webhookKey),
                http,
            },
            shipper: LajuExpress { base: config.courierUrl, apiKey: config.courierKey, http },
            outbox: Mutex(Outbox.empty()),
            policy: malaysia,
            slots: [:],
            paid: OrderPaid(),
        }
        let audit = shop.paid.subscribe(by: o => log($"order {o.id} paid"))    // unique handle: leaving the scope unsubscribes (F-58)
        log($"starting on :{config.port}, database {config.databaseUrl}")    // the URL prints as ***

        var router = Router<Handler>()
        router.get("/products", by: shop.catalog.search)
        router.get("/search", by: shop.catalog.renderSearchPage)
        router.post("/signup", by: Request req => signUp(req, by: shop.users))
        router.put("/orders/{id}/address", by: shop.saveAddress)
        router.post("/orders/{id}/pay", by: shop.pay)
        router.get("/orders/{id}/track", by: shop.track)
        router.get("/orders/{id}", by: shop.renderOrderPage)
        router.post("/webhooks/payments", by: shop.receivePaymentWebhook)

        // Structured concurrency: the sweeper can't outlive this scope, and leaving it cancels the sweeper.
        let background = Io.group<never>()
        background.spawn(() => shop.sweepOutbox())
        try Server.run(router, at: config.port)
    }
}

/// Sessions in Postgres, keyed by an HttpOnly cookie.
struct CookieSessions : ISessions {
    Pool db

    public CustomerId? identify(Request req) uses db, alloc, suspend {
        let token = req.cookie("suq_session") ?? return null
        let conn = db.open() catch _ => return null
        let id = conn.query<i64>(sql"select customer_id from sessions where token = $1 and expires_at > now()", token).tryFirst() catch _ => return null
        return CustomerId.tryFrom(id ?? return null)
    }
}
