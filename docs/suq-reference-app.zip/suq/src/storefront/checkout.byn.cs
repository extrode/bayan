// checkout.byn — drafts, payment, shipping, the order page and payment webhooks
module suq.storefront

import std.http
import std.json
import suq.carrier
import suq.db
import suq.model
import suq.payments
import suq.pricing.{ Policy, Quote, quote }
import suq.warehouse

/// Who is asking. Implemented by the session middleware.
public interface ISessions {
    identify(req: Request) -> CustomerId? uses net, alloc, suspend
}

/// Autosaved checkout addresses. A patch has no rules, so it is stored and loaded as
/// `Untrusted<Address.Patch>`; only `complete()` turns it into a trusted `Address`.
public struct DraftStore {
    public db: Pool

    public save(patch: Untrusted<Address.Patch>, for order: OrderId) fails DbError uses net, alloc, suspend {
        using let conn = try db.open()
        try conn.execute(sql"""
            insert into address_drafts (order_id, patch) values ($1, $2)
            on conflict (order_id) do update set patch = excluded.patch
            """, order.value, patch.toJson())
    }

    public load(for order: OrderId) -> Untrusted<Address.Patch>? fails DbError, JsonError uses net, alloc, suspend {
        using let conn = try db.open()
        let json = try conn.scalar<string?>(sql"select patch from address_drafts where order_id = $1", order.value) ?? return null
        // Rows we wrote are trusted, but this one holds what the customer typed (F-13).
        return try Address.Patch.fromJson(Untrusted(json), maxDepth: 2, maxBytes: 2KiB)
    }
}

@derive(Json)
struct PayRequest {
    card: CardToken
}

/// Everything the HTTP handlers need. Holds the gateway (unique), so it is unique too.
public struct unique Storefront {
    public orders: OrdersStore
    public drafts: DraftStore
    public users: UsersStore
    public catalog: Catalog
    public sessions: dyn ISessions
    public gateway: Gateway
    public shipper: dyn IShipper
    public outbox: Mutex<Outbox>                 // shared by every request fiber
    public policy: Policy
    public slots: Map<Sku, ShelfSlot>

    /// Loads an order only for the customer who owns it. Someone else's order is reported
    /// as not found, so order ids can't be probed.
    loadOwnOrder(req: Request) -> Order? fails ReadError uses net, alloc, suspend {
        let customer = sessions.identify(req) ?? return null
        let id = OrderId.tryParse(req.route("id")) ?? return null
        let order = try orders.find(id) ?? return null
        return order if order.customer == customer
        return null
    }

    /// PUT /orders/{id}/address — autosave while the customer types. Nothing is required yet.
    public saveAddress(req: Request) -> Response uses net, alloc, suspend {
        let found = loadOwnOrder(req) catch _ => return .unavailable
        let order = found ?? return .notFound
        let id = order.id
        let patch = Address.Patch.fromJson(req.body, maxDepth: 2, maxBytes: 2KiB) catch _ => return .badRequest
        drafts.save(patch, for: id) catch _ => return .unavailable
        return .noContent
    }

    /// POST /orders/{id}/pay — the order must be placed and the saved address complete.
    public pay(req: Request) -> Response uses net, alloc, suspend, clock {
        // `CardToken` has `requires`, so a successful decode is trusted (O10).
        let body = PayRequest.fromJson(req.body, maxDepth: 1, maxBytes: 1KiB) catch _ => return .badRequest
        let found = loadOwnOrder(req) catch _ => return .unavailable
        var order = found ?? return .notFound
        let id = order.id
        return .conflict(json: ["state": order.statusLabel]) unless order is .placed   // order: Order is .placed

        let draft = drafts.load(for: id) catch _ => return .unavailable
        let patch = draft ?? return .unprocessable(json: ["address": "missing"])
        // Constructing the `Address` checks its rules and removes the taint.
        let address = patch.complete() catch e => return .unprocessable(json: e.violations)

        // Charge what the customer was shown: the quote, with discount, shipping and tax.
        // A second concurrent request is safe: the gateway dedupes on the order's idempotency key.
        let lines = (order.lines except inactive).map(it.priceLine).collected()
        let priced = quote(lines.asSpan, by: policy) catch _ => return .unprocessable(json: ["order": "cannot be shipped"])
        let payment = gateway.charge(priced.total, from: body.card, for: id) catch switch {
            PaymentError.declined e => return .paymentRequired(json: ["code": e.code]),
            PaymentError => return .unavailable,
        }
        order.markPaid(payment)                                   // order: Order is .paid
        orders.saveState(order) catch _ => return .serverError

        let tracking = ship(order, to: address) catch e => {
            log($"order {id} paid; shipping queued: {e}", as: .warning)
            return .accepted(json: order.toDto())
        }
        order.markShipped(tracking)                               // order: Order is .shipped
        orders.saveState(order) catch _ => return .serverError
        return .ok(json: order.toDto())
    }

    /// Packs and books a paid order. If booking fails, every parcel waits in the outbox
    /// as a `BookWithRetryOp` value and the order stays paid.
    ship(order: Order is .paid, to address: Address) -> TrackingId fails ShipError {
        let units = (order.lines except inactive).map(it.qty).sum()
        var items = FixedList<PackItem>(capacity: units)
        try listItemsInto(ref items, from: order.lines, by: slots)
        var plan = PackPlan.allocate(for: items.length)
        try packInto(ref plan, from: items)

        var parcels = List<Parcel>(capacity: plan.boxes.length)
        for b in plan.boxes.indices {
            parcels.append(Parcel { order: order.id, box: plan.boxes[b].name, weight: plan.load[b] })
        }
        defer failing (e) {
            if e is CarrierError {
                using let pending = outbox.lock()        // no suspension while held
                for parcel in parcels {
                    pending.append(BookWithRetryOp(parcel, by: shipper))
                }
            }
        }
        let tracking = try bookAll(parcels, by: shipper)
        log($"order {order.id}: {parcels.length} parcels to {address.city}")
        // The `shipped` state holds one tracking number; extra parcels are only logged (F-32).
        return tracking[0]
    }

    /// GET /orders/{id}/track — redirect to the courier, only for a shipped order.
    public track(req: Request) -> Response uses net, alloc, suspend {
        let found = loadOwnOrder(req) catch _ => return .unavailable
        let order = found ?? return .notFound
        return .conflict(json: ["state": order.statusLabel]) unless order is .shipped
        // Narrowed: `order.tracking` exists only in `.shipped`. The redirect target is a `Url`
        // with an allowlisted host, never a string from the request.
        let url = Url.tryParse($"https://track.laju.example/{order.tracking.value}", allow: courierHosts) ?? return .serverError
        return .redirect(to: url)
    }

    /// GET /orders/{id} — the order and the customer's lifetime spend load concurrently.
    public renderOrderPage(req: Request) -> Response uses net, alloc, suspend {
        let id = OrderId.tryParse(req.route("id")) ?? return .notFound
        let customer = sessions.identify(req) ?? return .unauthorized

        let found = async orders.find(id)
        let spend = async orders.sumLifetimeSpend(customer, as: policy.currency)
        let (maybeOrder, lifetime) = await (found, spend) catch _ => return .unavailable
        let order = maybeOrder ?? return .notFound
        return .notFound if order.customer != customer             // don't reveal other customers' ids

        let lines = (order.lines except inactive).map(it.priceLine).collected()
        let priced = quote(lines.asSpan, by: policy) catch _ => return .serverError
        var page = Html.Builder()
        page.append(Html("<h1>Order "))
        page.append(Html.escape(order.id.value.format()))
        page.append(Html("</h1><p>"))
        page.append(Html.escape(order.statusLabel))
        page.append(Html("</p><p>Total: "))
        page.append(Html.escape(priced.total.format()))
        page.append(Html("</p><p>Lifetime: "))
        page.append(Html.escape(lifetime.format()))
        page.append(Html("</p>"))
        return .html(page.build())
    }

    /// Runs for the life of the server: retries queued bookings once a minute and records
    /// each success, so an order paid during a courier outage still ends up shipped.
    public sweepOutbox() -> never uses net, alloc, suspend, clock {
        while true {
            Clock.sleep(60s)
            for (parcel, tracking) in retryOutbox(outbox) {
                recordShipment(tracking, for: parcel.order) catch e => log($"order {parcel.order}: booked {tracking}, not recorded: {e}", as: .error)
            }
        }
    }

    recordShipment(tracking: TrackingId, for id: OrderId) fails ReadError, DbError {
        var order = try orders.find(id) ?? return
        return unless order is .paid           // another parcel of the same order got there first
        order.markShipped(tracking)
        try orders.saveState(order)
    }

    /// POST /webhooks/payments — authenticated before it is parsed.
    public receivePaymentWebhook(req: Request) -> Response uses net, alloc, suspend {
        return .payloadTooLarge if req.body.length > 4096      // before the MAC, which reads all of it
        let tag = Hex.tryDecode(req.header("x-signature") ?? return .unauthorized) ?? return .unauthorized
        let event = readWebhook(Webhook { body: req.body, tag }, by: gateway.webhookKey) catch switch {
            WebhookError.forged => return .unauthorized,
            WebhookError.unreadable => return .badRequest,
        }
        log($"payment {event.payment}: {event.kind}")
        return .noContent
    }
}

const courierHosts = Set(["track.laju.example"])

@derive(Json)
struct OrderDto {
    id: i64
    status: string
    total: string
    lines: List<LineDto>
}

@derive(Json)
struct LineDto {
    sku: string
    qty: i32
    unitPrice: string
    status: LineStatus
}

extension Order {
    public toDto() -> OrderDto uses alloc => OrderDto {
        id: id.value,
        status: statusLabel,
        total: total.format(),
        lines: lines.map(it.toDto()).collected(),
    }
}

extension Line {
    public toDto() -> LineDto uses alloc =>
        LineDto { sku: sku.value, qty, unitPrice: unitPrice.format(), status }
}
