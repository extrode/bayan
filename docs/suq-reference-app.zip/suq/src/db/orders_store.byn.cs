// orders_store.byn — orders on PostgreSQL: rows, transactions, binary COPY, streaming reads
module suq.db

import std.db.pg
import std.io
import suq.model
import suq.pricing.{ Money, Currency, Grams }

// Rows are flat (SPEC §16). Strings borrow the reader's buffer until the next row.

@derive(Row)
@table("orders")
struct OrderRow {
    id: i64
    customerId: i64
    currency: string
    status: string
    paymentId: string?
    trackingId: string?
    cancelReason: string?
    placedAt: Instant

    /// Rebuilds the order in its stored state. Each state needs its own literal (F-05).
    /// Borrowed strings are copied out with `owned()`, since the order outlives the row.
    public toOrder(lines: List<Line>, as currency: Currency) -> Order fails StoreError uses alloc {
        let corrupt = StoreError.corrupt(table: "orders", id: id)
        let orderId = OrderId(id) catch _ => fail corrupt
        let customer = CustomerId(customerId) catch _ => fail corrupt
        let state = Order.State.tryParse(status) ?? fail corrupt
        return state switch {
            .draft => Order.draft { id: orderId, customer, currency, lines },
            .placed => Order.placed { id: orderId, customer, currency, lines },
            .paid => Order.paid {
                id: orderId, customer, currency, lines,
                payment: PaymentId((paymentId ?? fail corrupt).owned()) catch _ => fail corrupt,
            },
            .shipped => Order.shipped {
                id: orderId, customer, currency, lines,
                payment: PaymentId((paymentId ?? fail corrupt).owned()) catch _ => fail corrupt,
                tracking: TrackingId((trackingId ?? fail corrupt).owned()) catch _ => fail corrupt,
            },
            .cancelled => Order.cancelled { id: orderId, customer, currency, lines, reason: (cancelReason ?? "").owned() },
        }
    }
}

@derive(Row)
@table("order_lines")
struct LineRow {
    orderId: i64
    sku: string
    qty: i32
    unitPriceCents: i64
    unitWeight: Grams
    status: string

    public toLine(as currency: Currency) -> Line fails StoreError uses alloc {
        let corrupt = StoreError.corrupt(table: "order_lines", id: orderId)
        let validSku = Sku(sku.owned()) catch _ => fail corrupt
        let lineStatus = LineStatus.tryParse(status) ?? fail corrupt
        return Line {
            sku: validSku,
            qty,
            unitPrice: Money { cents: unitPriceCents, currency },
            unitWeight,
            status: lineStatus,
        } catch _ => fail corrupt
    }
}

public union error StoreError {
    corrupt(table: string, id: i64)
}

public union error ReadError = DbError, StoreError

public struct OrdersStore {
    public db: Pool

    /// Saves a placed order and its lines in one transaction. Lines go in with binary COPY.
    public insert(order: Order is .placed) fails DbError uses net, alloc, suspend {
        using let conn = try db.open()
        using let tx = try conn.begin()
        defer failing tx.rollback()

        try tx.execute(sql"""
            insert into orders (id, customer_id, currency, status, placed_at)
            values ($1, $2, $3, 'placed', now())
            """, order.id.value, order.customer.value, order.currency.code)

        using let copy = try tx.copyIn<LineRow>()
        for line in order.lines {
            try copy.write(LineRow {
                orderId: order.id.value,
                sku: line.sku.value,
                qty: line.qty,
                unitPriceCents: line.unitPrice.cents,
                unitWeight: line.unitWeight,
                status: line.status.format(),
            })
        }
        try copy.finish()
        try tx.commit()
    }

    /// Writes the state columns after a transition. The state's payload decides the columns.
    public saveState(order: Order) fails DbError uses net, alloc, suspend {
        using let conn = try db.open()
        let (payment, tracking, reason) = order switch {
            .draft or .placed => (null, null, null),
            .paid o => (o.payment.value, null, null),
            .shipped o => (o.payment.value, o.tracking.value, null),
            .cancelled o => (null, null, o.reason),
        }
        try conn.execute(sql"""
            update orders
            set status = $2, payment_id = $3, tracking_id = $4, cancel_reason = $5
            where id = $1
            """, order.id.value, order.state.format(), payment, tracking, reason)
    }

    /// Loads an order in whatever state it's in. The caller narrows with `is` or `switch`.
    public find(id: OrderId) -> Order? fails ReadError uses net, alloc, suspend {
        using let conn = try db.open()
        let row = try conn.queryOne<OrderRow>(sql"select * from orders where id = $1", id.value) ?? return null
        let currency = Currency.tryParse(row.currency) ?? fail .corrupt(table: "orders", id: row.id)

        var lines = List<Line>()
        // Lazy query: `for try` covers opening the cursor and every step.
        for try l in conn.query<LineRow>(sql"select * from order_lines where order_id = $1 order by sku", id.value) {
            lines.append(try l.toLine(as: currency))
        }
        return try row.toOrder(move lines, as: currency)
    }

    /// Lifetime spend for a customer, streamed row by row with no row objects at all.
    public sumLifetimeSpend(customer: CustomerId, as currency: Currency) -> Money fails DbError uses net, alloc, suspend {
        using let conn = try db.open()
        using let rows = try conn.reader(sql"""
            select l.unit_price_cents, l.qty
            from order_lines l join orders o on o.id = l.order_id
            where o.customer_id = $1 and o.currency = $2
              and o.status in ('paid', 'shipped') and l.status = 'active'
            """, customer.value, currency.code)
        var total = Money.zero(currency)
        while let row = try rows.next() {
            total = total + Money { cents: row.i64(0), currency } * row.i32(1)
        }
        return total
    }

    /// Streams every line placed since `start` as CSV. One arena for the whole export,
    /// reset per row, so memory stays flat however many rows there are.
    public exportLines(from start: Instant, to out: dyn IWriter) fails DbError, IoError uses net, alloc, suspend, fs {
        using let conn = try db.open()
        using let arena = Arena(capacity: 64KiB)
        try out.write("order_id,sku,qty,unit_price_cents,unit_weight_g\n")
        for try l in conn.query<LineRow>(sql"""
            select l.* from order_lines l join orders o on o.id = l.order_id
            where o.placed_at >= $1 order by l.order_id
            """, start) {
            provide alloc: arena {
                try out.write($"{l.orderId},{l.sku},{l.qty},{l.unitPriceCents},{l.unitWeight / 1g}\n")
            }
            arena.reset()
        }
    }
}
