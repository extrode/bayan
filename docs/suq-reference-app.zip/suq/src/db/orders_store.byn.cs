// orders_store.byn — orders on PostgreSQL: rows, transactions, binary COPY, streaming reads
module suq.db

import std.db.pg
import std.io
import suq.model
import suq.pricing.{ Money, Currency, Grams }

// Rows are flat (SPEC §16). Strings borrow the reader's buffer until the next row.

@derive(Row)
@table("orders")
struct OrderRow {
    i64 id
    i64 customerId
    string currency
    string status
    string? paymentId
    string? trackingId
    string? cancelReason
    Instant placedAt

    /// Rebuilds the order in its stored state. Each state needs its own literal (F-05).
    /// Borrowed strings are copied out with `copy()`, since the order outlives the row.
    public Order restoreOrder(List<Line> lines, as Currency currency) fails StoreError uses alloc {
        let corrupt = StoreError.corrupt(table: "orders", id: id)
        let orderId = OrderId(id) catch _ => fail corrupt
        let customer = CustomerId(customerId) catch _ => fail corrupt
        let state = Order.State.tryParse(status) ?? fail corrupt
        return state switch {
            .draft => Order.draft { id: orderId, customer, currency, lines },
            .placed => Order.placed { id: orderId, customer, currency, lines },
            .paid => Order.paid {
                id: orderId, customer, currency, lines,
                payment: PaymentId((paymentId ?? fail corrupt).copy()) catch _ => fail corrupt,
            },
            .shipped => Order.shipped {
                id: orderId, customer, currency, lines,
                payment: PaymentId((paymentId ?? fail corrupt).copy()) catch _ => fail corrupt,
                tracking: TrackingId((trackingId ?? fail corrupt).copy()) catch _ => fail corrupt,
            },
            .cancelled => Order.cancelled { id: orderId, customer, currency, lines, reason: (cancelReason ?? "").copy() },
        }
    }
}

@derive(Row)
@table("order_lines")
struct LineRow {
    i64 orderId
    string sku
    i32 qty
    i64 unitPriceCents
    Grams unitWeight
    string status

    public Line restoreLine(as Currency currency) fails StoreError uses alloc {
        let corrupt = StoreError.corrupt(table: "order_lines", id: orderId)
        let validSku = Sku(sku.copy()) catch _ => fail corrupt
        let lineStatus = LineStatus.tryParse(status) ?? fail corrupt
        return Line {
            sku: validSku,
            qty,
            unitPrice: Money { cents: unitPriceCents, currency },
            unitWeight,
            status: lineStatus,
        } catch _ => fail corrupt
    }
}

public union error StoreError {
    corrupt(string table, i64 id)
}

public union error ReadError = DbError, StoreError

public struct OrdersStore {
    public Pool db

    /// Saves a placed order and its lines in one transaction. Lines go in with binary COPY.
    public void insert(Order.placed order) fails DbError uses db, alloc, suspend {
        using let conn = try db.open()
        using let tx = try conn.begin()
        defer failing tx.rollback()

        try tx.execute(sql"""
            insert into orders (id, customer_id, currency, status, placed_at)
            values ($1, $2, $3, 'placed', now())
            """, order.id.value, order.customer.value, order.currency.code)

        var rows = List<LineRow>(capacity: order.lines.length)
        for line in order.lines {
            rows.append(LineRow {
                orderId: order.id.value,
                sku: line.sku.value,
                qty: line.qty,
                unitPriceCents: line.unitPrice.cents,
                unitWeight: line.unitWeight,
                status: line.status.format(),
            })
        }
        try tx.bulkCopy(rows.span, ignoreConstraints: false)     // binary COPY (F-40)
        try tx.commit()
    }

    /// Writes the state columns after a transition. The state's payload decides the columns.
    public void saveState(Order order) fails DbError uses db, alloc, suspend {
        using let conn = try db.open()
        let (payment, tracking, reason) = order switch {
            .draft or .placed => (null, null, null),
            .paid o => (o.payment.value, null, null),
            .shipped o => (o.payment.value, o.tracking.value, null),
            .cancelled o => (null, null, o.reason),
        }
        try conn.execute(sql"""
            update orders
            set status = $2, payment_id = $3, tracking_id = $4, cancel_reason = $5
            where id = $1
            """, order.id.value, order.state.format(), payment, tracking, reason)
    }

    /// Loads an order in whatever state it's in. The caller narrows with `is` or `switch`.
    public Order? find(OrderId id) fails ReadError uses db, alloc, suspend {
        using let conn = try db.open()
        let row = try conn.query<OrderRow>(sql"select * from orders where id = $1", id.value).tryFirst() ?? return null
        let currency = Currency.tryParse(row.currency) ?? fail .corrupt(table: "orders", id: row.id)

        var lines = List<Line>()
        // Lazy query: `for try` covers opening the cursor and every step.
        for try l in conn.query<LineRow>(sql"select * from order_lines where order_id = $1 order by sku", id.value) {
            lines.append(try l.restoreLine(as: currency))
        }
        return try row.restoreOrder(move lines, as: currency)
    }

    /// Lifetime spend for a customer, streamed row by row as tuples: no row struct at all.
    public Money sumLifetimeSpend(CustomerId customer, as Currency currency) fails DbError uses db, alloc, suspend {
        using let conn = try db.open()
        var total = Money.zero(currency)
        for try (cents, qty) in conn.query<(i64, i32)>(sql"""
            select l.unit_price_cents, l.qty
            from order_lines l join orders o on o.id = l.order_id
            where o.customer_id = $1 and o.currency = $2
              and o.status in ('paid', 'shipped') and l.status = 'active'
            """, customer.value, currency.code) {
            total = total + Money { cents, currency } * qty
        }
        return total
    }

    /// Streams every line placed since `start` as CSV. One arena for the whole export,
    /// reset per row, so memory stays flat however many rows there are.
    public void exportLines(from Instant start, to dyn IWriter out) fails DbError, IoError uses db, alloc, suspend {
        using let conn = try db.open()
        using let arena = Arena(capacity: 64KiB)
        try out.write("order_id,sku,qty,unit_price_cents,unit_weight_g\n")
        for try l in conn.query<LineRow>(sql"""
            select l.* from order_lines l join orders o on o.id = l.order_id
            where o.placed_at >= $1 order by l.order_id
            """, start) {
            provide alloc: arena {
                try out.write($"{l.orderId},{l.sku},{l.qty},{l.unitPriceCents},{l.unitWeight / 1g}\n")
            }
            arena.reset()
        }
    }
}
