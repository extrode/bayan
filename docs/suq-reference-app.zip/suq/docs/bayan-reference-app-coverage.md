# Sūq — feature coverage

Which Sūq files exercise each round-3 feature. "×2" means it's used at least twice, in different ways. Until the compiler implements `bayan features --used`, this table is kept by hand.

| Feature (HANDOFF §) | Where | |
|---|---|---|
| Head-first declarations (§2) | `struct unique` sodium, gateway, checkout; `type distinct` ids, packing, restock; `union error` everywhere | ×2 |
| `union error` composition and `except` (§2, §7) | `OrderError = BasketError, PricingError`; `ShipError`, `PackError`, `ReadError`, `StartupError`; `Retryable = CarrierError except .rejected` | ×2 |
| Type-first declarations: return type or `void`, `Type name` params, fields and payloads; name-first `let`/`var` bindings (§2, revert of 2026-10-22) | all files | ×2 |
| Receivers: none, `this is .s`, `ref this`, `ref this is .s or .t` (§2, §14) | order, packing (`PackPlan`), stats | ×2 |
| `unique` resources (§2) | `SecretKey` (drop frees guarded memory), Gateway, Storefront | ×2 |
| Named patterns (§2) | `inactive` (order), `hidden` (catalog, with `or` of two struct patterns) | ×2 |
| Waqf termination, no `;` (§3) | all files; multi-line rule in address; `=>` continuation in packing | ×2 |
| `@` attributes, `because` (§4) | `@derive`, `@table`, `@cases`, `@budget`, `@forms`; `because` on `expose`, `trustUnchecked`, `unsafe` | ×2 |
| Postfix `if` / `unless`, block `unless` (§5) | money, quote, order, carrier, checkout, restock | ×2 |
| Word booleans `not`/`and`/`or` (§5) | package.byn `style.booleans: .words`; ids, address, catalog, restock | ×2 |
| `//` only, `///` docs and doctests (§6) | money (doctest), all files | ×2 |
| `except` on sequences (§7) | `lines except inactive` (order, packing, checkout), `rows except hidden`, `lines() … except ""` | ×2 |
| Units, finer-only conversion, `floor`/`ceiling`/`rounded<Unit>()` (§8) | `2kg`→Grams, `8pct`→BasisPoints, `200ms`/`5s`, `16KiB`; `i32 × Grams`; `rate / 1bp` | ×2 — `round(to:)` and `convert(to:)` are removed; `ceiling<Kilograms>()` in carrier (`billedWeight`) |
| Typed indices (§9) | `BoxId` over `boxes`/`load`, `.indices`, `lastIndex` | ×1 |
| `rune` (§10) | rune literals in `formatInto`, `split(',')` | ×1 |
| `requires` everywhere, violations, `T.Patch`, `T.rules`, `with` re-check (§11) | ids, address (struct-level `at`), order, signup, restock (field default) | ×2 |
| Grammar rules: `T.X` vs `X<T>`, `log` verb (§12) | `Address.Patch`, `Html.Builder`, `Order.State`; `Untrusted<…>`, `Secret<…>`; `log(…, as:)` | ×2 |
| Effects, upper bounds, inference, capabilities (§13) | pricing package `capabilities: []`; `IShipper`, `ISessions`, `Handler` bounds; private inference in catalog and checkout | ×2 |
| `provide` (§13) | `provide alloc: arena` (db), real handlers (main), fakes in carrier tests | ×2 |
| Ambient logging (§13) | carrier, accounts, checkout, restock | ×2 |
| Typestate (§14) | `Order` states, `becomes`/`become`, `for Order order is .shipped` parameter (label), narrowing in `pay` and `track`, exhaustive state switch | ×2 |
| Argument particles (§15) | `by`, `from`, `to`, `for`, `as`, `at` all used | ×2 |
| `Secret<T>` and derivations (§16) | courier, gateway and config keys; `@derive(Row)` only on flat rows | ×2 |
| Trust layer 1: sink types (§17) | `sql"…$n"`, `Html` builder, `Url` with an allowlist, `HeaderValue` | ×2 |
| Trust layer 2: `Untrusted<T>` (§17) | query, route, header and body; untrusted vs trusted decode (carrier vs gateway); untrusted file lines | ×2 |
| `try` scope (§18) | all fallible code | ×2 |
| `defer` / `defer failing` / modifier capture (§19) | db insert, sodium, checkout `defer failing (e) { … }`, restock `defer … if` | ×2 |
| Derived forms `tryX`, `xInto`/`x`, `-ed`, `XOp`, Forms II/III/V | `tryAdd`, `tryMultiply`, `tryInvoke`; `formatInto`, `packInto`, `labelInto`, `selectTopInto`; `pruned()`; `BookWithRetryOp`; `ensureCapacity`, `mergeWith`, `prune` | ×2 |
| Generics, extensions, `embed`, default methods, `Set` of a union | stats, checkout (`extension Order`) | ×1 each |
| comptime, type providers, file access | `Regex.compile`, `basket(40)`, `sample(40)`, `Json.typeFrom`, `File.read`, `Hmac.sha256` | ×2 |
| Fibers: `async`/`await`, groups with deadlines, `Mutex`, `Io.offload` | checkout `renderOrderPage`, carrier `bookAll`, `retryOutbox` (no guard across a suspension), main's sweeper group, signup | ×2 |
| `never` as a return type | `Storefront.sweepOutbox`, the `Io.group<never>` in main; `fail`/`return` arms in `catch switch` | ×2 |
| Visibility (`public` vs module default) | every cross-module type and field; Row structs and DTOs stay module-private | ×2 |
| `for try`, `while let`, `?? return`/`?? fail`, narrowing | db, catalog, restock, checkout | ×2 |
| Overflow: traps, `checked`, `*%`, `+%` | money, packing | ×1 each |
| FFI `extern`, `unsafe because` | sodium | ×1 |
| Laws (opt-in per package) | money, stats | ×2 |
| Tests: `@cases`, power asserts, doctests, `@budget` benches | pricing, packing | ×2 |
| Scripting mode, `@derive(Args)`, `@derive(Config)` | restock, main | ×2 |
| `Panic.handler`, `PanicHandler = Panic -> void uses console` (add.1 §1) | main | ×1 |
| Signature clause order `where`, `becomes`, `fails`, `uses` (§3) | stats `selectTopInto`, order `pay`, carrier `bookWithRetry` | ×2 |
| `expects` preconditions (§11) | packing `sumLoad`, money `clamped` | ×2 |
| `console` and `process` effects, `db` alias, inferred `main`, stored upper bounds (§13) | package capabilities; restock `run`; db and storefront; main; `Handler`, `OrderPaid` | ×2 |
| `states { … }` and `T.s` types (§14) | order, checkout `ship(Order.paid order, …)`, packing `labelInto`, db `insert(Order.placed …)`, `Fulfilled` alias | ×2 |
| `until`/`through` particles, `rest` exempt (§15) | packing `sumLoad`, money `clamped`, `Money.sum` | ×2 |
| Input forms and `rest` (§20, §24) | `Money.sum(…, rest …)` with a spread test; `Tally.record` overloads | ×2 |
| Loop and lambda forms (§25) | `for line: Line in …`, `Request req => …`, `(a, b) => …` in `sortPicksInto`, `x => …` in main | ×2 |
| Events and bare interface properties (§26) | `OrderPaid`, `Storefront.paid`; `IShipper.name` | ×1 each |
| Library shapes (§27) | `query<T>().single/tryFirst/all`, tuple rows, `bulkCopy`, `tryGet(at:)`, `.abs`, `.sum`, `Json.encode` | ×2 |
| Views and copies (add.1 §3) | `.span`, `.copy()`, `List(seq)`, `fromOrder`/`fromLine` factories | ×2 |
| `primitives: .sized` (§28) | package.byn | ×1 |
| `bayan format` (§29) | friction log, fail fix-its | ×1 |

## Not yet exercised

Under the CI rule ("every non-deferred spec feature is used"), these block the build until Sūq uses them:

`defer panicking`, `if likely`/`if never`, `while try`, `do … while`, `T.Id`, `T.Hasher`, `T.Comparer`, `T.<Verb>ed` events, comptime source generators that return declarations, library-defined diagnostics (`fail SUQ0001(…)`), channels and `Io.first`, atomics, `Io.Simulated`, slicing (take/skip/reverse), `+|`, `-|`, `rune` as a declared type, `mutableSpan()`, `rows.all()`, `Panic` use in a test.

## Compile-fail corpus

`fail/` has 49 snippets, one per mechanical diagnostic, each with `// expect:` and, where there is one, `// fix-it:`. `python3 tools/check_round3.py --self-test .` checks that each snippet is caught by its own rule and no other (49/49). Diagnostic codes (`BYN1xxx`…) get assigned when the compiler implements them.

**2026-10-22, type-first declarations.** Declarations went back to round 2's type-first order; local bindings stay name-first. Four snippets were added (`arrow-return`, `name-first-param`, `name-first-field`, `name-first-payload`), and `noalloc`, `not-a-particle`, `two-objects` and `fn-type-arrow` were rewritten so each still fails only for its own reason. See friction F-35 to F-39.

**2026-10-23, signature review and addendum 1.** Eleven snippets were added (`clause-order`, `on-prefix`, `to-as-call`, `to-member`, `bare-this`, `get-property`, `owned-copied`, `state-line`, `mode-particle`, `repeated-particle`, `unit-round`). `fn-type-arrow` now names its field `handler`, and `in-convert` and the `bayan fmt` fix-its follow §8 and §29. See friction F-40 to F-53.

## Per-milestone status

The v0.1 compiler doesn't implement round 3 yet, so none of Sūq compiles today. This is the "paper" stage in §21.
